/****************************************************************************
* MeshLab                                                           o o     *
* A versatile mesh processing toolbox                             o     o   *
*                                                                _   O  _   *
* Copyright(C) 2005                                                \/)\/    *
* Visual Computing Lab                                            /\/|      *
* ISTI - Italian National Research Council                           |      *
*                                                                    \      *
* All rights reserved.                                                      *
*                                                                           *
* This program is free software; you can redistribute it and/or modify      *
* it under the terms of the GNU General Public License as published by      *
* the Free Software Foundation; either version 2 of the License, or         *
* (at your option) any later version.                                       *
*                                                                           *
* This program is distributed in the hope that it will be useful,           *
* but WITHOUT ANY WARRANTY; without even the implied warranty of            *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
* GNU General Public License (http://www.gnu.org/licenses/gpl.txt)          *
* for more details.                                                         *
*                                                                           *
****************************************************************************/

#include "anker_manipulator.h"

#include <QDebug>
#include <QVector3D>
#include <common/GLExtensionsManager.h>
#define PI 3.1415926535898
#define EPSINON 0.01
AnkerManipulatorsPlugin::AnkerManipulatorsPlugin()
{

}

const QString AnkerManipulatorsPlugin::info()
{
	return tr("Provide tools for moving meshes around the space");
}

void AnkerManipulatorsPlugin::mousePressEvent(QMouseEvent* event, MeshModel& model, GLArea* gla)
{
}



void AnkerManipulatorsPlugin::mouseMoveEvent(QMouseEvent* event, MeshModel& model, GLArea* gla)
{
}

void AnkerManipulatorsPlugin::mouseReleaseEvent(QMouseEvent* event, MeshModel& model, GLArea* gla)
{
}


void AnkerManipulatorsPlugin::decorate(MeshModel& model, GLArea* gla, QPainter* painter)
{
}

bool AnkerManipulatorsPlugin::startEdit(MeshModel& m, GLArea* parent, MLSceneGLSharedDataContext* cont)
{
	thresholdRender(parent, &m, 60.0f, 90.0f);
	return true;
}

void AnkerManipulatorsPlugin::endEdit(MeshModel& m, GLArea* parent, MLSceneGLSharedDataContext* cont)
{
	if (parent == nullptr || cont == nullptr)
		return;
	cont->setRenderingDataPerMeshView(m.id(), parent->context(), defaultMLRender);
	cont->manageBuffers(m.id());
}



void AnkerManipulatorsPlugin::suggestedRenderingData(MeshModel& m, MLRenderingData& dt)
{
	defaultMLRender = dt;
	if (m.cm.VN() == 0)
		return;
	MLRenderingData::PRIMITIVE_MODALITY pr = MLRenderingData::PR_POINTS;

	if (m.cm.FN() > 0)
		pr = MLRenderingData::PR_SOLID;

	MLRenderingData::RendAtts atts;
	//atts[MLRenderingData::ATT_NAMES::ATT_VERTPOSITION] = true;
	//atts[MLRenderingData::ATT_NAMES::ATT_VERTNORMAL] = true;
	//atts[MLRenderingData::ATT_NAMES::ATT_VERTCOLOR] = true;
	atts[MLRenderingData::ATT_NAMES::ATT_VERTPOSITION] = true;
	atts[MLRenderingData::ATT_NAMES::ATT_FACECOLOR] = true;
	atts[MLRenderingData::ATT_NAMES::ATT_FACENORMAL] = true;
	vcg::GLMeshAttributesInfo::PRIMITIVE_MODALITY_MASK mask = dt.getPrimitiveModalityMask();

	dt.set(pr, atts);
}

void AnkerManipulatorsPlugin::thresholdRender(GLArea* gla, MeshModel* mm, float theta1, float theta2)
{
	if (!GLExtensionsManager::initializeGLextensions_notThrowing())
		return;
	if (gla == NULL || mm == NULL)
		return;
	vcg::tri::UpdateBounding<CMeshO>::Box(mm->cm);
	//mm->updateDataMask(MeshModel::MM_VERTFACETOPO | MeshModel::MM_FACEMARK | MeshModel::MM_VERTMARK);
	mm->updateDataMask(MeshModel::MM_FACEFACETOPO | MeshModel::MM_FACEMARK | MeshModel::MM_VERTMARK);

	/*if (!mm->hasDataMask(MeshModel::MM_VERTCOLOR))
	{
	   mm->updateDataMask(MeshModel::MM_VERTCOLOR);
	   tri::UpdateColor<CMeshO>::PerVertexConstant(mm->cm, Color4b(125, 125, 125, 255));
	}*/
	if (!mm->hasDataMask(MeshModel::MM_FACECOLOR))
	{
		mm->updateDataMask(MeshModel::MM_FACECOLOR);
		vcg::tri::UpdateColor<CMeshO>::PerFaceConstant(mm->cm, vcg::Color4b(255, 255, 0, 255));
	}
	vcg::tri::InitFaceIMark(mm->cm);
	vcg::tri::InitVertexIMark(mm->cm);

	QColor color(125, 0, 0);
	float dirtiness;
	QVector3D zVec(0.0f, 0.0f, -1.0f);

	for (CMeshO::FaceIterator fi = mm->cm.face.begin(); fi != mm->cm.face.end(); fi++)
	{
		vcg::Point3f nor = fi->N();
		QVector3D nVec(nor.X(), nor.Y(), nor.Z());
		float cosTheta = QVector3D::dotProduct(zVec, nVec) / (zVec.length() * nVec.length());
		float theta = 180.0 / PI * acosf(cosTheta);

		if (90 - theta > 90.0 || 90 - theta < EPSINON)
		{
			continue;
		}
		if ((90 - theta > theta1) && (90 - theta < theta2))
		{
			/// fi->V(0)->C() = vcg::Color4b(color.red(), color.green(), color.blue(), color.alpha());
			// fi->V(1)->C() = vcg::Color4b(color.red(), color.green(), color.blue(), color.alpha());
			// fi->V(2)->C() = vcg::Color4b(color.red(), color.green(), color.blue(), color.alpha());
			if (!fi->IsColorEnabled())
			{
				fi->Base().EnableColor();
			}
			fi->C() = vcg::Color4b(color.red(), color.green(), color.blue(), color.alpha());
		}
	}

	//vcg::tri::Allocator<CMeshO>::CompactFaceVector(m.cm);
	MLSceneGLSharedDataContext* shared = gla->mvc()->sharedDataContext();
	updateColorBuffer(*mm, shared);
	shared->manageBuffers(mm->id());
}

void AnkerManipulatorsPlugin::recMsgfromManager(PluginMessageData metaData)
{
	qDebug() << tr("AnkerManipulatorsPlugin...\n");
}
