/****************************************************************************
* MeshLab                                                           o o     *
* A versatile mesh processing toolbox                             o     o   *
*                                                                _   O  _   *
* Copyright(C) 2005                                                \/)\/    *
* Visual Computing Lab                                            /\/|      *
* ISTI - Italian National Research Council                           |      *
*                                                                    \      *
* All rights reserved.                                                      *
*                                                                           *
* This program is free software; you can redistribute it and/or modify      *
* it under the terms of the GNU General Public License as published by      *
* the Free Software Foundation; either version 2 of the License, or         *
* (at your option) any later version.                                       *
*                                                                           *
* This program is distributed in the hope that it will be useful,           *
* but WITHOUT ANY WARRANTY; without even the implied warranty of            *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
* GNU General Public License (http://www.gnu.org/licenses/gpl.txt)          *
* for more details.                                                         *
*                                                                           *
****************************************************************************/
/****************************************************************************
Revision 0.1  2021/10/27 15:52:40  Aden Hu
****************************************************************************/


#ifndef ANKER_SCENE_PLUGIN_MANIPULATOR_FACTORY_H
#define ANKER_SCENE_PLUGIN_MANIPULATOR_FACTORY_H

#include <QObject>
#include <QString>
#include <QMainWindow>
#include <QMenuBar>
#include <common/plugins/interfaces/edit_plugin.h>
#include "anker_manipulator.h"

#define MANIPULATORS_STR tr("Manipulators")

class AnkerManipulatorsFactory : public QObject, public EditPlugin
{
	Q_OBJECT
	MESHLAB_PLUGIN_IID_EXPORTER(EDIT_PLUGIN_IID)
	Q_INTERFACES(EditPlugin)

public:
	AnkerManipulatorsFactory();
	virtual ~AnkerManipulatorsFactory() { delete manipulators; }

	virtual QString pluginName() const;

	//get the edit tool for the given action
	virtual EditTool* getEditTool(const QAction*);

	//get the description for the given action
	virtual QString getEditToolDescription(const QAction*);

public:
	void recMsgfromManager(PluginMessageData);

	void initPluginGui(QMainWindow*);
	void initialize(ControlInterface* controlmanager, RichParameterList* globalParameterList);
signals:
	void sendMsg2Manager(PluginMessageData);
private:
	QAction* manipulators;
};



#endif // !ANKER_SCENE_PLUGIN_MANIPULATOR_FACTORY_H
