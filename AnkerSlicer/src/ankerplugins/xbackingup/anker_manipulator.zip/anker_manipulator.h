/****************************************************************************
* MeshLab                                                           o o     *
* A versatile mesh processing toolbox                             o     o   *
*                                                                _   O  _   *
* Copyright(C) 2005                                                \/)\/    *
* Visual Computing Lab                                            /\/|      *
* ISTI - Italian National Research Council                           |      *
*                                                                    \      *
* All rights reserved.                                                      *
*                                                                           *
* This program is free software; you can redistribute it and/or modify      *
* it under the terms of the GNU General Public License as published by      *
* the Free Software Foundation; either version 2 of the License, or         *
* (at your option) any later version.                                       *
*                                                                           *
* This program is distributed in the hope that it will be useful,           *
* but WITHOUT ANY WARRANTY; without even the implied warranty of            *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
* GNU General Public License (http://www.gnu.org/licenses/gpl.txt)          *
* for more details.                                                         *
*                                                                           *
****************************************************************************/
/****************************************************************************
Revision 0.1  2021/10/27 15:52:40  Aden Hu
****************************************************************************/

#ifndef ANKER_SCENE_PLUGIN_MANIPULATOR_H
#define ANKER_SCENE_PLUGIN_MANIPULATOR_H

#include <common/plugins/interfaces/edit_plugin.h>
#include <meshlab/glarea.h>
#include <vcg/space/point2.h>
#include <common/ml_document/cmesh.h>
#include <../ankerplugins/anker_scene/anker_world_coordinate.h>
using namespace vcg;
class AnkerManipulatorsPlugin : public QObject, public EditTool
{
	Q_OBJECT

public:

	enum RenderType { RenderThresholdType };
	AnkerManipulatorsPlugin();
	virtual ~AnkerManipulatorsPlugin() {}

	static const QString info();

	virtual void suggestedRenderingData(MeshModel&/*m*/, MLRenderingData& /*dt*/);
	virtual bool startEdit(MeshModel&/*m*/, GLArea* /*parent*/, MLSceneGLSharedDataContext* /*cont*/);
	virtual void endEdit(MeshModel&/*m*/, GLArea* /*parent*/, MLSceneGLSharedDataContext* /*cont*/);
	virtual void decorate(MeshModel&, GLArea*, QPainter*);
	virtual void mousePressEvent(QMouseEvent*, MeshModel&, GLArea*);
	virtual void mouseMoveEvent(QMouseEvent*, MeshModel&, GLArea*);
	virtual void mouseReleaseEvent(QMouseEvent* event, MeshModel&, GLArea*);
public:
	void recMsgfromManager(PluginMessageData);

	//阈值渲染，给一个阈值支撑角度值范围，染红色
	void thresholdRender(GLArea* gla, MeshModel* mm, float theta1/*最小度数 */, float theta2/*最大度数 */);

	inline void updateColorBuffer(MeshModel& m, MLSceneGLSharedDataContext* shared)
	{
		if (shared != NULL)
		{
			MLRenderingData::RendAtts atts;
			//atts[MLRenderingData::ATT_NAMES::ATT_VERTCOLOR] = true;
			atts[MLRenderingData::ATT_NAMES::ATT_FACENORMAL] = true;
			atts[MLRenderingData::ATT_NAMES::ATT_FACECOLOR] = true;
			shared->meshAttributesUpdated(m.id(), false, atts);
		}
	}

signals:
	void sendMsg2Manager(PluginMessageData);

private:
	MLRenderingData defaultMLRender;
};
#endif // !ANKER_SCENE_PLUGIN_MANIPULATOR_H
