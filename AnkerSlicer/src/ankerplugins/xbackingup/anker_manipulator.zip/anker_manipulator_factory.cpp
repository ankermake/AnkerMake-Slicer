/****************************************************************************
* MeshLab                                                           o o     *
* A versatile mesh processing toolbox                             o     o   *
*                                                                _   O  _   *
* Copyright(C) 2005                                                \/)\/    *
* Visual Computing Lab                                            /\/|      *
* ISTI - Italian National Research Council                           |      *
*                                                                    \      *
* All rights reserved.                                                      *
*                                                                           *
* This program is free software; you can redistribute it and/or modify      *
* it under the terms of the GNU General Public License as published by      *
* the Free Software Foundation; either version 2 of the License, or         *
* (at your option) any later version.                                       *
*                                                                           *
* This program is distributed in the hope that it will be useful,           *
* but WITHOUT ANY WARRANTY; without even the implied warranty of            *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
* GNU General Public License (http://www.gnu.org/licenses/gpl.txt)          *
* for more details.                                                         *
*                                                                           *
****************************************************************************/

#include "anker_manipulator_factory.h"
#include <QDebug>


#include <QMenuBar>
#include <QAction>
#include <QList>

AnkerManipulatorsFactory::AnkerManipulatorsFactory() : manipulators(NULL)
{
	manipulators = new QAction(/*QIcon(":/images/icon_manipulators.png"), */MANIPULATORS_STR, this);

	actionList.push_back(manipulators);

	foreach(QAction * editAction, actionList)
		editAction->setCheckable(true);
}

QString AnkerManipulatorsFactory::pluginName() const
{
	return "AnkerManipulators";
}

EditTool* AnkerManipulatorsFactory::getEditTool(const QAction* action)
{
	if (action == manipulators) {
		return new AnkerManipulatorsPlugin();
	}
	else
		assert(0); //should never be asked for an action that isn't here
	return NULL;
}

QString AnkerManipulatorsFactory::getEditToolDescription(const QAction*)
{
	return AnkerManipulatorsPlugin::info();
}

void AnkerManipulatorsFactory::initPluginGui(QMainWindow* wm)
{
	QList<QAction*> allAction = wm->menuBar()->actions();
	QAction* sceneAction = NULL;
	QAction* viewAction = NULL;
	QAction* editAction = NULL;
	for (QAction* action : allAction) {
		if (action->text() == tr("&Scene")) {
			sceneAction = action;
		}
		else if (action->text() == tr("&View")) {
			viewAction = action;
		}
		else if (action->text() == tr("&Edit")) {
			editAction = action;
		}
	}

	if (viewAction == NULL || editAction == NULL)
	{
		return;
	}

	QMenu* sceneMenu = NULL;
	if (sceneAction == NULL)
	{
		//在View前插入Scene菜单
		sceneMenu = new QMenu(tr("&Scene"));
		wm->menuBar()->insertMenu(viewAction, sceneMenu);
	}
	else
	{
		sceneMenu = sceneAction->menu();
	}

	for (QAction* action : actionList) {
		if (action->text() == MANIPULATORS_STR) {
			sceneMenu->addAction(action);
			//action->setShortcut(tr("a"));
		}
		editAction->menu()->removeAction(action);
	}
}

void AnkerManipulatorsFactory::recMsgfromManager(PluginMessageData metaData)
{
	qDebug() << tr("AnkerManipulatorsFactory...\n");
	if (metaData.msg == QString("Plugin UI initialization running in the QMainWindow constructor")
		&& metaData.object != NULL)
	{
		initPluginGui(qobject_cast<QMainWindow*>(metaData.object));
	}
}

void AnkerManipulatorsFactory::initialize(ControlInterface* controlmanager, RichParameterList* globalParameterList)
{
	if (controlmanager == nullptr || globalParameterList == nullptr)
		return;
	//controlmanager->addActionToModelTranform(manipulators);
}

MESHLAB_PLUGIN_NAME_EXPORTER(AnkerManipulatorsFactory)
