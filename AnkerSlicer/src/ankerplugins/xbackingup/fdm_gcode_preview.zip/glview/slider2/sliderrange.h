#ifndef SLIDERRANGE_H
#define SLIDERRANGE_H

#include <QWidget>
#include <QMouseEvent>
#include <QPaintEvent>

class SliderRange : public QWidget
{
	Q_OBJECT
		Q_ENUMS(SliderStyle)
		Q_ENUMS(SliderBgPercent)
		Q_ENUMS(SliderPercent)
		Q_ENUMS(SliderOrientation)

		Q_PROPERTY(int minValue READ getMinValue WRITE setMinValue)
		Q_PROPERTY(int maxValue READ getMaxValue WRITE setMaxValue)
		Q_PROPERTY(int leftValue READ getLeftValue WRITE setLeftValue)
		Q_PROPERTY(int rightValue READ getRightValue WRITE setRightValue)
		Q_PROPERTY(int upValue READ getUpValue WRITE setUpValue)
		Q_PROPERTY(int belowValue READ getBelowValue WRITE setBelowValue)

		Q_PROPERTY(int borderWidth READ getBorderWidth WRITE setBorderWidth)
		Q_PROPERTY(bool horizontal READ getHorizontal WRITE setHorizontal)
		Q_PROPERTY(bool showText READ getShowText WRITE setShowText)

		Q_PROPERTY(QColor usedColor READ getUsedColor WRITE setUsedColor)
		Q_PROPERTY(QColor freeColor READ getFreeColor WRITE setFreeColor)
		Q_PROPERTY(QColor textColor READ getTextColor WRITE setTextColor)
		Q_PROPERTY(QColor rangeTextColor READ getRangeTextColor WRITE setRangeTextColor)
		Q_PROPERTY(QColor sliderColor READ getSliderColor WRITE setSliderColor)
		Q_PROPERTY(QColor borderColor READ getBorderColor WRITE setBorderColor)

		Q_PROPERTY(SliderStyle sliderStyle READ getSliderStyle WRITE setSliderStyle)
		Q_PROPERTY(SliderBgPercent sliderBgPercent READ getSliderBgPercent WRITE setSliderBgPercent)
		Q_PROPERTY(SliderPercent sliderPercent READ getSliderPercent WRITE setSliderPercent)

public:
	enum SliderStyle {
		SliderStyle_Line = 0,       //线条状风格
		SliderStyle_Circle = 1      //圆形状风格
	};

	enum SliderBgPercent {
		SliderBgPercent_0_1 = 1,
		SliderBgPercent_0_2 = 2,
		SliderBgPercent_0_3 = 3,
		SliderBgPercent_0_4 = 4,
		SliderBgPercent_0_5 = 5,
		SliderBgPercent_0_6 = 6,
		SliderBgPercent_0_7 = 7,
		SliderBgPercent_0_8 = 8,
		SliderBgPercent_0_9 = 9,
		SliderBgPercent_1_0 = 10
	};

	enum SliderPercent {
		SliderPercent_0_1 = 1,
		SliderPercent_0_2 = 2,
		SliderPercent_0_3 = 3,
		SliderPercent_0_4 = 4,
		SliderPercent_0_5 = 5
	};

	enum SliderOrientation
	{
		SliderOrientation_Horizontal = 1,
		SliderOrientation_Vertical = 2
	};

    explicit SliderRange(QWidget* parent = 0,bool horizontalValue = false);
	~SliderRange();

protected:
	void mousePressEvent(QMouseEvent*);
	void mouseReleaseEvent(QMouseEvent*);
	void mouseMoveEvent(QMouseEvent*);
	void paintEvent(QPaintEvent*);
	void drawSliderBg(QPainter* painter);
	void drawSliderBg(QPainter* painter, SliderOrientation orientation);
	void drawSliderLine(QPainter* painter);
	void drawSliderLine(QPainter* painter, SliderOrientation orientation);
	void drawSliderCircle(QPainter* painter);
	void drawSliderCircle(QPainter* painter, SliderOrientation orientation);
	void drawValue(QPainter* painter);
	void drawValue(QPainter* painter, SliderOrientation orientation);

private:
	int minValue;                   //最小值
	int maxValue;                   //最大值
	int leftValue;                  //范围值左边
	int rightValue;                 //范围值右边
	int upValue;					//范围值上边
	int belowValue;					//范围值下边

	int borderWidth;                //滑块边框宽度
	bool horizontal;                //是否横向
	bool showText;                  //是否显示值

	QColor usedColor;               //范围值颜色
	QColor freeColor;               //范围值外颜色
	QColor textColor;               //文字颜色
	QColor rangeTextColor;          //范围文字颜色
	QColor sliderColor;             //滑块颜色
	QColor borderColor;             //滑块边框颜色

	SliderStyle sliderStyle;        //滑块风格
	SliderBgPercent sliderBgPercent;//滑块背景所占比例
	SliderPercent sliderPercent;    //滑块所占比例

	bool leftPressed;               //左边指示器是否按下
	bool rightPressed;              //右边指示器是否按下
	bool upPressed;					//上边指示器是否按下
	bool belowPressed;				//下边指示器是否按下

	int sliderLen;                  //指示器长度
	QRect leftSliderRect;           //左边值指示器区域
	QRect rightSliderRect;          //右边值指示器区域
	QRect upSliderRect;				//上边值指示器区域
	QRect belowSliderRect;			//下边值指示器区域

public:
	int getMinValue()               const;
	int getMaxValue()               const;
	int getLeftValue()              const;
	int getRightValue()             const;
	int getUpValue()				const;
	int getBelowValue()				const;

	int getBorderWidth()            const;
	bool getHorizontal()            const;
	bool getShowText()              const;

	QColor getUsedColor()           const;
	QColor getFreeColor()           const;
	QColor getTextColor()           const;
	QColor getRangeTextColor()      const;
	QColor getSliderColor()         const;
	QColor getBorderColor()         const;

	SliderStyle getSliderStyle()    const;
	SliderBgPercent getSliderBgPercent()const;
	SliderPercent getSliderPercent()const;

	QSize sizeHint()                const;
	QSize minimumSizeHint()         const;

public Q_SLOTS:
	//设置范围值
	void setRange(int minValue, int maxValue);
	void setRange(int minValue, int maxValue, SliderOrientation orientation);
	//设置最大最小值
	void setMinValue(int minValue);
	void setMaxValue(int maxValue);

	//设置当前范围值
	void setCurrentRange(int leftValue, int rightValue);
	void setCurrentRange(int belowValue, int upValue, SliderOrientation orientation);
	void setLeftValue(int leftValue);
	void setRightValue(int rightValue);
	void setUpValue(int upValue);
	void setBelowValue(int belowValue);

	//设置滑块边框宽度
	void setBorderWidth(int borderWidth);

	//设置方向
	void setHorizontal(bool horizontal);

	//设置是否显示值
	void setShowText(bool showText);

	//设置刻度值颜色
	void setUsedColor(const QColor& usedColor);
	//设置指针颜色
	void setFreeColor(const QColor& freeColor);
	//设置文本颜色
	void setTextColor(const QColor& textColor);
	//设置文本颜色
	void setRangeTextColor(const QColor& rangeTextColor);
	//设置滑块颜色
	void setSliderColor(const QColor& sliderColor);
	//设置滑块边框颜色
	void setBorderColor(const QColor& borderColor);

	//设置滑块风格
	void setSliderStyle(const SliderStyle& sliderStyle);
	//设置滑块背景所占比例
	void setSliderBgPercent(const SliderBgPercent& sliderBgPercent);
	//设置滑块所占比例
	void setSliderPercent(const SliderPercent& sliderPercent);

Q_SIGNALS:
	void valueChanged(int leftValue, int rightValue);
	//void valueChanged(int belowValue, int upValue, SliderOrientation orientation);
};


#endif //SLIDERRANGE_H
