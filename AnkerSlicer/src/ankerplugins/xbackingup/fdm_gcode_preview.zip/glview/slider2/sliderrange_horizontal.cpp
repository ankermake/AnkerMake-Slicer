#include "sliderrange_horizontal.h"
#include <QPainter>
#include <QEvent>
#include "qmath.h"
#include <QDebug>
#include "../common/utilities/tlogger.h"

HSliderRang::HSliderRang(QWidget* parent) : QWidget(parent), minValue(0), maxValue(100), leftValue(0), rightValue(100), borderWidth(1),
horizontal(true), showText(false), usedColor(QColor(24, 189, 155)), freeColor(QColor(70, 70, 70)), textColor(QColor(80, 80, 80)),
rangeTextColor(QColor(200, 200, 200)), sliderColor(QColor(250, 250, 250)), borderColor(QColor(255, 107, 107)),
sliderStyle(SliderStyle_Circle), sliderBgPercent(SliderBgPercent_0_2), sliderPercent(SliderPercent_0_2), leftPressed(false), rightPressed(false)
{
    //AkUtil::TFunction("");
	setFont(QFont("Arial", 8));
    setFocusPolicy(Qt::ClickFocus);
}

HSliderRang::~HSliderRang()
{

}

void HSliderRang::mousePressEvent(QMouseEvent* e)
{
    //AkUtil::TFunction("");
	if (e->button() & Qt::LeftButton) {

		int x = e->pos().x();
		int y = e->pos().y();

//        QRect tmpRect = leftSliderRect;
//		tmpRect.setRect(leftSliderRect.x() - 5, leftSliderRect.y() - 5, leftSliderRect.width() + 10, leftSliderRect.height() + 10); //增大鼠标落到矩形框中的范围
//		bool isContains = tmpRect.contains(x, y);
//		if (isContains)
//		{
//			leftPressed = true;
//			update();
//		}
        QRect tmpRect  = rightSliderRect;
		tmpRect.setRect(rightSliderRect.x() - 5, rightSliderRect.y() - 5, rightSliderRect.width() + 10, rightSliderRect.height() + 10);
		//belowSliderRect = tmpRect;
        bool isContains = tmpRect.contains(x, y);
		if (isContains)
		{
			rightPressed = true;
			update();
		}

        pressPos = press_center;
        if(rightSliderRect.contains(x,y))
        {
            pressPos = press_right;
        }
	}
	e->accept();
}

void HSliderRang::mouseReleaseEvent(QMouseEvent* e)
{
    //AkUtil::TFunction("");
	leftPressed = false;
	rightPressed = false;
	e->accept();
	update();
    alf = 0.0;
}

#include<QtMath>
void HSliderRang::wheelEvent(QWheelEvent * event)
{
    //qDebug() <<"event->delta() "<<event->delta() ;
    if(pressPos == press_right)
    {
        if(event->delta() > 0) // 当滚轮向上滑
        {
            alf = alf < 0.0001 ? event->delta() / 120.0 :  qRound(qPow(1.2,qPow((event->delta() / 120.0) - 1, 1.3)) * alf);
            rightValue+=alf;
            rightValue = rightValue > maxValue ? maxValue : rightValue;
            rightValue = rightValue < minValue ? minValue : rightValue;
            emit valueChanged(leftValue, rightValue);
        }
        else // 当滚轮向下滑
        {
            //qDebug() <<"alf "<<alf ;
            alf = alf > -0.0001 ? event->delta() / 120.0 : qRound(qPow(1.2,qPow((-event->delta() / 120.0) - 1, 1.3)) * alf);
            rightValue+=alf;
            rightValue = rightValue > maxValue ? maxValue : rightValue;
            rightValue = rightValue < minValue ? minValue : rightValue;
            emit valueChanged(leftValue, rightValue);
        }
    }

    event->accept();
}

void HSliderRang::mouseMoveEvent(QMouseEvent* e)
{
	//指示器选中,并且坐标在范围值内,且不能超过另外指示器坐标
 if (rightPressed) {
		int mouseX = e->pos().x();
		int rectW = rect().width();
        int width = this->width() - 16;
        double increment = (double)width / (maxValue - minValue);
        int value = (e->pos().x() - 8) / increment + minValue;

        value = value > maxValue ? maxValue : value;
        value = value < minValue ? minValue : value;

        rightValue = value;
        emit valueChanged(leftValue, rightValue);
        update();

	}
	e->accept();
}

void HSliderRang::focusInEvent( QFocusEvent * event )
{
    //qDebug() << "Focus on the  HSliderRang";
    event->accept();
}

void HSliderRang::focusOutEvent( QFocusEvent * event )
{
    //qDebug() << "Focus out  the  HSliderRang";
    pressPos = press_center;
    event->accept();
}

void HSliderRang::paintEvent(QPaintEvent*)
{
	//绘制准备工作,启用反锯齿,平移坐标轴中心,等比例缩放
	QPainter painter(this);
	painter.setRenderHints(QPainter::Antialiasing | QPainter::TextAntialiasing);

	//绘制滑块背景
	drawSliderBg(&painter);

	//根据样式绘制滑块
	if (sliderStyle == SliderStyle_Line) {
		drawSliderLine(&painter);
	}
	else if (sliderStyle == SliderStyle_Circle) {
		drawSliderCircle(&painter);
	}

	//绘制当前值
	drawValue(&painter);
}


void HSliderRang::drawSliderBg(QPainter* painter)
{
	painter->save();

	int width = this->width();
	int height = this->height();
	int penWidth = height * ((double)sliderBgPercent / 10);
	int radius = penWidth / 2;

	//增加偏移量,是的边缘更加平滑
	int offset = 1;

	QPen pen;
	pen.setWidth(penWidth);
	pen.setColor(freeColor);
	pen.setCapStyle(Qt::RoundCap);

	painter->setPen(pen);
    painter->drawLine(radius + offset + 8, height / 2, width - radius - offset, height / 2);

	painter->restore();
}

void HSliderRang::drawSliderLine(QPainter* painter)
{
	painter->save();
	painter->setPen(Qt::NoPen);

	int width = this->width();
	int height = this->height();
	sliderLen = height * ((double)sliderPercent / 10);

	//计算每一格移动多少,然后计算左边指示器所在位置
	double increment = (double)width / (maxValue - minValue);
	int initY = 0;

	//计算左右滑块区域
	leftSliderRect = QRect(leftValue * increment, initY, sliderLen, height);
	rightSliderRect = QRect(rightValue * increment, initY, sliderLen, height);

	//绘制范围值
	int penWidth = height * ((double)sliderBgPercent / 10);

	painter->setBrush(usedColor);
	painter->drawRect(leftSliderRect.x(), (height - penWidth) / 2, rightSliderRect.x() - leftSliderRect.x(), penWidth);

	QPen pen = QPen();
	pen.setWidth(sliderLen);
	pen.setColor(usedColor);
	pen.setCapStyle(Qt::RoundCap);
	painter->setPen(pen);

	//绘制左边值指示器
	painter->drawLine(leftSliderRect.x(), sliderLen, leftSliderRect.x(), height - sliderLen);

	//绘制右边值指示器
	painter->drawLine(rightSliderRect.x(), sliderLen, rightSliderRect.x(), height - sliderLen);

	painter->restore();
}

void HSliderRang::drawSliderCircle(QPainter* painter)
{
	painter->save();
	painter->setPen(Qt::NoPen);

    int width = this->width() - 16;
	int height = this->height();
	sliderLen = height * ((double)sliderPercent / 10);

	//如果半径超过高度的一半,则说明超出范围,取高度的一半
	if (sliderLen >= height / 2) {
		sliderLen = height / 2 - 1;
	}

	//计算每一格移动多少,然后计算左边指示器所在位置
	double increment = (double)width / (maxValue - minValue);

	//计算初始坐标及圆半径
	int initY = (height - sliderLen * 2) / 2;
	int side = sliderLen * 2;
    QColor rightColor=QColor(208, 242, 216);
    //QColor DownColor=QColor(208, 242, 216);
    setBorderWidth(2);
    if(pressPos == press_right)
    {
        rightColor = usedColor;
        setBorderWidth(3);
    }

	int borderSide = side + borderWidth * 2;

	//计算左右滑块区域
	leftSliderRect = QRect(leftValue * side - sliderLen, initY, side, side);
    rightSliderRect = QRect(rightValue * increment - sliderLen + 8, initY, side, side);

	//绘制范围值
	int penWidth = height * ((double)sliderBgPercent / 10);
	painter->setBrush(usedColor);
	painter->drawRect(leftSliderRect.x() + sliderLen, (height - penWidth) / 2, rightSliderRect.x() - leftSliderRect.x(), penWidth);

	//绘制左边值指示器
	//painter->setBrush(borderColor);
	//painter->drawEllipse(leftSliderRect.x() - borderWidth, leftSliderRect.y() - borderWidth, borderSide, borderSide);
	//painter->setBrush(sliderColor);
	//painter->drawEllipse(leftSliderRect);

	//绘制右边值指示器
    painter->setBrush(rightColor);
	painter->drawEllipse(rightSliderRect.x() - borderWidth, rightSliderRect.y() - borderWidth, borderSide, borderSide);

	painter->setBrush(sliderColor);
	painter->drawEllipse(rightSliderRect);

	painter->restore();
}


void HSliderRang::drawValue(QPainter* painter)
{
	if (!showText) {
		return;
	}

	painter->save();

	//设置文字宽度
	QFont font;
	font.setPixelSize(leftSliderRect.width() / 1.6);
	painter->setFont(font);

	//设置文字颜色
	painter->setPen(textColor);

	//绘制左侧值
	painter->drawText(leftSliderRect, Qt::AlignCenter, QString::number(leftValue));
	//绘制右侧值
	painter->drawText(rightSliderRect, Qt::AlignCenter, QString::number(rightValue));

	painter->restore();
}

int HSliderRang::getMinValue() const
{
	return this->minValue;
}

int HSliderRang::getMaxValue() const
{
	return this->maxValue;
}

int HSliderRang::getLeftValue() const
{
	return this->leftValue;
}

int HSliderRang::getRightValue() const
{
	return this->rightValue;
}

int HSliderRang::getBorderWidth() const
{
	return this->borderWidth;
}

bool HSliderRang::getHorizontal() const
{
	return this->horizontal;
}

bool HSliderRang::getShowText() const
{
	return this->showText;
}

QColor HSliderRang::getUsedColor() const
{
	return this->usedColor;
}

QColor HSliderRang::getFreeColor() const
{
	return this->freeColor;
}

QColor HSliderRang::getTextColor() const
{
	return this->textColor;
}

QColor HSliderRang::getRangeTextColor() const
{
	return this->rangeTextColor;
}

QColor HSliderRang::getSliderColor() const
{
	return this->sliderColor;
}

QColor HSliderRang::getBorderColor() const
{
	return this->borderColor;
}

HSliderRang::SliderStyle HSliderRang::getSliderStyle() const
{
	return this->sliderStyle;
}

HSliderRang::SliderBgPercent HSliderRang::getSliderBgPercent() const
{
	return this->sliderBgPercent;
}

HSliderRang::SliderPercent HSliderRang::getSliderPercent() const
{
	return this->sliderPercent;
}

QSize HSliderRang::sizeHint() const
{
	return QSize(300, 50);
}

QSize HSliderRang::minimumSizeHint() const
{
	return QSize(10, 10);
}

void HSliderRang::setRange(int minValue, int maxValue, bool isEmit)
{
    AkUtil::TFunction("");
	//如果最小值大于或者等于最大值则不设置
	if (minValue >= maxValue) {
		return;
	}

	this->minValue = minValue;
	this->maxValue = maxValue;

	//如果目标值不在范围值内,则重新设置目标值
    setCurrentRange(minValue, maxValue,isEmit);


	update();
}

void HSliderRang::setMinValue(int minValue)
{
    //AkUtil::TFunction("");
	setRange(minValue, maxValue);
}

void HSliderRang::setMaxValue(int maxValue)
{
    //AkUtil::TFunction("");
	setRange(minValue, maxValue);
}

void HSliderRang::setCurrentRange(int leftValue, int rightValue, bool isEmit )
{
    //AkUtil::TFunction("");
	//左边值不能大于右边值
	if (leftValue > rightValue) {
		return;
	}

	//左边值不能小于最小值,右边值不能大于最大值
	if (leftValue < minValue || rightValue > maxValue) {
		return;
	}

	this->leftValue = leftValue;
	this->rightValue = rightValue;
    if(isEmit)
    {
	emit valueChanged(leftValue, rightValue);
    }
	update();
}

void HSliderRang::setLeftValue(int leftValue)
{
    //AkUtil::TFunction("");
	setCurrentRange(leftValue, rightValue);
}

void HSliderRang::setRightValue(int rightValue)
{
    //AkUtil::TFunction("");
	setCurrentRange(leftValue, rightValue);
}

void HSliderRang::setBorderWidth(int borderWidth)
{
    //AkUtil::TFunction("");
	if (this->borderWidth != borderWidth) {
		this->borderWidth = borderWidth;
		update();
	}
}

void HSliderRang::setHorizontal(bool horizontal)
{
    //AkUtil::TFunction("");
	if (this->horizontal != horizontal) {
		this->horizontal = horizontal;
		update();
	}
}

void HSliderRang::setShowText(bool showText)
{
    //AkUtil::TFunction("");
	if (this->showText != showText) {
		this->showText = showText;
		update();
	}
}

void HSliderRang::setUsedColor(const QColor& usedColor)
{
    //AkUtil::TFunction("");
	if (this->usedColor != usedColor) {
		this->usedColor = usedColor;
		update();
	}
}

void HSliderRang::setFreeColor(const QColor& freeColor)
{
    //AkUtil::TFunction("");
	if (this->freeColor != freeColor) {
		this->freeColor = freeColor;
		update();
	}
}

void HSliderRang::setTextColor(const QColor& textColor)
{
    //AkUtil::TFunction("");
	if (this->textColor != textColor) {
		this->textColor = textColor;
		update();
	}
}

void HSliderRang::setRangeTextColor(const QColor& rangeTextColor)
{
    //AkUtil::TFunction("");
	if (this->rangeTextColor != rangeTextColor) {
		this->rangeTextColor = rangeTextColor;
		update();
	}
}

void HSliderRang::setSliderColor(const QColor& sliderColor)
{
    //AkUtil::TFunction("");
	if (this->sliderColor != sliderColor) {
		this->sliderColor = sliderColor;
		update();
	}
}

void HSliderRang::setBorderColor(const QColor& borderColor)
{
    //AkUtil::TFunction("");
	if (this->borderColor != borderColor) {
		this->borderColor = borderColor;
		update();
	}
}

void HSliderRang::setSliderStyle(const HSliderRang::SliderStyle& sliderStyle)
{
    //AkUtil::TFunction("");
	if (this->sliderStyle != sliderStyle) {
		this->sliderStyle = sliderStyle;
		update();
	}
}

void HSliderRang::setSliderBgPercent(const HSliderRang::SliderBgPercent& sliderBgPercent)
{
    //AkUtil::TFunction("");
	if (this->sliderBgPercent != sliderBgPercent) {
		this->sliderBgPercent = sliderBgPercent;
		update();
	}
}

void HSliderRang::setSliderPercent(const HSliderRang::SliderPercent& sliderPercent)
{
    //AkUtil::TFunction("");
	if (this->sliderPercent != sliderPercent) {
		this->sliderPercent = sliderPercent;
		update();
	}
}

