/****************************************************************************
Revision 0.1  2021/12/08 12:00:40  Aden Hu
****************************************************************************/

#ifndef VIEWWIDGET_H
#define VIEWWIDGET_H
#include "common/GeoAndShow/SceneParam.h"
#include <QWidget>
#include <QLineEdit>
#include <QHBoxLayout>
#include <QGridLayout>
#include <QSpacerItem>
#include <QPushButton>
#include <QToolButton>
#include<QColorDialog>
#include <QGroupBox>
#include <QCheckBox>
#include <QLabel>
#include <QTimer>
#include <QSpinBox>
#include <QComboBox>
#include <QStackedLayout>
#include <QDateTime>
#include <QRemoteObjectNode>
#include <QRemoteObjectDynamicReplica>
//#include "slider/flatui.h"
//#include "slider/slider.h"
#include "ui_viewwidget.h"
#include "slider2/sliderrange_vertical.h"
#include "slider2/sliderrange_horizontal.h"
#include "common/controlInterface/switchbutton.h"
#include "common/controlInterface/progressdialog.h"
#include "common/Socket/QMainSocket2.h"
#include "gcode_label_edit.h"

namespace Ui
{
    class viewWidget;
}


enum featureType : uint8_t {
    innerWall,
    outerWall,
    skin,
    helper,
    fill,
    travel,
    support,
    unknown,
    Count
};

struct SliderLastValue
{
    int h_lastValue1 = -1;
    int h_lastValue2 = -1;
    int v_lastValue1 = -1;
    int v_lastValue2 = -1;
};

class viewWidget : public QWidget
{
    Q_OBJECT

protected:
    void closeEvent(QCloseEvent* event);
public:
    explicit  viewWidget(QWidget* parent, const SceneParam& param, bool pmode = false, QString hUrl = "local:tmp",bool imode = false);
    ~viewWidget();
    bool setToolPath(Anker::GCodeProcessor::Result&& gcode_result, std::string gcodePath, bool,int);

    void setSceneParams(const SceneParam& param);

    void reSetGcodePath(std::string gcodePath, bool,int);
    void setDefaultScene();

protected:
    virtual void paintEvent(QPaintEvent* event);
    virtual void resizeEvent(QResizeEvent* event);
    void changeEvent(QEvent * event) Q_DECL_OVERRIDE;
    void wheelEvent(QWheelEvent* event) Q_DECL_OVERRIDE;
private:
    Ui::viewWidget* ui;
    SliderLastValue m_sliderLastValue;
public slots:
    void setOriginalStlName(const QString& oStlName);
    void setAimode(bool _isAimode);
private slots:
    void initForm();

    void setSavePicTrue();
    void setExportPic();
    void verticalSliderValueChanged(int, int);
    void horizontalSliderValueChanged(int, int);
    void onFrontView();
    void onBackView();
    void onLeftView();
    void onRightView();
    void onTopView();
    void onBottomView();
    void onJustView();
    void msgFromFdmGcodePaser(QString);
    void palyView();
    void on_pushButton_quit_clicked();
    void innerWallcheckButton();//erPerimeter
    void outerWallcheckButton();//erExternalPerimeter
    void skincheckButton();//erSkirt
    void helpercheckButton();//erInternalInfill
    void fillcheckButton();//erSolidInfill
    void zlapcheckButton();
    void travelcheckButton();//
    void supportcheckButton();
    void unkonwncheckButton();
    void updatePlayViewer();
    void spinBoxUpValueChanged(int);
#ifdef USE_EXTRA_UI
    void linetypeComboxChange(int);
#endif
    void spinBoxDownValueChanged(int);
    void colorChanged();
    void buttonVisible(qint64,int);
    void displayDeviceListWidgetFeedbackSLOT(qint64, int);
    void stateChangedSlot(QRemoteObjectDynamicReplica::State state, QRemoteObjectDynamicReplica::State oldState);

    void onMsgFromFdmGcodePaser(const QString &msg);
    void connectedRPC();
    void paramChange(QVariant p);
//    void rpc_setValue(int);
signals:
    void checkoutPreviewEvent(bool);
    //void setValue(int);
    //void startOffRender(const QString& savePath,bool isAiMode,bool cancel);
public:
    void changeSlider();
    void getFilamentCount();
    void setFilamentStr();
    void getTimeCount();
    void setTimeStr();
    void getGcodeSize();
    void setGcodeSize();
    void setPerformance(bool);


    GcodeViewer* getGcodeView(){return this->ui->openGLWidget;};
    QString getTimesDhms(float timeInSecs);
    //QWidget* widget;
    VSliderRange* verticalSlider;
    HSliderRang* horizontalSlider;
    QPushButton* ExitButton;
    QPushButton* ExportButton;
    QSharedPointer<QRemoteObjectDynamicReplica> m_rpc;
    QRemoteObjectNode *m_node = nullptr;
    QString oStlName;

    //打印控制界面开关
    bool printMode = false;
    //inner mode
    bool innerMode = false;
private:
    //bool offRenderLock = false;
    bool isHighPerformance = true;
    QString saveTempPath ;
    QMainSocket2* qs;
#ifdef USE_EXTRA_UI
    QComboBox *linetypeCombox;
#endif
    QStackedLayout* typeLayout;

    QHBoxLayout *innerWallLayout; //内墙走线布局
    QPushButton *innerWallLabelC; //显示内墙走线颜色的静态框
    QLabel *innerWallLabel;//内墙走线名字
    QSpacerItem *horizontalSpacer_innerWall;//
    SwitchButton *innerWallcheckBox; //内墙走线checkBox


    QHBoxLayout *outerWallLayout; //内墙走线布局
    QPushButton *outerWallLabelC; //显示内墙走线颜色的静态框
    QLabel *outerWallLabel;//内墙走线名字
    QSpacerItem *horizontalSpacer_outerWall;//
    SwitchButton *outerWallcheckBox; //内墙走线checkBox



    QHBoxLayout *skinLayout; //内墙走线布局
    QPushButton *skinLabelC; //显示内墙走线颜色的静态框
    QLabel *skinLabel;//内墙走线名字
    QSpacerItem *horizontalSpacer_skin;//
    SwitchButton *skincheckBox; //内墙走线checkBox



    QHBoxLayout *helperLayout; //内墙走线布局
    QPushButton *helperLabelC; //显示内墙走线颜色的静态框
    QLabel *helperLabel;//内墙走线名字
    QSpacerItem *horizontalSpacer_helper;//
    SwitchButton *helpercheckBox; //内墙走线checkBox



    QHBoxLayout *fillLayout; //内墙走线布局
    QPushButton *fillLabelC; //显示内墙走线颜色的静态框
    QLabel *fillLabel;//内墙走线名字
    QSpacerItem *horizontalSpacer_fill;//
    SwitchButton *fillcheckBox; //内墙走线checkBox



    QHBoxLayout *travelLayout; //内墙走线布局
    QPushButton *travelLabelC; //显示内墙走线颜色的静态框
    QLabel *travelLabel;//内墙走线名字
    QSpacerItem *horizontalSpacer_travel;//
    SwitchButton *travelcheckBox; //内墙走线checkBox



    QHBoxLayout *supportLayout; //内墙走线布局
    QPushButton *supportLabelC; //显示内墙走线颜色的静态框
    QLabel *supportLabel;//内墙走线名字
    QSpacerItem *horizontalSpacer_support;//
    SwitchButton *supportcheckBox; //内墙走线checkBox



    QHBoxLayout *unkonwnLayout; //内墙走线布局
    QPushButton *unkonwnLabelC; //显示内墙走线颜色的静态框
    QLabel *unkonwnLabel;//内墙走线名字
    QSpacerItem *horizontalSpacer_unkonwn;//
    SwitchButton *unkonwncheckBox; //内墙走线checkBox

    QHBoxLayout *zlapLayout;
    QPushButton *zlapLabelC;
    QLabel *zlapLabel;
    QSpacerItem *horizontalSpacer_zlap;//
    SwitchButton *zlapcheckBox;



#ifdef USE_EXTRA_UI

    QHBoxLayout *innerWallLayout_speed; //内墙走线布局
    QLabel *innerWallLabel_speed;//内墙走线名字
    QSpacerItem *horizontalSpacer_innerWall_speed;//
    SwitchButton *innerWallcheckBox_speed; //内墙走线checkBox
    QHBoxLayout *outerWallLayout_speed; //内墙走线布局
    QLabel *outerWallLabel_speed;//内墙走线名字
    QSpacerItem *horizontalSpacer_outerWall_speed;//
    SwitchButton *outerWallcheckBox_speed; //内墙走线checkBox

    QHBoxLayout *skinLayout_speed; //内墙走线布局
    QLabel *skinLabel_speed;//内墙走线名字
    QSpacerItem *horizontalSpacer_skin_speed;//
    SwitchButton *skincheckBox_speed; //内墙走线checkBox
    QHBoxLayout *helperLayout_speed; //内墙走线布局
    QLabel *helperLabel_speed;//内墙走线名字
    QSpacerItem *horizontalSpacer_helper_speed;//
    SwitchButton *helpercheckBox_speed; //内墙走线checkBox
    QHBoxLayout *fillLayout_speed; //内墙走线布局
    QLabel *fillLabel_speed;//内墙走线名字
    QSpacerItem *horizontalSpacer_fill_speed;//
    SwitchButton *fillcheckBox_speed; //内墙走线checkBox
    QHBoxLayout *travelLayout_speed; //内墙走线布局
    QLabel *travelLabel_speed;//内墙走线名字
    QSpacerItem *horizontalSpacer_travel_speed;//
    SwitchButton *travelcheckBox_speed; //内墙走线checkBox
    QHBoxLayout *supportLayout_speed; //内墙走线布局
    QLabel *supportLabel_speed;//内墙走线名字
    QSpacerItem *horizontalSpacer_support_speed;//
    SwitchButton *supportcheckBox_speed; //内墙走线checkBox
    QHBoxLayout *unkonwnLayout_speed; //内墙走线布局
    QLabel *unkonwnLabel_speed;//内墙走线名字
    QSpacerItem *horizontalSpacer_unkonwn_speed;//
    SwitchButton *unkonwncheckBox_speed; //内墙走线checkBox
    /////
    QHBoxLayout *innerWallLayout_trapezoid; //内墙走线布局
    QLabel *innerWallLabel_trapezoid;//内墙走线名字
    QSpacerItem *horizontalSpacer_innerWall_trapezoid;//
    SwitchButton *innerWallcheckBox_trapezoid; //内墙走线checkBox

    QHBoxLayout *outerWallLayout_trapezoid; //内墙走线布局
    QLabel *outerWallLabel_trapezoid;//内墙走线名字
    QSpacerItem *horizontalSpacer_outerWall_trapezoid;//
    SwitchButton *outerWallcheckBox_trapezoid; //内墙走线checkBox

    QHBoxLayout *skinLayout_trapezoid; //内墙走线布局
    QLabel *skinLabel_trapezoid;//内墙走线名字
    QSpacerItem *horizontalSpacer_skin_trapezoid;//
    SwitchButton *skincheckBox_trapezoid; //内墙走线checkBox

    QHBoxLayout *helperLayout_trapezoid; //内墙走线布局
    QLabel *helperLabel_trapezoid;//内墙走线名字
    QSpacerItem *horizontalSpacer_helper_trapezoid;//
    SwitchButton *helpercheckBox_trapezoid; //内墙走线checkBox

    QHBoxLayout *fillLayout_trapezoid; //内墙走线布局
    QLabel *fillLabel_trapezoid;//内墙走线名字
    QSpacerItem *horizontalSpacer_fill_trapezoid;//
    SwitchButton *fillcheckBox_trapezoid; //内墙走线checkBox

    QHBoxLayout *travelLayout_trapezoid; //内墙走线布局
    QLabel *travelLabel_trapezoid;//内墙走线名字
    QSpacerItem *horizontalSpacer_travel_trapezoid;//
    SwitchButton *travelcheckBox_trapezoid; //内墙走线checkBox

    QHBoxLayout *supportLayout_trapezoid; //内墙走线布局
    QLabel *supportLabel_trapezoid;//内墙走线名字
    QSpacerItem *horizontalSpacer_support_trapezoid;//
    SwitchButton *supportcheckBox_trapezoid; //内墙走线checkBox

    QHBoxLayout *unkonwnLayout_trapezoid; //内墙走线布局
    QLabel *unkonwnLabel_trapezoid;//内墙走线名字
    QSpacerItem *horizontalSpacer_unkonwn_trapezoid;//
    SwitchButton *unkonwncheckBox_trapezoid; //内墙走线checkBox

    ///

    /////
       QHBoxLayout *innerWallLayout_Flow; //内墙走线布局
       QLabel *innerWallLabel_Flow;//内墙走线名字
       QSpacerItem *horizontalSpacer_innerWall_Flow;//
       SwitchButton *innerWallcheckBox_Flow; //内墙走线checkBox

       QHBoxLayout *outerWallLayout_Flow; //内墙走线布局
       QLabel *outerWallLabel_Flow;//内墙走线名字
       QSpacerItem *horizontalSpacer_outerWall_Flow;//
       SwitchButton *outerWallcheckBox_Flow; //内墙走线checkBox

       QHBoxLayout *skinLayout_Flow; //内墙走线布局
       QLabel *skinLabel_Flow;//内墙走线名字
       QSpacerItem *horizontalSpacer_skin_Flow;//
       SwitchButton *skincheckBox_Flow; //内墙走线checkBox

       QHBoxLayout *helperLayout_Flow; //内墙走线布局
       QLabel *helperLabel_Flow;//内墙走线名字
       QSpacerItem *horizontalSpacer_helper_Flow;//
       SwitchButton *helpercheckBox_Flow; //内墙走线checkBox

       QHBoxLayout *fillLayout_Flow; //内墙走线布局
       QLabel *fillLabel_Flow;//内墙走线名字
       QSpacerItem *horizontalSpacer_fill_Flow;//
       SwitchButton *fillcheckBox_Flow; //内墙走线checkBox

       QHBoxLayout *travelLayout_Flow; //内墙走线布局
       QLabel *travelLabel_Flow;//内墙走线名字
       QSpacerItem *horizontalSpacer_travel_Flow;//
       SwitchButton *travelcheckBox_Flow; //内墙走线checkBox

       QHBoxLayout *supportLayout_Flow; //内墙走线布局
       QLabel *supportLabel_Flow;//内墙走线名字
       QSpacerItem *horizontalSpacer_support_Flow;//
       SwitchButton *supportcheckBox_Flow; //内墙走线checkBox

       QHBoxLayout *unkonwnLayout_Flow; //内墙走线布局
       QLabel *unkonwnLabel_Flow;//内墙走线名字
       QSpacerItem *horizontalSpacer_unkonwn_Flow;//
       SwitchButton *unkonwncheckBox_Flow; //内墙走线checkBox

       QLabel* colorPatch_label_start_trapezoid;
       QLabel* colorPatch_label_end_trapezoid;
       ///
       QLabel* colorPatch_label_start;
       QLabel* colorPatch_label_end;
       QLabel* colorPatch_label_start_Flow;
       QLabel* colorPatch_label_end_Flow;
#endif

    QLabel* filamentValue;
    QLabel* timeValue;

    QLabel* allTimeLabel;
    QLabel* allfilamentLabel;
    QLabel* allSizeLabel;

    gcodeLabelEdit* spinBox_2;//up
    gcodeLabelEdit* spinBox;//down

    QTimer* mPlayTimer = nullptr;
    QPushButton* pushButton_9; //paly view button

    std::array<double, featureType::Count> showLabelCount{ 0 };
    std::array<float, featureType::Count> showTimeLabelCount{ 0 };
    std::array<int, 3> showAllSize{ 0 };
    SceneParam m_sceneParam;
    bool isAiMode = false;
    int runTimesId;
    const qint64 qs_id = QDateTime::currentSecsSinceEpoch();
    ProgressDialog *m_progessDlg;
private:
    QColorDialog* colorDlg;
    const std::map<uint8_t, QString> roleDict = {
    {ExtrusionRole::erNone ,"unkonwnLabelC"},
    {ExtrusionRole::erPerimeter,"innerWallLabelC"},
    {ExtrusionRole::erExternalPerimeter,"outerWallLabelC"},
    {ExtrusionRole::erOverhangPerimeter ,"unkonwnLabelC"},
    {ExtrusionRole::erInternalInfill ,"fillLabelC"},
    {ExtrusionRole::erSolidInfill,"skinLabelC"},
    {ExtrusionRole::erTopSolidInfill,"unkonwnLabelC"},
    {ExtrusionRole::erIroning,"unkonwnLabelC"},
    {ExtrusionRole::erBridgeInfill,"unkonwnLabelC"},
    {ExtrusionRole::erInternalBridgeInfill,"unkonwnLabelC"},
    {ExtrusionRole::erThinWall,"unkonwnLabelC"},
    {ExtrusionRole::erGapFill,"unkonwnLabelC"},
    {ExtrusionRole::erSkirt,"helperLabelC"},
    {ExtrusionRole::erSupportMaterial,"supportLabelC"},
    {ExtrusionRole::erSupportMaterialInterface,"supportLabelC"},
    {ExtrusionRole::erWipeTower,"helperLabelC"},
    {ExtrusionRole::erMilling,"unkonwnLabelC"},
    {ExtrusionRole::erCustom,"unkonwnLabelC"},
    {ExtrusionRole::erMixed,"unkonwnLabelC"}
    };

    const std::map<QString, QColor> colorDict = {
        {"innerWallLabelC" ,{80, 99, 92}},
        {"outerWallLabelC" ,{255, 144, 82}},
        {"skinLabelC" ,{97, 211, 125}},
        {"helperLabelC" ,{71, 143, 255}},
        {"fillLabelC" ,{138, 76, 216}},
        {"travelLabelC" ,{91, 207, 207}},
#ifdef USE_EXTRA_UI
        {"zlapLabelC" ,{91, 207, 207}},
#endif
        {"supportLabelC" ,{249, 211, 86}},
        {"unkonwnLabelC" ,{255, 105, 105}}
    };

    std::map<QString, int> labelIndexDict = {
        {"innerWallLabelC" ,0},
        {"outerWallLabelC" ,1},
        {"skinLabelC"      ,2},
        {"helperLabelC"    ,3},
        {"fillLabelC"      ,4},
        {"travelLabelC"    ,5},
#ifdef USE_EXTRA_UI
        {"zlapLabelC"      ,6},
        {"supportLabelC"   ,7},
        {"unkonwnLabelC"   ,8}
#else
        {"supportLabelC"   ,6},
        {"unkonwnLabelC"   ,7}
#endif

    };
};



#endif // !VIEWWIDGET_H
