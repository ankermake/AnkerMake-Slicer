#ifndef PROCESS_AI_PICTURE_H
#define PROCESS_AI_PICTURE_H
#include <iostream>
#include <fstream>
using namespace std;
//文件头(固定128 bytes长度)
union fileHead{
    char a[128] = {0};
    struct {
        unsigned int  magic;                //0x3DA13DA1
        unsigned int  crc32;                //从version_num开始到文件结束
        unsigned int  version_num;          //版本号(从01开始)
        unsigned int  total_picture;        //总图片数
        unsigned int  total_layer;          //总层数
        unsigned int  file_size;            //总文件大小
        char relate_gcode_name[64];         //关联的G Code文件名称
    };
};

//文件头(固定128 bytes长度)
union imageHead{
    char a[64] = {0};
    struct {
        float         percentage;        //当前百分比  、
        unsigned int  layer_num;         //当前层号
        unsigned int  file_size;         //图件文件大小
        float         roi_info[4];       //roi 信息
        char name[32];                   //图件文件名称
    };
};

struct imgInfo
{
    char* data;
    size_t size;
};

class processAiPicture
{
    ofstream m_outFile;
    fileHead m_head;
public:
    processAiPicture(std::string fileName,unsigned int totalLayers, unsigned int total_picture);
    ~processAiPicture();
    void writeImage(imageHead iHead,imgInfo iInfo);

};

#endif // PROCESS_AI_PICTURE_H
