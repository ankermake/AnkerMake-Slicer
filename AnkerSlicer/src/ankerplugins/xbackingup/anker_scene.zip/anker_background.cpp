/****************************************************************************
* MeshLab                                                           o o     *
* A versatile mesh processing toolbox                             o     o   *
*                                                                _   O  _   *
* Copyright(C) 2005                                                \/)\/    *
* Visual Computing Lab                                            /\/|      *
* ISTI - Italian National Research Council                           |      *
*                                                                    \      *
* All rights reserved.                                                      *
*                                                                           *
* This program is free software; you can redistribute it and/or modify      *
* it under the terms of the GNU General Public License as published by      *
* the Free Software Foundation; either version 2 of the License, or         *
* (at your option) any later version.                                       *
*                                                                           *
* This program is distributed in the hope that it will be useful,           *
* but WITHOUT ANY WARRANTY; without even the implied warranty of            *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
* GNU General Public License (http://www.gnu.org/licenses/gpl.txt)          *
* for more details.                                                         *
*                                                                           *
****************************************************************************/
#include "anker_background.h"


SceneBackground::SceneBackground(const GLArea* area, const RichParameterList* rParamList)
	: gla(const_cast<GLArea*>(area)), rps(const_cast<RichParameterList*>(rParamList))
{
}

SceneBackground::~SceneBackground()
{
}

void SceneBackground::setParamColor(const QColor &color, const QString& name)
{
    if (rps == NULL || gla == NULL)
    {
        return;
    }

    ColorValue cv(color);
    RichParameter& rp = rps->getParameterByName(name);
    rp.setValue(cv);
    updateCustomSettingValues();
}

void SceneBackground::backgroundBotColor(const QColor &color)
{
    
}

void SceneBackground::backgroundTopColor(const QColor& color)
{

}


void SceneBackground::baseLightAmbientColor(const QColor& color)
{

}

void SceneBackground::baseLightDiffuseColor(const QColor& color)
{

}

void SceneBackground::baseLightSpecularColor(const QColor& color)
{

}

void SceneBackground::logAreaColor(const QColor& color)
{

}

void SceneBackground::updateCustomSettingValues()
{
    if (rps == NULL || gla == NULL)
    {
        return;
    }

    gla->makeCurrent();

    gla->glas.logAreaColor = rps->getColor4b(gla->glas.logAreaColorParam());
    gla->glas.backgroundBotColor = rps->getColor4b(gla->glas.backgroundBotColorParam());
    gla->glas.backgroundTopColor = rps->getColor4b(gla->glas.backgroundTopColorParam());

    gla->glas.baseLightAmbientColor = rps->getColor4b(gla->glas.baseLightAmbientColorParam());
    gla->glas.baseLightDiffuseColor = rps->getColor4b(gla->glas.baseLightDiffuseColorParam());
    gla->glas.baseLightSpecularColor = rps->getColor4b(gla->glas.baseLightSpecularColorParam());

    gla->glas.fancyBLightDiffuseColor = rps->getColor4b(gla->glas.fancyBLightDiffuseColorParam());
    gla->glas.fancyFLightDiffuseColor = rps->getColor4b(gla->glas.fancyFLightDiffuseColorParam());

    gla->glas.textureMinFilter = rps->getEnum(gla->glas.textureMinFilterParam());
    gla->glas.textureMagFilter = rps->getEnum(gla->glas.textureMagFilterParam());

    gla->glas.pointDistanceAttenuation = rps->getBool(gla->glas.pointDistanceAttenuationParam());
    gla->glas.pointSmooth = rps->getBool(gla->glas.pointSmoothParam());
    gla->glas.pointSize = rps->getFloat(gla->glas.pointSizeParam());
    gla->glas.wheelDirection = rps->getBool(gla->glas.wheelDirectionParam());
    gla->glas.matrixDecimalPrecision = rps->getInt(gla->glas.matrixDecimalPrecisionParam());
    gla->glas.currentGlobalParamSet = rps;

    gla->update();
}
