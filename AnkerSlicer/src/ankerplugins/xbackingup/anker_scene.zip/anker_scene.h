/****************************************************************************
* MeshLab                                                           o o     *
* A versatile mesh processing toolbox                             o     o   *
*                                                                _   O  _   *
* Copyright(C) 2005                                                \/)\/    *
* Visual Computing Lab                                            /\/|      *
* ISTI - Italian National Research Council                           |      *
*                                                                    \      *
* All rights reserved.                                                      *
*                                                                           *
* This program is free software; you can redistribute it and/or modify      *
* it under the terms of the GNU General Public License as published by      *
* the Free Software Foundation; either version 2 of the License, or         *
* (at your option) any later version.                                       *
*                                                                           *
* This program is distributed in the hope that it will be useful,           *
* but WITHOUT ANY WARRANTY; without even the implied warranty of            *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
* GNU General Public License (http://www.gnu.org/licenses/gpl.txt)          *
* for more details.                                                         *
*                                                                           *
****************************************************************************/
/****************************************************************************
Revision 0.1  2021/10/22 10:38:03  Aden Hu
****************************************************************************/

#ifndef ANKER_SCENE_PLUGIN_H
#define ANKER_SCENE_PLUGIN_H

#include <QObject>
#include <QAction>
#include <QList>
#include <QMenu>
#include <QMainWindow>
#include <QMenubar>
#include <QHBoxLayout>
#include "common/plugins/interfaces/decorate_plugin.h"
#include "common/ml_shared_data_context/ml_scene_gl_shared_data_context.h"
#include "meshlab/additionalgui.h"
#include "anker_perspective.h"
#include "anker_world_coordinate.h"
#include "anker_background.h"
#include "side_show.h"
#define RICHPARAMETER_STR tr("Show Rich Parameter List")
#define LOGSTREAM_STR tr("Show Log Stream")
#define IMPORT_PEDESTAL_STR tr("Import Pedestal")

#define SHOW_NORMAL_STR tr("Show Normal")
#define SHOW_THRESHOLD_STR tr("Show Threshold Render")

#define SHOW_POINTS_RENDER_STR tr("Show Points Render")
#define SHOW_WIREFRAME_RENDER_STR tr("Show WireFrame Render")
#define SHOW_VERT_RENDER_STR tr("Show Vert Render")
#define SHOW_FACE_RENDER_STR tr("Show Face Render")

struct MyPlane
{
    MyPlane()
    {

    }
    MyPlane(const vcg::Point3f& P1, const vcg::Point3f& P2, const vcg::Point3f& P3, const vcg::Point3f& P4)
        : p1(P1), p2(P2), p3(P3), p4(P4)
    {

    }

    MyPlane& operator=(const MyPlane& pln) 
    {
        p1 = pln.p1;
        p2 = pln.p2;
        p3 = pln.p3;
        p4 = pln.p4;

        return *this;
    }


    vcg::Point3f p1, p2, p3, p4;
};

class AnkerScenePlugin : public QObject, public DecoratePlugin
{
    Q_OBJECT
        MESHLAB_PLUGIN_IID_EXPORTER(DECORATE_PLUGIN_IID)
        Q_INTERFACES(DecoratePlugin)
        QString decorationName(ActionIDType id) const;
    QString decorationInfo(ActionIDType id) const;
    QString pluginName() const;

    //perspective projection
    //Preview the perspective
    enum  ViewType {
        DP_SHOW_FRONT = 0x00020,
        DP_SHOW_BACK = 0x00021,
        DP_SHOW_RIGHT = 0x00022,
        DP_SHOW_LEFT = 0x00023,
        DP_SHOW_TOP = 0x00024,
        DP_SHOW_BOTTOM = 0x00025,
        DP_SHOW_THREED = 0x00026,

        DP_SHOW_TOP_Z_IS_UP = 0x00027,
        DP_SHOW_BOTTOM_Z_IS_UP = 0x00028,
        DP_SHOW_LEFT_Z_IS_UP = 0x00029,
        DP_SHOW_RIGHT_Z_IS_UP = 0x0002A,
        DP_SHOW_FRONT_Z_IS_UP = 0x0002B,
        DP_SHOW_BACK_Z_IS_UP = 0x0002C,

        DP_SHOW_HORIZONTAL_PLUS = 0x00030,
        DP_SHOW_HORIZONTAL_SUBTRACT = 0x00031,
        DP_SHOW_VERTICAL_PLUS = 0x00032,
        DP_SHOW_VERTICAL_SUBTRACT = 0x00033,
        DP_SHOW_AXIAL_PLUS = 0x00034,
        DP_SHOW_AXIAL_SUBTRACT = 0x00035,

        DP_SHOW_THRESHOLD = 0x00036,

        DP_SHOW_TOGGLE = 0x00040,
        DP_SHOW_SETPARAMETER = 0x00041,
        DP_SHOW_LOGSTREAM = 0x00042,

        DP_SHOW_PERSPECTIVE_PROJECTION = 0x00043,
        DP_SHOW_PARALLERL_PROJECTION = 0x00044,
    };

    enum CoordinateType {
        DP_SHOW_WORLD_COORDINATE = 0x00050,
        DP_SHOW_LOCAL_COORDINATE = 0x00051,

        DP_SHOW_WORLD_BBOX = 0x00052,
        DP_SHOW_LOACL_BBOX = 0x00053,

        DP_SHOW_IMPORT_PEDESTAL = 0x00054,

        DP_SHOW_NORMAL = 0x00055,
    };

    enum RenderType {
        DP_SHOW_POINTS_RENDER = 0x00060,
        DP_SHOW_WIREFRAME_RENDER = 0x00061,
        DP_SHOW_VERT_RENDER = 0x00062,
        DP_SHOW_FACE_RENDER = 0x00063,
    };

    inline QString WorldCoordParam() const { return  "MeshLab::Decoration::WorldCoord"; }
    inline QString AnkerSceneParam() const { return "MeshLab::Decoration::AnkerScene"; }
    inline QString PerspectiveParam() const { return "MeshLab::Decoration::Perspective"; }

public:
    AnkerScenePlugin()
    {
        typeList
            << DP_SHOW_FRONT
            << DP_SHOW_BACK
            << DP_SHOW_RIGHT
            << DP_SHOW_LEFT
            << DP_SHOW_TOP
            << DP_SHOW_BOTTOM
            << DP_SHOW_THREED

            << DP_SHOW_TOP_Z_IS_UP
            << DP_SHOW_BOTTOM_Z_IS_UP
            << DP_SHOW_LEFT_Z_IS_UP
            << DP_SHOW_RIGHT_Z_IS_UP
            << DP_SHOW_FRONT_Z_IS_UP
            << DP_SHOW_BACK_Z_IS_UP

            << DP_SHOW_HORIZONTAL_PLUS
            << DP_SHOW_HORIZONTAL_SUBTRACT
            << DP_SHOW_VERTICAL_PLUS
            << DP_SHOW_VERTICAL_SUBTRACT
            << DP_SHOW_AXIAL_PLUS
            << DP_SHOW_AXIAL_SUBTRACT

            << DP_SHOW_TOGGLE

            << DP_SHOW_SETPARAMETER

            << DP_SHOW_LOGSTREAM

            << DP_SHOW_WORLD_COORDINATE
            << DP_SHOW_LOCAL_COORDINATE
            << DP_SHOW_WORLD_BBOX
            << DP_SHOW_LOACL_BBOX

            << DP_SHOW_PERSPECTIVE_PROJECTION
            << DP_SHOW_PARALLERL_PROJECTION

            << DP_SHOW_IMPORT_PEDESTAL
            << DP_SHOW_NORMAL
            << DP_SHOW_THRESHOLD

            << DP_SHOW_POINTS_RENDER
            << DP_SHOW_WIREFRAME_RENDER
            << DP_SHOW_VERT_RENDER
            << DP_SHOW_FACE_RENDER;


        for (ActionIDType tt : types()) {
            actionList << new QAction(decorationName(tt), this);
            if (tt == DP_SHOW_IMPORT_PEDESTAL)
            {

            }
        }
    }

    QList<QAction*> actions() const { return actionList; }
    QString ankerSceneFileName;
    bool startDecorate(const QAction* /*mode*/, MeshDocument&/*m*/, const RichParameterList* /*parent*/ par, GLArea* /*parent*/);
    void decorateDoc(const QAction* a, MeshDocument& md, const RichParameterList*, GLArea* gla, QPainter*, GLLogStream& _log);
    void decorateMesh(const QAction*, MeshModel&, const RichParameterList*, GLArea*, QPainter*, GLLogStream&) {}
    void initGlobalParameterList(const QAction*, RichParameterList&/*globalparam*/);
    int getDecorationClass(const QAction* /*action*/) const { return DecoratePlugin::PerDocument; }
    void endDecorate(const QAction*, MeshDocument&, const RichParameterList*, GLArea*);


public:
    void recMsgfromManager(PluginMessageData);
    void initialize(ControlInterface* controlmanager, RichParameterList* globalParameterList);

    void drawCurrentModelBox(MeshModel& model);
    void drawCurrentModelBox(const MeshModel& model, float width, float boxSize, const QColor& color);

    void setModelColor(GLArea*, MeshModel&, vcg::Color4b);

    void drawBBox(const Box3m&, const GLfloat* Xrgb, const GLfloat* Yrgb, const GLfloat* Zrgb, GLfloat lineWidth, float boxSize, bool isSceneBox = false);

    void initPluginGui(QMainWindow*);

    void addActionToMenu(QMenu*);

    void setView(GLArea*/*gla*/, PerspectiveType /*type*/, const QString& /*dir*/);

    void setSceneBox(const vcg::Box3f& box, GLfloat d/*盒底中心面边缘到盒子边的长度*/);

    void setSceneCenterPlane(const MyPlane& plane);

    void setSceneBoxLineColor(const GLfloat* color);

    void sideShow(const SideShow::SideShowType type, GLArea* gla, MeshModel& model, const MLPerViewGLOptions& opts);

    void suggestedRenderingData(MeshModel& m, MLRenderingData& dt);

    inline void updateColorBuffer(MeshModel& m, MLSceneGLSharedDataContext* shared)
    {
        if (shared != NULL)
        {
            MLRenderingData::RendAtts atts;
            //atts[MLRenderingData::ATT_NAMES::ATT_VERTCOLOR] = true;
            atts[MLRenderingData::ATT_NAMES::ATT_FACECOLOR] = true;
            shared->meshAttributesUpdated(m.id(), false, atts);
        }
    }

    //阈值渲染，给一个阈值支撑角度值范围，染红色
    void thresholdRender(GLArea* gla, MeshModel* mm, float theta1, float theta2);

    inline void updateGeometryBuffers(MeshModel& m, MLSceneGLSharedDataContext* shared)
    {
        if (shared != NULL)
        {
            MLRenderingData::RendAtts atts;
            atts[MLRenderingData::ATT_NAMES::ATT_VERTPOSITION] = true;
            atts[MLRenderingData::ATT_NAMES::ATT_VERTNORMAL] = true;
            atts[MLRenderingData::ATT_NAMES::ATT_FACENORMAL] = true;
            shared->meshAttributesUpdated(m.id(), false, atts);
        }
    }

    //工程load/Save虚接口
    virtual bool needSaveProject()
    {
        return true;
    }
    virtual bool saveProject(const QString& proPath)
    {
        return false;
    }
    virtual bool needLoadProject()
    {
        return true;
    }
    virtual bool loadProject(const QString& proPath)
    {
        return false;
    }

signals:
    void sendMsg2Manager(PluginMessageData);


private:

    vcg::Box3f sceneBox; //场景的盒子

    MyPlane sceneCenterPln;//盒底中心放模型的平面
    GLfloat div;//盒底中心面边缘到盒子边的长度
    GLfloat tick;//盒子底部小网格宽度
    GLfloat sceneBoxLineColor[3];//场景盒子线颜色

    MLRenderingData defaultMLRender;
};
#endif
