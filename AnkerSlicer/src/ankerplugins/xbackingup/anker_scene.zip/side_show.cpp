/****************************************************************************
* MeshLab                                                           o o     *
* A versatile mesh processing toolbox                             o     o   *
*                                                                _   O  _   *
* Copyright(C) 2005                                                \/)\/    *
* Visual Computing Lab                                            /\/|      *
* ISTI - Italian National Research Council                           |      *
*                                                                    \      *
* All rights reserved.                                                      *
*                                                                           *
* This program is free software; you can redistribute it and/or modify      *
* it under the terms of the GNU General Public License as published by      *
* the Free Software Foundation; either version 2 of the License, or         *
* (at your option) any later version.                                       *
*                                                                           *
* This program is distributed in the hope that it will be useful,           *
* but WITHOUT ANY WARRANTY; without even the implied warranty of            *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
* GNU General Public License (http://www.gnu.org/licenses/gpl.txt)          *
* for more details.                                                         *
*                                                                           *
****************************************************************************/
#include "side_show.h"
#include <QDebug>

#define PI 3.1415926535898

SideShow::SideShow(const SideShowType type, GLArea* gla, MeshModel& model, const MLPerViewGLOptions& opts) :
	m_type(type), m_gla(gla), m_model(model), m_opts(opts)
{
	setCurrentModelMLPerViewGLOptions();
}

SideShow::~SideShow()
{

}

void SideShow::update()
{
	if (m_gla == NULL)
		return;
	if ((m_gla->md() != NULL) && (m_gla->md()->mm() != NULL))
	{
		updateColorBuffer(m_model, m_gla->mvc()->sharedDataContext());
		updateGeometryBuffers(m_model, m_gla->mvc()->sharedDataContext());
		m_gla->mvc()->sharedDataContext()->manageBuffers(m_model.id());
	}
	m_gla->updateAllSiblingsGLAreas();
	m_gla->update();
}

void SideShow::updateColorBuffer(MeshModel& m, MLSceneGLSharedDataContext* shared)
{
	if (shared != NULL)
	{
		MLRenderingData::RendAtts atts;
		atts[MLRenderingData::ATT_NAMES::ATT_VERTCOLOR] = true;
		shared->meshAttributesUpdated(m.id(), false, atts);
	}
}

void SideShow::updateGeometryBuffers(MeshModel& m, MLSceneGLSharedDataContext* shared)
{
	if (shared != NULL)
	{
		MLRenderingData::RendAtts atts;
		atts[MLRenderingData::ATT_NAMES::ATT_VERTPOSITION] = true;
		atts[MLRenderingData::ATT_NAMES::ATT_VERTNORMAL] = true;
		atts[MLRenderingData::ATT_NAMES::ATT_FACENORMAL] = true;
		shared->meshAttributesUpdated(m.id(), false, atts);
	}
}

void SideShow::setModelColor(GLArea* gla, MeshModel& model, vcg::Color4b color)
{
	MLSceneGLSharedDataContext* datacont = gla->mvc()->sharedDataContext();
	if (datacont == NULL)
		return;
	MLRenderingData curr;
	datacont->getRenderInfoPerMeshView(model.id(), gla->context(), curr);
	MLPerViewGLOptions opts;
	if (curr.get(opts) == false)
		throw MLException(QString("GLArea: invalid MLPerViewGLOptions"));
	opts._persolid_fixed_color_enabled = true;
	opts._persolid_fixed_color = color;

	curr.set(opts);
	datacont->setRenderingDataPerMeshView(model.id(), gla->context(), curr);
}


void SideShow::setCurrentModelMLPerViewGLOptions()
{
	if (m_gla == NULL)
		return;
	MLSceneGLSharedDataContext *mSharedData = m_gla->mvc()->sharedDataContext();
	if (mSharedData == NULL)
		return;
	glPushAttrib(GL_TRANSFORM_BIT);
	glMatrixMode(GL_MODELVIEW);
	glPushMatrix();
	glMultMatrix(m_model.cm.Tr);
	double modelview_matrix[16] = { 0.0 };
	double projection_matrix[16] = { 0.0 };
	double viewport[3] = { 0 };
	glGetDoublev(GL_MODELVIEW_MATRIX, modelview_matrix);
	glPopMatrix();
	glPopAttrib();
	glGetDoublev(GL_PROJECTION_MATRIX, projection_matrix);
	viewport[0] = viewport[1] = 0;
	viewport[2] = m_gla->width(); viewport[3] = m_gla->height();
	switch (m_type)
	{
	case SideShow::SIDE_SHOW_POINT:
	
	case SideShow::SIDE_SHOW_WIRE:
		
	case SideShow::SIDE_SHOW_SOLID:
		
	case SideShow::SIDE_SHOW_BBOX:
	{
		QColor color(255, 0, 0);
		setModelColor(m_gla, m_model, vcg::Color4b(color.red(), color.green(), color.blue(), color.alpha()));
	}
		break;
	case SideShow::SIDE_SHOW_COLOR:
	{
		QColor color(255, 0, 0);
		setModelColor(m_gla, m_model, vcg::Color4b(color.red(), color.green(), color.blue(), color.alpha()));
	}
		break;
	case SideShow::SIDE_SHOW_CHARTLET:
		break;
	case SideShow::SIDE_SHOW_NORMAL:
	{
		/*
			* ?X??????X(1,0,0)????N(x2,y2,z2) ?theta?X?????N???? alpha???????
												x1*x2 + y1*y2 + z1*z2											x2
			cos<X,N> = cos(theta) = --------------------------------------------------------   =  ----------------------------- < cos(alpha)
										sqrt(x1*x1+y1*y1+z1*z1) * sqrt(x2*x2+y2*y2+z2*z2)				sqrt(x2*x2+y2*y2+z2*z2)

			*/
		
		float theta = 0.0, alpha = 45.0, max = 90.0;
		float dirtiness;
		QColor color(255, 0, 0);
		for (CMeshO::VertexIterator fi = m_model.cm.vert.begin(); fi != m_model.cm.vert.end(); fi++)
		{
			bool hasColor = fi->HasColor();
			bool isColorEnabled = fi->IsColorEnabled();
			
			qDebug() << QObject::tr("Color1: ") << fi->C()._v[0] << QObject::tr(",") << fi->C()._v[1] << QObject::tr(",") << fi->C()._v[2];
			if (hasColor && isColorEnabled)
			{
				fi->C() = vcg::Color4b(color.red(), color.green(), color.blue(), color.alpha());
				fi->cC() = vcg::Color4b(color.red(), color.green(), color.blue(), color.alpha());
			}
			
		}

		//for (CMeshO::FaceIterator fi = m_model.cm.face.begin(); fi != m_model.cm.face.end(); fi++)
		{
			/*vcg::Point3f nor = fi->N();
			float cosTheta = nor.X() / sqrtf(nor.X() * nor.X() + nor.Y() * nor.Y() + nor.Z() * nor.Z());
			theta = 180.0 / PI * acosf(cosTheta) ;

			fi->V(0)->C() = vcg::Color4b(color.red(), color.green(), color.blue(), color.alpha());
			fi->V(1)->C() = vcg::Color4b(color.red(), color.green(), color.blue(), color.alpha());
			fi->V(2)->C() = vcg::Color4b(color.red(), color.green(), color.blue(), color.alpha());

			if (theta > alpha && theta < max)
			{
				if (!fi->Base().IsColorEnabled())
				{
					fi->Base().EnableColor();
				}
				if (!fi->Base().IsQualityEnabled())
				{
					fi->Base().EnableQuality();
				}

				dirtiness = fi->Q();
				if (dirtiness == 0)
				{
					fi->C() = vcg::Color4b(255, 0, 0, 0);
				}
				else
				{
					if (dirtiness > 255) fi->C() = vcg::Color4b(0, 0, 0, 0);
					else fi->C() = vcg::Color4b(255 - dirtiness, 255 - dirtiness, 255 - dirtiness ,0);
				}
				
				qDebug() << QObject::tr("Theta:") << theta <<QObject::tr("  N:(") << nor.X() << QObject::tr(",") << nor.Y() << QObject::tr(",") << nor.Z() << QObject::tr(")");

			} */
		}
		//vcg::tri::UpdateColor<CMeshO>::PerVertexFromFace(m_model.cm);
		//updateColorBuffer(m_model, mSharedData);
		update();
	}
		break;
	case SideShow::SIDE_SHOW_THRESHOLD_VALUE:
		break;
	default:
		break;
	}
}
