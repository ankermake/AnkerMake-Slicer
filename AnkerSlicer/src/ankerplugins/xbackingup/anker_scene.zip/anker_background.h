/****************************************************************************
* MeshLab                                                           o o     *
* A versatile mesh processing toolbox                             o     o   *
*                                                                _   O  _   *
* Copyright(C) 2005                                                \/)\/    *
* Visual Computing Lab                                            /\/|      *
* ISTI - Italian National Research Council                           |      *
*                                                                    \      *
* All rights reserved.                                                      *
*                                                                           *
* This program is free software; you can redistribute it and/or modify      *
* it under the terms of the GNU General Public License as published by      *
* the Free Software Foundation; either version 2 of the License, or         *
* (at your option) any later version.                                       *
*                                                                           *
* This program is distributed in the hope that it will be useful,           *
* but WITHOUT ANY WARRANTY; without even the implied warranty of            *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
* GNU General Public License (http://www.gnu.org/licenses/gpl.txt)          *
* for more details.                                                         *
*                                                                           *
****************************************************************************/
/****************************************************************************
Revision 0.1  2021/11/08 09:14:40  Aden Hu
****************************************************************************/
#ifndef ANKER_SCENE_BACKGROUND_H
#define ANKER_SCENE_BACKGROUND_H

#include <QColor>
#include <QString>
#include <common/parameters/value.h>
#include <common/parameters/rich_parameter_list.h>
#include <meshlab/glarea.h>
class SceneBackground
{
public:
	SceneBackground(const GLArea *area, const RichParameterList* rParamList);
	~SceneBackground();

	void setParamColor(const QColor &,const QString&);
	void backgroundBotColor(const QColor &);
	void backgroundTopColor(const QColor &);
	void baseLightAmbientColor(const QColor &);
	void baseLightDiffuseColor(const QColor &);
	void baseLightSpecularColor(const QColor &);

	void logAreaColor(const QColor &);
	void updateCustomSettingValues();

private:
	RichParameterList* rps;
	GLArea* gla;
};




#endif // !ANKER_SCENE_BACKGROUND_H
