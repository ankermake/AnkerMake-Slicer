/****************************************************************************
* MeshLab                                                           o o     *
* A versatile mesh processing toolbox                             o     o   *
*                                                                _   O  _   *
* Copyright(C) 2005                                                \/)\/    *
* Visual Computing Lab                                            /\/|      *
* ISTI - Italian National Research Council                           |      *
*                                                                    \      *
* All rights reserved.                                                      *
*                                                                           *
* This program is free software; you can redistribute it and/or modify      *
* it under the terms of the GNU General Public License as published by      *
* the Free Software Foundation; either version 2 of the License, or         *
* (at your option) any later version.                                       *
*                                                                           *
* This program is distributed in the hope that it will be useful,           *
* but WITHOUT ANY WARRANTY; without even the implied warranty of            *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
* GNU General Public License (http://www.gnu.org/licenses/gpl.txt)          *
* for more details.                                                         *
*                                                                           *
****************************************************************************/

#include "anker_perspective.h"
#include <wrap/qt/device_to_logical.h>
#include <math.h>

Perspective::Perspective(GLArea* glArea) : _glArea(glArea) , _fov(glArea->fov)
{

}

void Perspective::perspective(PerspectiveType type, const QString& name)
{
    switch (type)
    {
    case TOGGLE_ORTHOGRAPHIC_CAMREA:
        _toggleOrtho();
        break;
    case ORTHOVIEW:
        _createOrthoView(name);
        break;
    case TRACKBALL_STEP:
        _trackballStep(name);
        break;
    default:
        break;
    }
}
void Perspective::_toggleOrtho()
{
    if (_glArea)
    {
        if (_glArea->fov == 5.0)
            _glArea->fov = 35.0;
        else
            _glArea->fov = 5.0;

        _glArea->update();
    }
}

void Perspective::initializeShot(Shotm& shot)
{
    if (_glArea == NULL)
    {
        return;
    }
    shot.Intrinsics.PixelSizeMm[0] = 0.036916077f;
    shot.Intrinsics.PixelSizeMm[1] = 0.036916077f;

    int width = _glArea->width();
    int height = _glArea->height();
    shot.Intrinsics.DistorCenterPx[0] = width / 2;
    shot.Intrinsics.DistorCenterPx[1] = height / 2;
    shot.Intrinsics.CenterPx[0] = width / 2;
    shot.Intrinsics.CenterPx[1] = height / 2;
    shot.Intrinsics.ViewportPx[0] = width;
    shot.Intrinsics.ViewportPx[1] = height;

    double viewportYMm = shot.Intrinsics.PixelSizeMm[1] * shot.Intrinsics.ViewportPx[1];
    shot.Intrinsics.FocalMm = viewportYMm / (2 * tanf(vcg::math::ToRad(this->fovDefault() / 2.0f))); //27.846098mm

    shot.Extrinsics.SetIdentity();
}

float Perspective::getCameraDistance()
{
    if (_glArea == NULL)
        return 0.0;
    float cameraDist = viewRatio() / tanf(vcg::math::ToRad(_glArea->fov * .5f));
    return cameraDist;
}


void Perspective::_setView(const PerspectiveType type)
{
    if (_glArea == NULL)
        return;
    _glArea->makeCurrent();
    glViewport(0, 0, (GLsizei)QTLogicalToDevice(_glArea, _glArea->width()), (GLsizei)QTLogicalToDevice(_glArea, _glArea->height()));

    GLfloat fAspect = (GLfloat)_glArea->width() / _glArea->height();
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    vcg::Matrix44f mtTr; mtTr.SetTranslate(_glArea->trackball.center);
    vcg::Matrix44f mtSc; mtSc.SetScale(4.0f, 4.0f, 4.0f);
    vcg::Matrix44f mt = mtSc * mtTr * _glArea->trackball.Matrix() * (-mtTr);
    //    Matrix44f mt =  trackball.Matrix();

    Box3m bb;
    bb.Add(Matrix44m::Construct(mt), _glArea->md()->bbox());
    float cameraDist = this->getCameraDistance();
    
    if (type == PERSPECTIVE_PROJECTION)  _glArea->fov = 5.0;
    else if (type == PARALLEL_PROJECTION) _glArea->fov = 30.0;
    if (_glArea->fov <= 5) cameraDist = 8.0f; // small hack for orthographic projection where camera distance is rather meaningless...

    _glArea->nearPlane = cameraDist * _glArea->clipRatioNear;

    float maxFarPlane = cameraDist + std::max(viewRatio(), float(-bb.min[2])); // is this guaranteed to be the largest interesting view?
    _glArea->farPlane = cameraDist * _glArea->clipRatioFar;
    if (maxFarPlane < _glArea->farPlane)
    {
        _glArea->farPlane = maxFarPlane;
        // here we do not set clipRatioFar since the maxFarPlane changes as you zoom
    }
    // make sure far plane is always behind nearplane and avoid unnecessary wheel scrolling by changing clip ratio
    if (_glArea->farPlane < _glArea->nearPlane)
    {
        _glArea->farPlane = _glArea->nearPlane + 0.01f; // avoids the object completely disappearing
        _glArea->clipRatioFar = _glArea->farPlane / cameraDist;
    }

    //    qDebug("tbcenter %f %f %f",trackball.center[0],trackball.center[1],trackball.center[2]);
    //    qDebug("camera dist %f far  %f",cameraDist, farPlane);
    //    qDebug("Bb %f %f %f - %f %f %f", bb.min[0], bb.min[1], bb.min[2], bb.max[0], bb.max[1], bb.max[2]);

    if (type == PARALLEL_PROJECTION)
    {
        //???????
        glOrtho(-viewRatio() * fAspect, viewRatio() * fAspect, -viewRatio(), viewRatio(), _glArea->nearPlane, _glArea->farPlane);
    }
    else if(type == PERSPECTIVE_PROJECTION)
    {
        //?????????
        gluPerspective(_glArea->fov, fAspect, _glArea->nearPlane, _glArea->farPlane);
    }

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    //gluLookAt(0, 0, cameraDist, 0, 0, 0, 0, 1, 0);
    gluLookAt(-bb.max.X(), bb.max.Y(), 1.0f, 0, 0, 0, 0, 0, 1);
}
 


void Perspective::_createOrthoView(const QString& name)
{
    if (_glArea == NULL)
    {
        return;
    }
    Shotm view;
    initializeShot(view);
    _glArea->fov = 5;

    double viewportYMm = view.Intrinsics.PixelSizeMm[1] * view.Intrinsics.ViewportPx[1];
    view.Intrinsics.FocalMm = viewportYMm / (2 * tanf(vcg::math::ToRad(_glArea->fov / 2))); //27.846098 equivalente a circa 60 gradi

    _glArea->trackball.Reset();
    float newScale = 3.0f / _glArea->md()->bbox().Diag();
    _glArea->trackball.track.sca = newScale;
    _glArea->trackball.track.tra.Import(-_glArea->md()->bbox().Center());

    Matrix44m rot;
    QString dir = name;
    if (dir == TOPSTR)
        rot.SetRotateDeg(90, Point3m(1, 0, 0));
    else if (dir == BOTTOMSTR)
        rot.SetRotateDeg(90, Point3m(-1, 0, 0));
    else if (dir == LEFTSTR)
        rot.SetRotateDeg(90, Point3m(0, 1, 0));
    else if (dir == RIGHTSTR)
        rot.SetRotateDeg(90, Point3m(0, -1, 0));
    else if (dir == FRONTSTR)
        rot.SetRotateDeg(0, Point3m(0, 1, 0));
    else if (dir == BACKSTR)
        rot.SetRotateDeg(180, Point3m(0, 1, 0));
    else if (dir == THREEDSTR)
        rot = Matrix44m().SetRotateDeg(90, Point3m(0, 1, 0)) * Matrix44m().SetRotateDeg(90, Point3m(-1, 0, 0)) * Matrix44m().SetRotateDeg(-45, Point3m(0, 0, 1));
    // scene uses "engineering" reference system, with Z as vertical axis
    else if (dir == TOP_Z_IS_UP_STR)
        rot.SetRotateDeg(0, Point3m(1, 0, 0));
    else if (dir == BOTTOM_Z_IS_UP_STR)
        rot.SetRotateDeg(180, Point3m(1, 0, 0));
    else if (dir == LEFT_Z_IS_UP_STR)
        rot = Matrix44m().SetRotateDeg(90, Point3m(0, 1, 0)) * Matrix44m().SetRotateDeg(90, Point3m(-1, 0, 0));
    else if (dir == RIGHT_Z_IS_UP_STR)
        rot = Matrix44m().SetRotateDeg(90, Point3m(0, -1, 0)) * Matrix44m().SetRotateDeg(90, Point3m(-1, 0, 0));
    else if (dir == FRONT_Z_IS_UP_STR)
        rot.SetRotateDeg(90, Point3m(-1, 0, 0));
    else if (dir == BACK_Z_IS_UP_STR)
        rot = Matrix44m().SetRotateDeg(90, Point3m(1, 0, 0)) * Matrix44m().SetRotateDeg(180, Point3m(0, 1, 0));

    view.Extrinsics.SetRot(rot);
    view.Extrinsics.SetTra(vcg::Point3f(0.0f, 0.0f, 1.0f));

    float cameraDist = getCameraDistance();

    //add the translation introduced by gluLookAt() (0,0,cameraDist), in order to have the same view---------------
    //T(gl)*S*R*T(t) => SR(gl+t) => S R (S^(-1)R^(-1)gl + t)
    //Add translation S^(-1) R^(-1)(gl)
    //Shotd doesn't introduce scaling
    //---------------------------------------------------------------------
    view.Extrinsics.SetTra(view.Extrinsics.Tra() + (Inverse(view.Extrinsics.Rot()) * Point3m(0, 0, cameraDist)));

    Shotm shot = track2ShotCPU(view, &_glArea->trackball);

    QPair<Shotm, float> shotAndScale = QPair<Shotm, float>(shot, _glArea->trackball.track.sca);
    loadShot(shotAndScale);

    _glArea->Logf(GLLogStream::SYSTEM, "View scene from %s", qUtf8Printable(dir));
}

void Perspective::loadShot(const QPair<Shotm, float>& shotAndScale)
{
    if (_glArea == NULL)
        return;
    Shotm shot = shotAndScale.first;

    _glArea->fov = (shot.Intrinsics.cameraType == 0) ? shot.GetFovFromFocal() : 5.0;

    float cameraDist = getCameraDistance();

    //reset trackball. The point of view must be set only by the shot
    _glArea->trackball.Reset();
    _glArea->trackball.track.sca = shotAndScale.second;

    shot2Track(shot, cameraDist, _glArea->trackball);

    /*Point3f point = this->md()->bbox().Center();
    Point3f p1 = ((trackball.track.Matrix()*(point-trackball.center))- Point3f(0,0,cameraDist));*/
    //Expressing the translation along Z with a scale factor k
    //Point3f p2 = ((trackball.track.Matrix()*(point-trackball.center))- Point3f(0,0,cameraDist));

    ////k is the ratio between the distances along z of two correspondent points (before and after the translation)
    ////from the point of view
    //float k= abs(p2.Z()/p1.Z());

    //float sca= trackball.track.sca/k;
    //Point3f tra = trackball.track.tra;
    //
    //// Apply this formula:
    //// SR(t+p) -v = k[S'R'(t'+p) -v] forall p, R=R', k is a constant
    //// SR(t) -v = k[S'R(t') -v]
    //// t' = 1/k* S'^-1St + (k-1)/k S'^-1*R^-1v
    //Matrix44f s0 = Matrix44f().SetScale(trackball.track.sca,trackball.track.sca, trackball.track.sca);
    //Matrix44f s1 = Matrix44f().SetScale(sca, sca, sca);
    //Matrix44f r;
    //trackball.track.rot.ToMatrix(r);
    //Matrix44f rapM = Matrix44f().SetScale(1/k, 1/k, 1/k);
    //Matrix44f rapM2 = Matrix44f().SetScale(1-1/k, 1-1/k, 1-1/k);
    //Point3f t1 = rapM*Inverse(s1)*s0*tra + rapM2*Inverse(s1)*Inverse(r)*Point3f(0,0,cameraDist);

    //trackball.track.sca =sca;
    //trackball.track.tra =t1 /*+ tb.track.rot.Inverse().Rotate(glLookAt)*/ ;

    _glArea->update();
}
#include <vcg/math/quaternion.h>
using namespace vcg;
void Perspective::_trackballStep(const QString& name)
{
    if (_glArea)
    {
        QString dir = name;
        float stepAngle = float(M_PI / 12.0);

        if (dir == HORIZONTAL_PLUS_STR)
            _glArea->trackball.track.rot = Quaternionf(-stepAngle, Point3f(0.0, 1.0, 0.0)) * _glArea->trackball.track.rot;
        else if (dir == HORIZONTAL_SUBTRACT_STR)
            _glArea->trackball.track.rot = Quaternionf(stepAngle, Point3f(0.0, 1.0, 0.0)) * _glArea->trackball.track.rot;
        else if (dir == VERTICAL_PLUS_STR)
            _glArea->trackball.track.rot = Quaternionf(-stepAngle, Point3f(1.0, 0.0, 0.0)) * _glArea->trackball.track.rot;
        else if (dir == VERTICAL_SUBTRACT_STR)
            _glArea->trackball.track.rot = Quaternionf(stepAngle, Point3f(1.0, 0.0, 0.0)) * _glArea->trackball.track.rot;
        else if (dir == AXIAL_PLUS_STR)
            _glArea->trackball.track.rot = Quaternionf(-stepAngle, Point3f(0.0, 0.0, 1.0)) * _glArea->trackball.track.rot;
        else if (dir == AXIAL_SUBTRACT_STR)
            _glArea->trackball.track.rot = Quaternionf(stepAngle, Point3f(0.0, 0.0, 1.0)) * _glArea->trackball.track.rot;

        _glArea->update();
    }
}
