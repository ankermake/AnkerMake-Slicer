/****************************************************************************
* MeshLab                                                           o o     *
* A versatile mesh processing toolbox                             o     o   *
*                                                                _   O  _   *
* Copyright(C) 2005                                                \/)\/    *
* Visual Computing Lab                                            /\/|      *
* ISTI - Italian National Research Council                           |      *
*                                                                    \      *
* All rights reserved.                                                      *
*                                                                           *
* This program is free software; you can redistribute it and/or modify      *
* it under the terms of the GNU General Public License as published by      *
* the Free Software Foundation; either version 2 of the License, or         *
* (at your option) any later version.                                       *
*                                                                           *
* This program is distributed in the hope that it will be useful,           *
* but WITHOUT ANY WARRANTY; without even the implied warranty of            *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
* GNU General Public License (http://www.gnu.org/licenses/gpl.txt)          *
* for more details.                                                         *
*                                                                           *
****************************************************************************/
#include <GL/glew.h>


#include <wrap/qt/gl_label.h>
#include <wrap/gl/deprecated_space.h>
#include <wrap/gl/addons.h>
#include "anker_world_coordinate.h"

AnkerWorldCoordinate::AnkerWorldCoordinate(float size, const Point3f& p, const Quaternionf& r) : MovableCoordinateFrame(size)
{
    position = p;
    linewidth = 2.0f;
    rotation = r;
}

void AnkerWorldCoordinate::Render(QGLWidget* glw, QPainter* p )
{
    assert(glw != NULL);
    glPushAttrib(GL_ALL_ATTRIB_BITS);
    glDisable(GL_LIGHTING);
    glDisable(GL_TEXTURE_2D);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glEnable(GL_LINE_SMOOTH);
    glEnable(GL_POINT_SMOOTH);
    glLineWidth(linewidth);
    glPointSize(linewidth * 1.5);
    glLabel::Mode md;
    Point3d o(0, 0, 0);
    Point3d a(size, 0, 0);
    Point3d b(0, size, 0);
    Point3d c(0, 0, size);
    // Get gl state values
    double mm[16], mp[16];
    GLint vp[4];
    glGetDoublev(GL_MODELVIEW_MATRIX, mm);
    glGetDoublev(GL_PROJECTION_MATRIX, mp);
    glGetIntegerv(GL_VIEWPORT, vp);
    float scalefactor = size * 0.02f;
    if (drawaxis) {
        glBegin(GL_LINES);
        glColor(xcolor);
        glVertex(o); glVertex(a);
        glColor(ycolor);
        glVertex(o); glVertex(b);
        glColor(zcolor);
        glVertex(o); glVertex(c);
        glEnd();
        
        glPushMatrix();
        glTranslate(a);
        glScalef(scalefactor, scalefactor, scalefactor);
        glColor(xcolor);
        Add_Ons::Cone(10, linewidth * 1.5, linewidth * 0.5, true);
        glPopMatrix();
        glPushMatrix();
        glTranslate(b);
        glRotatef(90, 0, 0, 1);
        glScalef(scalefactor, scalefactor, scalefactor);
        glColor(ycolor);
        Add_Ons::Cone(10, linewidth * 1.5, linewidth * 0.5, true);
        glPopMatrix();
        glPushMatrix();
        glTranslate(c);
        glRotatef(-90, 0, 1, 0);
        glScalef(scalefactor, scalefactor, scalefactor);
        glColor(zcolor);
        Add_Ons::Cone(10, linewidth * 1.5, linewidth * 0.5, true);
        glPopMatrix();

    }
    if (drawlabels) {
        md.qFont.setBold(true);
        md.qFont.setPixelSize(12);
        float d = size + scalefactor * linewidth * 1.5;
        if (p) {
            md.color = xcolor;
            vcg::glLabel::render(p, vcg::Point3f(d, 0, 0), QString("X"), md);
            md.color = ycolor;
            vcg::glLabel::render(p, vcg::Point3f(0, d, 0), QString("Y"), md);
            md.color = zcolor;
            vcg::glLabel::render(p, vcg::Point3f(0, 0, d), QString("Z"), md);
        }
    }

    glGetError(); // Patch to buggy qt rendertext;
    glPopAttrib();
    assert(!glGetError());
}


AnkerLocalCoordinate::AnkerLocalCoordinate(float size, const Point3f& p, const Quaternionf& r) :
    MovableCoordinateFrame(size)
{
    position = p;
    rotation = r;
    linewidth = 1.0f;
}
AnkerLocalCoordinate::AnkerLocalCoordinate(float size, const Matrix44f& m) : MovableCoordinateFrame(size), m_matrix(m)
{
    linewidth = 1.0f;
}


void AnkerLocalCoordinate::Render(QGLWidget* glw, QPainter* p)
{
    assert(glw != NULL);
    glPushAttrib(GL_ALL_ATTRIB_BITS);
    glDisable(GL_LIGHTING);
    glDisable(GL_TEXTURE_2D);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glEnable(GL_LINE_SMOOTH);
    glEnable(GL_POINT_SMOOTH);
    glLineWidth(linewidth);
    glPointSize(linewidth * 1.5);
    glLabel::Mode md;
    Point3d o(position);
    Point3d a(position[0] + size, position[1], position[2]);
    Point3d b(position[0],  position[1] + size, position[2]);
    Point3d c(position[0], position[1], position[2] + size);
    // Get gl state values
    double mm[16], mp[16];
    GLint vp[4];
    glGetDoublev(GL_MODELVIEW_MATRIX, mm);
    glGetDoublev(GL_PROJECTION_MATRIX, mp);
    glGetIntegerv(GL_VIEWPORT, vp);
    float scalefactor = size * 0.02f;
    if (drawaxis) {
        glBegin(GL_LINES);
        glColor(xcolor);
        glVertex(o); glVertex(a);
        glColor(ycolor);
        glVertex(o); glVertex(b);
        glColor(zcolor);
        glVertex(o); glVertex(c);
        glEnd();

        glPushMatrix();
        glTranslate(a);
        glScalef(scalefactor, scalefactor, scalefactor);
        glColor(xcolor);
        Add_Ons::Cone(10, linewidth * 1.5, linewidth * 0.5, true);
        glPopMatrix();
        glPushMatrix();
        glTranslate(b);
        glRotatef(90, 0, 0, 1);
        glScalef(scalefactor, scalefactor, scalefactor);
        glColor(ycolor);
        Add_Ons::Cone(10, linewidth * 1.5, linewidth * 0.5, true);
        glPopMatrix();
        glPushMatrix();
        glTranslate(c);
        glRotatef(-90, 0, 1, 0);
        glScalef(scalefactor, scalefactor, scalefactor);
        glColor(zcolor);
        Add_Ons::Cone(10, linewidth * 1.5, linewidth * 0.5, true);
        glPopMatrix();
    }
    if (drawlabels) {
        md.qFont.setBold(true);
        md.qFont.setPixelSize(5);
        float d = size + scalefactor * linewidth * 1.0;
        if (p) {
            md.color = xcolor;
            vcg::glLabel::render(p, vcg::Point3f(position[0] + d, position[1], position[2]), QString(""), md);
            md.color = ycolor;
            vcg::glLabel::render(p, vcg::Point3f(position[0], position[1] + d, position[2]), QString(""), md);
            md.color = zcolor;
            vcg::glLabel::render(p, vcg::Point3f(position[0], position[1], position[2] + d), QString(""), md);
        }
    }
    glGetError(); // Patch to buggy qt rendertext;
    glPopAttrib();
    assert(!glGetError());
}


LocalCoordinate::LocalCoordinate(float size, const Point3f& p, const Matrix44f& m) :
    m_size(size), m_center(p), m_matrix(m) , m_linewidth(1.5f)
{

}

void LocalCoordinate::render()
{
    glLineWidth(m_linewidth);
    glPushMatrix();    
    glMultMatrixf(vcg::Transpose(m_matrix).V());
    glBegin(GL_LINES);
    glColor4b(125, 0, 0, 255);
    glVertex3f(m_center.X(), m_center.Y(), m_center.Z()); glVertex3f(m_size + m_center.X(), m_center.Y(), m_center.Z());
    glColor4b(0, 125, 0, 255);
    glVertex3f(m_center.X(), m_center.Y(), m_center.Z()); glVertex3f(m_center.X(), m_center.Y() + m_size, m_center.Z());
    glColor4b(0, 0, 125, 255);
    glVertex3f(m_center.X(), m_center.Y(), m_center.Z()); glVertex3f(m_center.X(), m_center.Y(), m_center.Z() + m_size);
    glEnd();

    glPopMatrix();
}
