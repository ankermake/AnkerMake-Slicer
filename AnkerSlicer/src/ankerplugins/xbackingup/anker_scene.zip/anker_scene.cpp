/****************************************************************************
* MeshLab                                                           o o     *
* A versatile mesh processing toolbox                             o     o   *
*                                                                _   O  _   *
* Copyright(C) 2005                                                \/)\/    *
* Visual Computing Lab                                            /\/|      *
* ISTI - Italian National Research Council                           |      *
*                                                                    \      *
* All rights reserved.                                                      *
*                                                                           *
* This program is free software; you can redistribute it and/or modify      *
* it under the terms of the GNU General Public License as published by      *
* the Free Software Foundation; either version 2 of the License, or         *
* (at your option) any later version.                                       *
*                                                                           *
* This program is distributed in the hope that it will be useful,           *
* but WITHOUT ANY WARRANTY; without even the implied warranty of            *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
* GNU General Public License (http://www.gnu.org/licenses/gpl.txt)          *
* for more details.                                                         *
*                                                                           *
****************************************************************************/
#include <math.h>
#include <limits>
#include <stdlib.h>
#include "anker_scene.h"
#include <wrap/gl/addons.h>
#include <wrap/qt/col_qt_convert.h>
//#include <meshlab/mainwindow.h>
#include "meshlab/glarea.h"
#include "common/GLExtensionsManager.h"
#include "common/plugins/plugin_manager.h"
#include <QVector3D>
#include <QCoreApplication>
using namespace vcg;
#define PI 3.1415926535898
#define EPSINON 0.01
QString AnkerScenePlugin::decorationName(ActionIDType id) const
{
    switch (id)
    {
    case DP_SHOW_FRONT: return FRONTSTR;
    case DP_SHOW_BACK: return BACKSTR;
    case DP_SHOW_RIGHT: return RIGHTSTR;
    case DP_SHOW_LEFT: return LEFTSTR;
    case DP_SHOW_TOP: return TOPSTR;
    case DP_SHOW_BOTTOM: return BOTTOMSTR;
    case DP_SHOW_THREED: return THREEDSTR;

    case DP_SHOW_TOP_Z_IS_UP: return TOP_Z_IS_UP_STR;
    case  DP_SHOW_BOTTOM_Z_IS_UP: return BOTTOM_Z_IS_UP_STR;
    case   DP_SHOW_LEFT_Z_IS_UP: return LEFT_Z_IS_UP_STR;
    case  DP_SHOW_RIGHT_Z_IS_UP:    return RIGHT_Z_IS_UP_STR;
    case    DP_SHOW_FRONT_Z_IS_UP:  return FRONT_Z_IS_UP_STR;
    case  DP_SHOW_BACK_Z_IS_UP: return BACK_Z_IS_UP_STR;

    case  DP_SHOW_HORIZONTAL_PLUS:  return HORIZONTAL_PLUS_STR;
    case  DP_SHOW_HORIZONTAL_SUBTRACT:  return HORIZONTAL_SUBTRACT_STR;
    case   DP_SHOW_VERTICAL_PLUS: return  VERTICAL_PLUS_STR;
    case     DP_SHOW_VERTICAL_SUBTRACT: return   VERTICAL_SUBTRACT_STR;
    case   DP_SHOW_AXIAL_PLUS:  return   AXIAL_PLUS_STR;
    case    DP_SHOW_AXIAL_SUBTRACT: return AXIAL_SUBTRACT_STR;


    case DP_SHOW_TOGGLE: return TOOGLESTR;

    case DP_SHOW_SETPARAMETER: return RICHPARAMETER_STR;

    case DP_SHOW_LOGSTREAM: return LOGSTREAM_STR;

    case DP_SHOW_WORLD_COORDINATE: return WORLD_COORDINATE_NAME_STR;
    case DP_SHOW_LOCAL_COORDINATE: return LOCAL_COORDINATE_NAME_STR;
    case DP_SHOW_LOACL_BBOX: return LOCAL_BBOX_NAME_STR;
    case DP_SHOW_WORLD_BBOX: return WORLD_BBOX_NAME_STR;

    case  DP_SHOW_PERSPECTIVE_PROJECTION: return PERSPECTIVE_PROJECTION_STR;
    case  DP_SHOW_PARALLERL_PROJECTION: return PARALLERL_PROJECTION_STR;

    case  DP_SHOW_IMPORT_PEDESTAL: return  IMPORT_PEDESTAL_STR;

    case DP_SHOW_NORMAL: return SHOW_NORMAL_STR;
    case DP_SHOW_THRESHOLD: return SHOW_THRESHOLD_STR;

    case DP_SHOW_POINTS_RENDER: return SHOW_POINTS_RENDER_STR;
    case DP_SHOW_WIREFRAME_RENDER: return SHOW_WIREFRAME_RENDER_STR;
    case DP_SHOW_VERT_RENDER: return SHOW_VERT_RENDER_STR;
    case DP_SHOW_FACE_RENDER: return  SHOW_FACE_RENDER_STR;
    }
    assert(0);
    return QString();
}

QString AnkerScenePlugin::decorationInfo(ActionIDType id) const
{
    switch(id)
    {
    case DP_SHOW_FRONT: return FRONTSTR;
    case DP_SHOW_BACK: return BACKSTR;
    case DP_SHOW_RIGHT: return RIGHTSTR;
    case DP_SHOW_LEFT: return LEFTSTR;
    case DP_SHOW_TOP: return TOPSTR;
    case DP_SHOW_BOTTOM: return BOTTOMSTR;
    case DP_SHOW_THREED: return THREEDSTR;

    case DP_SHOW_TOP_Z_IS_UP: return TOP_Z_IS_UP_STR;
    case  DP_SHOW_BOTTOM_Z_IS_UP: return BOTTOM_Z_IS_UP_STR;
    case   DP_SHOW_LEFT_Z_IS_UP: return LEFT_Z_IS_UP_STR;
    case  DP_SHOW_RIGHT_Z_IS_UP:    return RIGHT_Z_IS_UP_STR;
    case    DP_SHOW_FRONT_Z_IS_UP:  return FRONT_Z_IS_UP_STR;
    case  DP_SHOW_BACK_Z_IS_UP: return BACK_Z_IS_UP_STR;

    case  DP_SHOW_HORIZONTAL_PLUS:  return HORIZONTAL_PLUS_STR;
    case  DP_SHOW_HORIZONTAL_SUBTRACT:  return HORIZONTAL_SUBTRACT_STR;
    case   DP_SHOW_VERTICAL_PLUS: return  VERTICAL_PLUS_STR;
    case     DP_SHOW_VERTICAL_SUBTRACT: return   VERTICAL_SUBTRACT_STR;
    case   DP_SHOW_AXIAL_PLUS:  return   AXIAL_PLUS_STR;
    case    DP_SHOW_AXIAL_SUBTRACT: return AXIAL_SUBTRACT_STR;


    case DP_SHOW_TOGGLE: return TOOGLESTR;

    case DP_SHOW_SETPARAMETER: return RICHPARAMETER_STR;

    case DP_SHOW_LOGSTREAM: return LOGSTREAM_STR;

    case DP_SHOW_WORLD_COORDINATE: return WORLD_COORDINATE_NAME_STR;
    case DP_SHOW_LOCAL_COORDINATE: return LOCAL_COORDINATE_NAME_STR;
    case DP_SHOW_LOACL_BBOX: return LOCAL_BBOX_NAME_STR;
    case DP_SHOW_WORLD_BBOX: return WORLD_BBOX_NAME_STR;

    case  DP_SHOW_PERSPECTIVE_PROJECTION: return PERSPECTIVE_PROJECTION_STR;
    case  DP_SHOW_PARALLERL_PROJECTION: return PARALLERL_PROJECTION_STR;

    case  DP_SHOW_IMPORT_PEDESTAL: return  IMPORT_PEDESTAL_STR;

    case DP_SHOW_NORMAL: return SHOW_NORMAL_STR;
    case DP_SHOW_THRESHOLD: return SHOW_THRESHOLD_STR;

    case DP_SHOW_POINTS_RENDER: return SHOW_POINTS_RENDER_STR;
    case DP_SHOW_WIREFRAME_RENDER: return SHOW_WIREFRAME_RENDER_STR;
    case DP_SHOW_VERT_RENDER: return SHOW_VERT_RENDER_STR;
    case DP_SHOW_FACE_RENDER: return  SHOW_FACE_RENDER_STR;
    }
    assert(0);
    return QString();
}

QString AnkerScenePlugin::pluginName() const
{
    return "AnkerScene";
}

void AnkerScenePlugin::setView(GLArea* gla, PerspectiveType type, const QString& dir)
{
    Perspective perspective(gla);
    perspective.perspective(type, dir);
}

bool AnkerScenePlugin::startDecorate(const QAction * action, MeshDocument &m, const RichParameterList * parset, GLArea * gla)
{
    if (!GLExtensionsManager::initializeGLextensions_notThrowing()) {
        return false;
    }
    switch(ID(action))
    {

    case DP_SHOW_FRONT:
    {
        setView(gla, ORTHOVIEW, FRONTSTR);
        break;
    }
    case DP_SHOW_BACK:
    {
        setView(gla, ORTHOVIEW, BACKSTR);
        break;
    }
    case DP_SHOW_RIGHT:
    {
        setView(gla, ORTHOVIEW, RIGHTSTR);
        break;
    }
    case DP_SHOW_LEFT:
    {
        setView(gla, ORTHOVIEW, LEFTSTR);
        break;
    }
    case DP_SHOW_TOP:
    {
        setView(gla, ORTHOVIEW, TOPSTR);
        break;
    }
    case DP_SHOW_BOTTOM:
    {
        setView(gla, ORTHOVIEW, BOTTOMSTR);
        break;
    }
    case DP_SHOW_THREED:
    {
        setView(gla, ORTHOVIEW, THREEDSTR);
        break;
    }
    case DP_SHOW_TOP_Z_IS_UP:
    {
        setView(gla, ORTHOVIEW, TOP_Z_IS_UP_STR);
        break;
    }
    case  DP_SHOW_BOTTOM_Z_IS_UP:
    {
        setView(gla, ORTHOVIEW, BOTTOM_Z_IS_UP_STR);
        break;
    }
    case   DP_SHOW_LEFT_Z_IS_UP:
    {
        setView(gla, ORTHOVIEW, LEFT_Z_IS_UP_STR);
        break;
    }
    case  DP_SHOW_RIGHT_Z_IS_UP:
    {
        setView(gla, ORTHOVIEW, RIGHT_Z_IS_UP_STR);
        break;
    }
    case  DP_SHOW_FRONT_Z_IS_UP:
    {
        setView(gla, ORTHOVIEW, FRONT_Z_IS_UP_STR);
        break;
    }
    case  DP_SHOW_BACK_Z_IS_UP:
    {
        setView(gla, ORTHOVIEW, BACK_Z_IS_UP_STR);
        break;
    }




    case DP_SHOW_HORIZONTAL_PLUS:
    {
        setView(gla, TRACKBALL_STEP, HORIZONTAL_PLUS_STR);
        break;
    }
    case  DP_SHOW_HORIZONTAL_SUBTRACT:
    {
        setView(gla, TRACKBALL_STEP, HORIZONTAL_SUBTRACT_STR);
        break;
    }
    case DP_SHOW_VERTICAL_PLUS:
    {
        setView(gla, TRACKBALL_STEP, VERTICAL_PLUS_STR);
        break;
    }
    case DP_SHOW_VERTICAL_SUBTRACT:
    {
        setView(gla, TRACKBALL_STEP, VERTICAL_SUBTRACT_STR);
        break;
    }
    case DP_SHOW_AXIAL_PLUS:
    {
        setView(gla, TRACKBALL_STEP, AXIAL_PLUS_STR);
        break;
    }
    case DP_SHOW_AXIAL_SUBTRACT:
    {
        setView(gla, TRACKBALL_STEP, AXIAL_SUBTRACT_STR);
        break;
    }
    
    case DP_SHOW_TOGGLE :
    {
        setView(gla, TOGGLE_ORTHOGRAPHIC_CAMREA, TOOGLESTR);
        break;
    }

    case DP_SHOW_SETPARAMETER:
    {
        RichParameterList* rps = const_cast<RichParameterList*>(parset);
        
        QColor c1 = parset->getColor(tr("MeshLab::Appearance::backgroundBotColor"));
        c1.setRgb(247, 247, 247);
        SceneBackground sbg1(gla, const_cast<RichParameterList*>(parset));//场景背景颜色
        sbg1.setParamColor(c1, tr("MeshLab::Appearance::backgroundBotColor"));

        QColor c2 = parset->getColor(tr("MeshLab::Appearance::backgroundTopColor"));
        c2.setRgb(247, 247, 247);
        SceneBackground sbg2(gla, const_cast<RichParameterList*>(parset));//场景背景颜色
        sbg1.setParamColor(c2, tr("MeshLab::Appearance::backgroundTopColor"));
        break;
    }



    case DP_SHOW_LOCAL_COORDINATE:
    {
        break;
    }

    case  DP_SHOW_PERSPECTIVE_PROJECTION:
    {
        Perspective perspective(gla);
        perspective._setView(PERSPECTIVE_PROJECTION);
        break;
    }
    case  DP_SHOW_PARALLERL_PROJECTION:
    {
        Perspective perspective(gla);
        perspective._setView(PARALLEL_PROJECTION);
        break;
    }


    case DP_SHOW_IMPORT_PEDESTAL:
    {
       
        break;
    }

    

    case DP_SHOW_POINTS_RENDER:
    {
        MLSceneGLSharedDataContext* datacont = gla->mvc()->sharedDataContext();
        if (datacont == NULL)
            return false;
        MLRenderingData curr;
        datacont->getRenderInfoPerMeshView(m.mm()->id(), gla->context(), curr);
        curr.set(MLRenderingData::PR_POINTS, true);
        curr.set(MLRenderingData::PR_SOLID, false);

        datacont->setRenderingDataPerMeshView(m.mm()->id(), gla->context(), curr);
    }
        
        break;
    case DP_SHOW_WIREFRAME_RENDER:
    {
        MLSceneGLSharedDataContext* datacont = gla->mvc()->sharedDataContext();
        if (datacont == NULL)
            return false;
        MLRenderingData curr;
        datacont->getRenderInfoPerMeshView(m.mm()->id(), gla->context(), curr);
        curr.set(MLRenderingData::PR_WIREFRAME_TRIANGLES, true);
        curr.set(MLRenderingData::PR_SOLID, false);
        datacont->setRenderingDataPerMeshView(m.mm()->id(), gla->context(), curr);
    }
        break;
    case DP_SHOW_VERT_RENDER:
    {
        MLSceneGLSharedDataContext* datacont = gla->mvc()->sharedDataContext();
        if (datacont == NULL)
            return false;
        MLRenderingData curr;
        datacont->getRenderInfoPerMeshView(m.mm()->id(), gla->context(), curr);
        curr.set(MLRenderingData::PR_POINTS, true);
        curr.set(MLRenderingData::PR_SOLID, false);
        datacont->setRenderingDataPerMeshView(m.mm()->id(), gla->context(), curr);
    }
        break;
    case DP_SHOW_FACE_RENDER:
    {
        MLSceneGLSharedDataContext* datacont = gla->mvc()->sharedDataContext();
        if (datacont == NULL)
            return false;
        MLRenderingData curr;
        datacont->getRenderInfoPerMeshView(m.mm()->id(), gla->context(), curr);
        curr.set(MLRenderingData::PR_SOLID, true);
        datacont->setRenderingDataPerMeshView(m.mm()->id(), gla->context(), curr);
    }
        break;
    case DP_SHOW_THRESHOLD:
    {
        MLSceneGLSharedDataContext* datacont = gla->mvc()->sharedDataContext();
        if (datacont == NULL)
            return false;
        MLRenderingData curr;
        datacont->getRenderInfoPerMeshView(m.mm()->id(), gla->context(), curr);
        suggestedRenderingData(*m.mm(), curr);
        datacont->setRenderingDataPerMeshView(m.mm()->id(), gla->context(), curr);
        datacont->manageBuffers(m.mm()->id());
        thresholdRender(gla, m.mm(), 30.0f, 90.0f);
        break;
    }
   
    }
    
    return true;
}

void AnkerScenePlugin::endDecorate(const QAction* action, MeshDocument& m, const RichParameterList*, GLArea* gla)
{
    switch (ID(action))
    {
    case DP_SHOW_THRESHOLD:
    {
        MLSceneGLSharedDataContext* datacont = gla->mvc()->sharedDataContext();
        if (datacont == NULL)
            return ;
        datacont->setRenderingDataPerMeshView(m.mm()->id(), gla->context(), defaultMLRender);
        datacont->manageBuffers(m.mm()->id());
        break;
    }
    }
}

void AnkerScenePlugin::thresholdRender(GLArea* gla, MeshModel* mm, float theta1, float theta2)
{
    if (!GLExtensionsManager::initializeGLextensions_notThrowing())
        return;
    if (gla == NULL || mm == NULL)
        return;
    vcg::tri::UpdateBounding<CMeshO>::Box(mm->cm);
    //mm->updateDataMask(MeshModel::MM_VERTFACETOPO | MeshModel::MM_FACEMARK | MeshModel::MM_VERTMARK);
    mm->updateDataMask(MeshModel::MM_FACEFACETOPO | MeshModel::MM_FACEMARK | MeshModel::MM_VERTMARK);

    /*if (!mm->hasDataMask(MeshModel::MM_VERTCOLOR))
    {
       mm->updateDataMask(MeshModel::MM_VERTCOLOR);
       tri::UpdateColor<CMeshO>::PerVertexConstant(mm->cm, Color4b(125, 125, 125, 255));
    }*/
    if (!mm->hasDataMask(MeshModel::MM_FACECOLOR))
    {
        mm->updateDataMask(MeshModel::MM_FACECOLOR);
        vcg::tri::UpdateColor<CMeshO>::PerFaceConstant(mm->cm, vcg::Color4b(255, 255, 0, 255));
    }
    vcg::tri::InitFaceIMark(mm->cm);
    vcg::tri::InitVertexIMark(mm->cm);

    QColor color(125, 0, 0);
    float dirtiness;
    QVector3D zVec(0.0f, 0.0f, -1.0f);

    for (CMeshO::FaceIterator fi = mm->cm.face.begin(); fi != mm->cm.face.end(); fi++)
    {
        vcg::Point3f nor = fi->N();
        QVector3D nVec(nor.X(), nor.Y(), nor.Z());
        float cosTheta = QVector3D::dotProduct(zVec, nVec) / (zVec.length() * nVec.length());
            
        float theta = 180.0 / PI * acosf(cosTheta);

        if ((90 - theta > 90.0 - EPSINON) || (90 - theta < EPSINON))
        {
            continue;
        }
        if ((90 - theta > theta1 + EPSINON) && (90 - theta < theta2 - EPSINON))
        {
            /// fi->V(0)->C() = vcg::Color4b(color.red(), color.green(), color.blue(), color.alpha());
            // fi->V(1)->C() = vcg::Color4b(color.red(), color.green(), color.blue(), color.alpha());
            // fi->V(2)->C() = vcg::Color4b(color.red(), color.green(), color.blue(), color.alpha());
            if (!fi->IsColorEnabled())
            {
                fi->Base().EnableColor();
            }
            fi->C() = vcg::Color4b(color.red(), color.green(), color.blue(), color.alpha());
        }
    }

    //vcg::tri::Allocator<CMeshO>::CompactFaceVector(m.cm);
    MLSceneGLSharedDataContext* shared = gla->mvc()->sharedDataContext();
    updateColorBuffer(*mm, shared);
    shared->manageBuffers(mm->id());
}

void AnkerScenePlugin::suggestedRenderingData(MeshModel& m, MLRenderingData& dt)
{
    defaultMLRender = dt;
    if (m.cm.VN() == 0)
        return;
    MLRenderingData::PRIMITIVE_MODALITY pr = MLRenderingData::PR_POINTS;

    if (m.cm.FN() > 0)
        pr = MLRenderingData::PR_SOLID;

    MLRenderingData::RendAtts atts;
    //atts[MLRenderingData::ATT_NAMES::ATT_VERTPOSITION] = true;
    //atts[MLRenderingData::ATT_NAMES::ATT_VERTNORMAL] = true;
    //atts[MLRenderingData::ATT_NAMES::ATT_VERTCOLOR] = true;
    atts[MLRenderingData::ATT_NAMES::ATT_VERTPOSITION] = true;
    atts[MLRenderingData::ATT_NAMES::ATT_FACECOLOR] = true;
    atts[MLRenderingData::ATT_NAMES::ATT_FACENORMAL] = true;
    vcg::GLMeshAttributesInfo::PRIMITIVE_MODALITY_MASK mask = dt.getPrimitiveModalityMask();

    dt.set(pr, atts);
}

void AnkerScenePlugin::decorateDoc(const QAction* a, MeshDocument &m, const RichParameterList * parset, GLArea * gla, QPainter* painter, GLLogStream &logStream)
{
    static QString lastname("uninitialized");
    switch (ID(a))
    {
    case DP_SHOW_WORLD_COORDINATE:
    {
        AnkerWorldCoordinate(m.bbox().Diag() / 5.0, m.bbox().Center()).Render(gla, painter);
        break;
    }
    case DP_SHOW_LOCAL_COORDINATE:
    {
        MeshModel* currentModel = m.mm();
        if (currentModel == NULL)
        {
            break;
        }
        vcg::Box3f box = currentModel->cm.bbox;
        float size = sqrt(box.max.X() * box.max.X() + box.max.Y() * box.max.Y() + box.max.Z() * box.max.Z());
        LocalCoordinate coord(size, box.Center(), currentModel->cm.Tr);
        coord.render();
        /*AnkerLocalCoordinate(currentModel->cm.bbox.Diag() / 5.0,
            currentModel->cm.bbox.Center(),
            Quaternionf(0, Point3f(0, 0, 1))).Render(gla, painter); */
        break;
    }
    case DP_SHOW_LOACL_BBOX:
    {
        MeshModel* currentModel = m.mm();
        if (currentModel == NULL)
        {
            break;
        }

        //drawCurrentModelBox(*currentModel);
        drawCurrentModelBox(*currentModel, 5.0f, 4.0, QColor(0, 51, 238));
        //setModelColor(gla, *currentModel, vcg::Color4b(Color4b::Red));
        break;
    }
    case DP_SHOW_WORLD_BBOX:
    {
        //输入Box最大点和最小点
        vcg::Point3f max(235, 235, 250);//先设置默认盒子大小
        vcg::Point3f min(0.0f, 0.0f, 0.0f);
        tick = 10.0f;
        div = 20.0f;
        vcg::Box3f box(min, max);
        setSceneBox(box, 10.0f);
        sceneBoxLineColor[0] = sceneBoxLineColor[1] = sceneBoxLineColor[2] = 0.0f;

        drawBBox(box, sceneBoxLineColor, sceneBoxLineColor, sceneBoxLineColor, 0.1f, 2.0, true);

        /* MeshModel* currentModel = m.mm();
        if (currentModel == NULL)
        {
            break;
        }
        //判断模型是否在盒子内部
        if (box.Collide(currentModel->cm.bbox))
        {
            setModelColor(gla, *currentModel, vcg::Color4b(Color4b::DarkGray));
        }
        else
        {
            setModelColor(gla, *currentModel, vcg::Color4b(Color4b::Gray));
        } */

        break;
    }
    case DP_SHOW_LOGSTREAM:
    {
        QString dir = QCoreApplication::applicationDirPath();
        QStringList logList;
        logStream.print(logList);
        QFile file(dir + tr("/log.txt"));
        file.open(QIODevice::WriteOnly | QIODevice::Append);
        QTextStream text_stream(&file);
        for (int i = 0; i < logList.length(); i++)
        {
#ifdef  _WIN32
            text_stream << logList[i] << tr("\r\n");
#elif __linux__
            text_stream << logList[i] << tr("\n");
#endif //  _WIN32
        }
        qDebug() << tr("Log: ") << logList;
        break;
    }

    case DP_SHOW_NORMAL:
    {
        MeshModel* currentModel = m.mm();
        if (currentModel == NULL)
        {
            break;
        }
        Matrix44m tempMat = currentModel->cm.Tr;
        Matrix44m currTr = vcg::Transpose(tempMat);
        
        float size = 10.0f;
        glColor3f(1.0f, 1.0f, 0.0f);
        glLineWidth(0.5);
        glPushMatrix();
        glMultMatrixf(currTr.V());

        glBegin(GL_LINES);
        for (CMeshO::VertexIterator vi = m.mm()->cm.vert.begin(); vi != m.mm()->cm.vert.end(); vi++)
        {
            glVertex((*vi).P());
            glVertex((*vi).P() + (*vi).N() * size);
        }
        glEnd();
        //glLineWidth(1.0f);
       
        glPopMatrix();
        
        break;
    }
    }
}

void AnkerScenePlugin::initGlobalParameterList(const QAction *action, RichParameterList &parset)
{
    if (action == NULL)
        return;
    switch(ID(action))
    {
   
    }
}




void AnkerScenePlugin::setSceneBox(const vcg::Box3f& box, GLfloat d)
{
    sceneBox = box;
    Point3f min = sceneBox.min;
    Point3f max = sceneBox.max;

    setSceneCenterPlane(MyPlane(Point3f(min[0] + d, min[1] + d, min[2]), Point3f(max[0] - d, min[1] + d, min[2]),
        Point3f(max[0] - d, max[1] - d, min[2]), Point3f(min[0] + d, max[1] - d, min[2])));
}

void AnkerScenePlugin::setSceneCenterPlane(const MyPlane& plane)
{
    sceneCenterPln = plane;
}

void AnkerScenePlugin::setSceneBoxLineColor(const GLfloat* color)
{
    if (color != NULL)
    {
        for (int i = 0; i < 3; i++)
        {
            sceneBoxLineColor[i] = color[i];
        }
    }
}


void AnkerScenePlugin::drawBBox(const Box3m& b, const GLfloat* Xrgb, const GLfloat* Yrgb, const GLfloat* Zrgb, GLfloat lineWidth, float boxSize, bool isSceneBox)
{
    if (Xrgb == NULL || Yrgb == NULL || Zrgb == NULL)
    {
        return;
    }
    vcg::Point3f sp = b.Dim();
    float size = sqrtf(sp.X() * sp.X() + sp.Y() * sp.Y() + sp.Z() * sp.Z());
    qDebug() << tr("BBox Size: ") << size;
    Point3m mi = b.min;
    Point3m ma = b.max;
    Point3m d3 = (b.max - b.min) / boxSize;
    Point3m zz(0, 0, 0);

    // setup
    glPushAttrib(GL_ALL_ATTRIB_BITS);
    glDisable(GL_LIGHTING);
    glDisable(GL_TEXTURE_2D);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glEnable(GL_LINE_SMOOTH);
    glEnable(GL_MULTISAMPLE);
    glEnable(GL_DEPTH_TEST);
    glLineWidth(lineWidth);
    glDepthMask(GL_FALSE);
    //Get gl state values
    double mm[16];
    double mp[16];
    GLint vp[4];
    glGetDoublev(GL_MODELVIEW_MATRIX, mm);
    glGetDoublev(GL_PROJECTION_MATRIX, mp);
    glGetIntegerv(GL_VIEWPORT, vp);

    glPushMatrix();
    //画盒子
    glBegin(GL_LINES);
    glColor3f(Xrgb[0], Xrgb[1], Xrgb[2]); glVertex3f(mi[0], mi[1], mi[2]); glVertex3f(mi[0] + d3[0], mi[1] + zz[1], mi[2] + zz[2]);
    glColor3f(Yrgb[0], Yrgb[1], Yrgb[2]); glVertex3f(mi[0], mi[1], mi[2]); glVertex3f(mi[0] + zz[0], mi[1] + d3[1], mi[2] + zz[2]);
    glColor3f(Zrgb[0], Zrgb[1], Zrgb[2]); glVertex3f(mi[0], mi[1], mi[2]); glVertex3f(mi[0] + zz[0], mi[1] + zz[1], mi[2] + d3[2]);

    glColor3f(Xrgb[0], Xrgb[1], Xrgb[2]); glVertex3f(ma[0], mi[1], mi[2]); glVertex3f(ma[0] - d3[0], mi[1] + zz[1], mi[2] + zz[2]);
    glColor3f(Yrgb[0], Yrgb[1], Yrgb[2]); glVertex3f(ma[0], mi[1], mi[2]); glVertex3f(ma[0] + zz[0], mi[1] + d3[1], mi[2] + zz[2]);
    glColor3f(Zrgb[0], Zrgb[1], Zrgb[2]); glVertex3f(ma[0], mi[1], mi[2]); glVertex3f(ma[0] + zz[0], mi[1] + zz[1], mi[2] + d3[2]);

    glColor3f(Xrgb[0], Xrgb[1], Xrgb[2]); glVertex3f(mi[0], ma[1], mi[2]); glVertex3f(mi[0] + d3[0], ma[1] + zz[1], mi[2] + zz[2]);
    glColor3f(Yrgb[0], Yrgb[1], Yrgb[2]); glVertex3f(mi[0], ma[1], mi[2]); glVertex3f(mi[0] + zz[0], ma[1] - d3[1], mi[2] + zz[2]);
    glColor3f(Zrgb[0], Zrgb[1], Zrgb[2]); glVertex3f(mi[0], ma[1], mi[2]); glVertex3f(mi[0] + zz[0], ma[1] + zz[1], mi[2] + d3[2]);

    glColor3f(Xrgb[0], Xrgb[1], Xrgb[2]); glVertex3f(ma[0], ma[1], mi[2]); glVertex3f(ma[0] - d3[0], ma[1] + zz[1], mi[2] + zz[2]);
    glColor3f(Yrgb[0], Yrgb[1], Yrgb[2]); glVertex3f(ma[0], ma[1], mi[2]); glVertex3f(ma[0] + zz[0], ma[1] - d3[1], mi[2] + zz[2]);
    glColor3f(Zrgb[0], Zrgb[1], Zrgb[2]); glVertex3f(ma[0], ma[1], mi[2]); glVertex3f(ma[0] + zz[0], ma[1] + zz[1], mi[2] + d3[2]);

    glColor3f(Xrgb[0], Xrgb[1], Xrgb[2]); glVertex3f(mi[0], mi[1], ma[2]); glVertex3f(mi[0] + d3[0], mi[1] + zz[1], ma[2] + zz[2]);
    glColor3f(Yrgb[0], Yrgb[1], Yrgb[2]); glVertex3f(mi[0], mi[1], ma[2]); glVertex3f(mi[0] + zz[0], mi[1] + d3[1], ma[2] + zz[2]);
    glColor3f(Zrgb[0], Zrgb[1], Zrgb[2]); glVertex3f(mi[0], mi[1], ma[2]); glVertex3f(mi[0] + zz[0], mi[1] + zz[1], ma[2] - d3[2]);

    glColor3f(Xrgb[0], Xrgb[1], Xrgb[2]); glVertex3f(ma[0], mi[1], ma[2]); glVertex3f(ma[0] - d3[0], mi[1] + zz[1], ma[2] + zz[2]);
    glColor3f(Yrgb[0], Yrgb[1], Yrgb[2]); glVertex3f(ma[0], mi[1], ma[2]); glVertex3f(ma[0] + zz[0], mi[1] + d3[1], ma[2] + zz[2]);
    glColor3f(Zrgb[0], Zrgb[1], Zrgb[2]); glVertex3f(ma[0], mi[1], ma[2]); glVertex3f(ma[0] + zz[0], mi[1] + zz[1], ma[2] - d3[2]);

    glColor3f(Xrgb[0], Xrgb[1], Xrgb[2]); glVertex3f(mi[0], ma[1], ma[2]); glVertex3f(mi[0] + d3[0], ma[1] + zz[1], ma[2] + zz[2]);
    glColor3f(Yrgb[0], Yrgb[1], Yrgb[2]); glVertex3f(mi[0], ma[1], ma[2]); glVertex3f(mi[0] + zz[0], ma[1] - d3[1], ma[2] + zz[2]);
    glColor3f(Zrgb[0], Zrgb[1], Zrgb[2]); glVertex3f(mi[0], ma[1], ma[2]); glVertex3f(mi[0] + zz[0], ma[1] + zz[1], ma[2] - d3[2]);

    glColor3f(Xrgb[0], Xrgb[1], Xrgb[2]); glVertex3f(ma[0], ma[1], ma[2]); glVertex3f(ma[0] - d3[0], ma[1] + zz[1], ma[2] + zz[2]);
    glColor3f(Yrgb[0], Yrgb[1], Yrgb[2]); glVertex3f(ma[0], ma[1], ma[2]); glVertex3f(ma[0] + zz[0], ma[1] - d3[1], ma[2] + zz[2]);
    glColor3f(Zrgb[0], Zrgb[1], Zrgb[2]); glVertex3f(ma[0], ma[1], ma[2]); glVertex3f(ma[0] + zz[0], ma[1] + zz[1], ma[2] - d3[2]);
    glEnd();

    if (isSceneBox)
    {
        //开启面的深度偏移
        glEnable(GL_POLYGON_OFFSET_FILL);
        glPolygonOffset(1.0f, -1.0f);
        //画底面
        glBegin(GL_TRIANGLES);
        glColor4f(0.376f, 0.376f, 0.376f, 0.5f); glVertex3f(mi[0], mi[1], mi[2]); glVertex3f(ma[0], mi[1], mi[2]); glVertex3f(mi[0], mi[1] + div, mi[2]);
        glColor4f(0.376f, 0.376f, 0.376f, 0.5f); glVertex3f(ma[0], mi[1] + div, mi[2]); glVertex3f(ma[0], mi[1], mi[2]); glVertex3f(mi[0], mi[1] + div, mi[2]);

        glColor4f(0.376f, 0.376f, 0.376f, 0.5f); glVertex3f(mi[0], mi[1] + div, mi[2]); glVertex3f(mi[0] + div, mi[1] + div, mi[2]); glVertex3f(mi[0], ma[1], mi[2]);
        glColor4f(0.376f, 0.376f, 0.376f, 0.5f); glVertex3f(mi[0] + div, ma[1], mi[2]); glVertex3f(mi[0] + div, mi[1] + div, mi[2]); glVertex3f(mi[0], ma[1], mi[2]);

        glColor4f(0.376f, 0.376f, 0.376f, 0.5f); glVertex3f(mi[0] + div, ma[1], mi[2]); glVertex3f(mi[0] + div, ma[1] - div, mi[2]); glVertex3f(ma[0], ma[1] - div, mi[2]);
        glColor4f(0.376f, 0.376f, 0.376f, 0.5f); glVertex3f(ma[0], ma[1], mi[2]); glVertex3f(mi[0] + div, ma[1], mi[2]); glVertex3f(ma[0], ma[1] - div, mi[2]);

        glColor4f(0.376f, 0.376f, 0.376, 0.5f); glVertex3f(ma[0] - div, ma[1] - div, mi[2]); glVertex3f(ma[0], ma[1] - div, mi[2]); glVertex3f(ma[0], mi[1] + div, mi[2]);
        glColor4f(0.376f, 0.376f, 0.376f, 0.5f); glVertex3f(ma[0] - div, mi[1] + div, mi[2]); glVertex3f(ma[0], mi[1] + div, mi[2]); glVertex3f(ma[0] - div, ma[1] - div, mi[2]);


        glColor4f(1.0f, 1.0f, 1.0f, 0.5f); glVertex3f(mi[0] + div, mi[1] + div, mi[2]); glVertex3f(ma[0] - div, mi[1] + div, mi[2]); glVertex3f(mi[0] + div, ma[1] - div, mi[2]);
        glColor4f(1.0f, 1.0f, 1.0f, 0.5f); glVertex3f(ma[0] - div, ma[1] - div, mi[2]); glVertex3f(ma[0] - div, mi[1] + div, mi[2]); glVertex3f(mi[0] + div, ma[1] - div, mi[2]);
        glEnd(); 
        
        glColor4f(0.0f, 0.0f, 0.0f, 0.5f);
        glLineWidth(0.1f);
        
        //画底面网格线
        for (int i = 0; i <= (ma[0] - mi[0]) / tick; i++)
        {
            glBegin(GL_LINES);
            glVertex3f(mi[0] + i * tick, mi[1], mi[2]);
            glVertex3f(mi[0] + i * tick, ma[1], mi[2]);
            glEnd();
        }

       glColor4f(0.0f, 0.0f, 0.0f, 0.5f);
      
       for (int i = 0; i <= (ma[1] - mi[1]) / tick; i++)
        {
            glBegin(GL_LINES);
            glVertex3f(mi[0], mi[1] + i * tick, mi[2]);
            glVertex3f(ma[0], mi[1] + i * tick, mi[2]);
            glEnd();
        }

       
    }
    isSceneBox = false;
    glDepthMask(GL_TRUE);
    glPopMatrix();
    glPopAttrib();
}

void AnkerScenePlugin::setModelColor(GLArea* gla, MeshModel& model, vcg::Color4b color)
{
    MLSceneGLSharedDataContext* datacont = gla->mvc()->sharedDataContext();
    if (datacont == NULL)
        return;
    MLRenderingData curr;
    datacont->getRenderInfoPerMeshView(model.id(), gla->context(), curr);
    MLPerViewGLOptions opts;
    if (curr.get(opts) == false)
        throw MLException(QString("GLArea: invalid MLPerViewGLOptions"));
    opts._persolid_fixed_color_enabled = true;
    opts._persolid_fixed_color = color;

    curr.set(opts);
    datacont->setRenderingDataPerMeshView(model.id(), gla->context(), curr);
}

void AnkerScenePlugin::sideShow(const SideShow::SideShowType type, GLArea* gla, MeshModel& model, const MLPerViewGLOptions& opts)
{
    SideShow sShow(type, gla, model, opts);
}

void AnkerScenePlugin::drawCurrentModelBox(const MeshModel& model, float width, float boxSize, const QColor& color)
{
    vcg::Color4f c(color.red(), color.green(), color.blue(), color.alpha());
    Matrix44m tmpMat = model.cm.Tr;
    vcg::Box3f b = model.cm.bbox;
    Point3m mi = b.min;
    Point3m ma = b.max;
    Point3m d3 = (b.max - b.min) / boxSize;
    Point3m zz(0, 0, 0);
    vcg::Transpose(tmpMat);
    glLineWidth(width);
    glPushMatrix();
    glMultMatrixf(tmpMat.V());
    //画盒子
    glBegin(GL_LINES);
    glColor3f(c.X(), c.Y(), c.Z()); glVertex3f(mi[0], mi[1], mi[2]); glVertex3f(mi[0] + d3[0], mi[1] + zz[1], mi[2] + zz[2]);
    glColor3f(c.X(), c.Y(), c.Z()); glVertex3f(mi[0], mi[1], mi[2]); glVertex3f(mi[0] + zz[0], mi[1] + d3[1], mi[2] + zz[2]);
    glColor3f(c.X(), c.Y(), c.Z()); glVertex3f(mi[0], mi[1], mi[2]); glVertex3f(mi[0] + zz[0], mi[1] + zz[1], mi[2] + d3[2]);

    glColor3f(c.X(), c.Y(), c.Z()); glVertex3f(ma[0], mi[1], mi[2]); glVertex3f(ma[0] - d3[0], mi[1] + zz[1], mi[2] + zz[2]);
    glColor3f(c.X(), c.Y(), c.Z()); glVertex3f(ma[0], mi[1], mi[2]); glVertex3f(ma[0] + zz[0], mi[1] + d3[1], mi[2] + zz[2]);
    glColor3f(c.X(), c.Y(), c.Z()); glVertex3f(ma[0], mi[1], mi[2]); glVertex3f(ma[0] + zz[0], mi[1] + zz[1], mi[2] + d3[2]);

    glColor3f(c.X(), c.Y(), c.Z()); glVertex3f(mi[0], ma[1], mi[2]); glVertex3f(mi[0] + d3[0], ma[1] + zz[1], mi[2] + zz[2]);
    glColor3f(c.X(), c.Y(), c.Z()); glVertex3f(mi[0], ma[1], mi[2]); glVertex3f(mi[0] + zz[0], ma[1] - d3[1], mi[2] + zz[2]);
    glColor3f(c.X(), c.Y(), c.Z()); glVertex3f(mi[0], ma[1], mi[2]); glVertex3f(mi[0] + zz[0], ma[1] + zz[1], mi[2] + d3[2]);

    glColor3f(c.X(), c.Y(), c.Z()); glVertex3f(ma[0], ma[1], mi[2]); glVertex3f(ma[0] - d3[0], ma[1] + zz[1], mi[2] + zz[2]);
    glColor3f(c.X(), c.Y(), c.Z()); glVertex3f(ma[0], ma[1], mi[2]); glVertex3f(ma[0] + zz[0], ma[1] - d3[1], mi[2] + zz[2]);
    glColor3f(c.X(), c.Y(), c.Z()); glVertex3f(ma[0], ma[1], mi[2]); glVertex3f(ma[0] + zz[0], ma[1] + zz[1], mi[2] + d3[2]);

    glColor3f(c.X(), c.Y(), c.Z()); glVertex3f(mi[0], mi[1], ma[2]); glVertex3f(mi[0] + d3[0], mi[1] + zz[1], ma[2] + zz[2]);
    glColor3f(c.X(), c.Y(), c.Z()); glVertex3f(mi[0], mi[1], ma[2]); glVertex3f(mi[0] + zz[0], mi[1] + d3[1], ma[2] + zz[2]);
    glColor3f(c.X(), c.Y(), c.Z()); glVertex3f(mi[0], mi[1], ma[2]); glVertex3f(mi[0] + zz[0], mi[1] + zz[1], ma[2] - d3[2]);

    glColor3f(c.X(), c.Y(), c.Z()); glVertex3f(ma[0], mi[1], ma[2]); glVertex3f(ma[0] - d3[0], mi[1] + zz[1], ma[2] + zz[2]);
    glColor3f(c.X(), c.Y(), c.Z()); glVertex3f(ma[0], mi[1], ma[2]); glVertex3f(ma[0] + zz[0], mi[1] + d3[1], ma[2] + zz[2]);
    glColor3f(c.X(), c.Y(), c.Z()); glVertex3f(ma[0], mi[1], ma[2]); glVertex3f(ma[0] + zz[0], mi[1] + zz[1], ma[2] - d3[2]);

    glColor3f(c.X(), c.Y(), c.Z()); glVertex3f(mi[0], ma[1], ma[2]); glVertex3f(mi[0] + d3[0], ma[1] + zz[1], ma[2] + zz[2]);
    glColor3f(c.X(), c.Y(), c.Z()); glVertex3f(mi[0], ma[1], ma[2]); glVertex3f(mi[0] + zz[0], ma[1] - d3[1], ma[2] + zz[2]);
    glColor3f(c.X(), c.Y(), c.Z()); glVertex3f(mi[0], ma[1], ma[2]); glVertex3f(mi[0] + zz[0], ma[1] + zz[1], ma[2] - d3[2]);

    glColor3f(c.X(), c.Y(), c.Z()); glVertex3f(ma[0], ma[1], ma[2]); glVertex3f(ma[0] - d3[0], ma[1] + zz[1], ma[2] + zz[2]);
    glColor3f(c.X(), c.Y(), c.Z()); glVertex3f(ma[0], ma[1], ma[2]); glVertex3f(ma[0] + zz[0], ma[1] - d3[1], ma[2] + zz[2]);
    glColor3f(c.X(), c.Y(), c.Z()); glVertex3f(ma[0], ma[1], ma[2]); glVertex3f(ma[0] + zz[0], ma[1] + zz[1], ma[2] - d3[2]);
    glEnd();
    glPopMatrix();
}

void AnkerScenePlugin::drawCurrentModelBox(MeshModel& model)
{
    GLfloat Xrgb[3] = {1.0, 0.5, 0.5};
    GLfloat Yrgb[3] = { 0.5, 1.0, 0.5 };
    GLfloat Zrgb[3] = { 0.5, 0.5, 1.0 };
    drawBBox(model.cm.bbox, Xrgb, Yrgb, Zrgb, 20.0f, 4.0);
}

void AnkerScenePlugin::initPluginGui(QMainWindow* wm)
{
    QList<QAction*> allAction = wm->menuBar()->actions();
    QAction* viewAction = NULL;
    QAction* renderAction = NULL;
    QAction* sceneAction = NULL;

    for (QAction* action : allAction)
    {
        if (action->text() == tr("&Scene"))
        {
            sceneAction = action;
        }
        else if (action->text() == tr("&Render"))
        {
            renderAction = action;
        }
        else if (action->text() == tr("&View"))
        {
            viewAction = action;
        }
    }
    if (viewAction == NULL || renderAction == NULL)
    {
        return;
    }
    QMenu* sceneMenu = NULL;
    if (sceneAction == NULL)
    {
        //在View前插入Scene菜单
        sceneMenu = new QMenu(tr("&Scene"));
        wm->menuBar()->insertMenu(viewAction, sceneMenu);
    }
    else
    {
        sceneMenu = sceneAction->menu();
    }
    QMenu* perspectiveMenu = new QMenu(tr("&Perspective"));
    QList<QAction*> sceneAllAction = sceneMenu->actions();
    if (sceneAllAction.size() == 0)
    {
        sceneMenu->addMenu(perspectiveMenu);
    }
    else if (sceneAllAction.size() > 0)
    {
        sceneMenu->insertMenu(sceneMenu->actions()[0], perspectiveMenu);
    }

    
    for (QAction* action : actionList)
    {
        if (action->text() == FRONTSTR ||
            action->text() == BACKSTR ||
            action->text() == RIGHTSTR ||
            action->text() == LEFTSTR ||
            action->text() == TOPSTR ||
            action->text() == BOTTOMSTR ||

            action->text() == TOP_Z_IS_UP_STR ||
            action->text() == BOTTOM_Z_IS_UP_STR ||
            action->text() == LEFT_Z_IS_UP_STR ||
            action->text() == RIGHT_Z_IS_UP_STR ||
            action->text() == FRONT_Z_IS_UP_STR ||
            action->text() == BACK_Z_IS_UP_STR ||

            action->text() == HORIZONTAL_PLUS_STR ||
            action->text() == HORIZONTAL_SUBTRACT_STR ||
            action->text() == VERTICAL_PLUS_STR ||
            action->text() == VERTICAL_SUBTRACT_STR ||
            action->text() == AXIAL_PLUS_STR ||
            action->text() == AXIAL_SUBTRACT_STR
            )
        {
            perspectiveMenu->addAction(action);
        }
        else if (action->text() == WORLD_COORDINATE_NAME_STR)
        {
            sceneMenu->insertAction(perspectiveMenu->menuAction(), action);
        }
        else if (action->text() == LOCAL_COORDINATE_NAME_STR)
        {
            sceneMenu->insertAction(perspectiveMenu->menuAction(), action);
        }
        else if (action->text() == LOCAL_BBOX_NAME_STR)
        {
            sceneMenu->insertAction(perspectiveMenu->menuAction(), action);
        }
        else if (action->text() == WORLD_BBOX_NAME_STR)
        {
            sceneMenu->insertAction(perspectiveMenu->menuAction(), action);
        }
        else if (action->text() == SCENE_CENTER_PLANE_NAME_STR)
        {
            sceneMenu->insertAction(perspectiveMenu->menuAction(), action);
        }
        else if (action->text() == RICHPARAMETER_STR)
        {
            sceneMenu->insertAction(perspectiveMenu->menuAction(), action);
        }
        else if (action->text() == LOGSTREAM_STR)
        {
            sceneMenu->insertAction(perspectiveMenu->menuAction(), action);
        }
        else if (action->text() == PERSPECTIVE_PROJECTION_STR)
        {
            sceneMenu->insertAction(perspectiveMenu->menuAction(), action);
        }
        else if (action->text() == PARALLERL_PROJECTION_STR)
        {
            sceneMenu->insertAction(perspectiveMenu->menuAction(), action);
        }
        else if (action->text() == SHOW_NORMAL_STR)
        {
            sceneMenu->insertAction(perspectiveMenu->menuAction(), action);
        }
        else if (action->text() == SHOW_FACE_RENDER_STR)
        {
            sceneMenu->insertAction(perspectiveMenu->menuAction(), action);
        }
        else if (action->text() == SHOW_POINTS_RENDER_STR)
        {
            sceneMenu->insertAction(perspectiveMenu->menuAction(), action);
        }
        else if (action->text() == SHOW_WIREFRAME_RENDER_STR)
        {
            sceneMenu->insertAction(perspectiveMenu->menuAction(), action);
        }
        else if (action->text() == SHOW_VERT_RENDER_STR)
        {
            sceneMenu->insertAction(perspectiveMenu->menuAction(), action);
        }

        //添加快捷键
        if (action->text() == FRONTSTR)
        {
            //action->setShortcut(tr("a"));
        }

        //移除在Render下插件默认添加的Action
        renderAction->menu()->removeAction(action);
    }
}

void AnkerScenePlugin::addActionToMenu(QMenu* menu)
{
    if (menu == nullptr)
        return;
    QMenu* sceneMenu = new QMenu(tr("Scene"), NULL);

    QMenu* perspectiveMenu = new QMenu(tr("&Perspective"));
    QList<QAction*> sceneAllAction = sceneMenu->actions();
    if (sceneAllAction.size() == 0)
    {
        sceneMenu->addMenu(perspectiveMenu);
    }
    else if (sceneAllAction.size() > 0)
    {
        sceneMenu->insertMenu(sceneMenu->actions()[0], perspectiveMenu);
    }

    menu->addMenu(sceneMenu);

    for (QAction* action : actionList)
    {
        if (action->text() == FRONTSTR ||
            action->text() == BACKSTR ||
            action->text() == RIGHTSTR ||
            action->text() == LEFTSTR ||
            action->text() == TOPSTR ||
            action->text() == BOTTOMSTR ||
            action->text() == THREEDSTR ||

            action->text() == TOP_Z_IS_UP_STR ||
            action->text() == BOTTOM_Z_IS_UP_STR ||
            action->text() == LEFT_Z_IS_UP_STR ||
            action->text() == RIGHT_Z_IS_UP_STR ||
            action->text() == FRONT_Z_IS_UP_STR ||
            action->text() == BACK_Z_IS_UP_STR ||

            action->text() == HORIZONTAL_PLUS_STR ||
            action->text() == HORIZONTAL_SUBTRACT_STR ||
            action->text() == VERTICAL_PLUS_STR ||
            action->text() == VERTICAL_SUBTRACT_STR ||
            action->text() == AXIAL_PLUS_STR ||
            action->text() == AXIAL_SUBTRACT_STR
            )
        {
            perspectiveMenu->addAction(action);
        }
        else if (action->text() == WORLD_COORDINATE_NAME_STR)
        {
            sceneMenu->insertAction(perspectiveMenu->menuAction(), action);
        }
        else if (action->text() == LOCAL_COORDINATE_NAME_STR)
        {
            sceneMenu->insertAction(perspectiveMenu->menuAction(), action);
        }
        else if (action->text() == LOCAL_BBOX_NAME_STR)
        {
            sceneMenu->insertAction(perspectiveMenu->menuAction(), action);
        }
        else if (action->text() == WORLD_BBOX_NAME_STR)
        {
            sceneMenu->insertAction(perspectiveMenu->menuAction(), action);
        }
        else if (action->text() == SCENE_CENTER_PLANE_NAME_STR)
        {
            sceneMenu->insertAction(perspectiveMenu->menuAction(), action);
        }
        else if (action->text() == RICHPARAMETER_STR)
        {
            sceneMenu->insertAction(perspectiveMenu->menuAction(), action);
        }
        else if (action->text() == LOGSTREAM_STR)
        {
            sceneMenu->insertAction(perspectiveMenu->menuAction(), action);
        }
        else if (action->text() == PERSPECTIVE_PROJECTION_STR)
        {
            sceneMenu->insertAction(perspectiveMenu->menuAction(), action);
        }
        else if (action->text() == PARALLERL_PROJECTION_STR)
        {
            sceneMenu->insertAction(perspectiveMenu->menuAction(), action);
        }
        else if (action->text() == SHOW_NORMAL_STR)
        {
            sceneMenu->insertAction(perspectiveMenu->menuAction(), action);
        }
        else if (action->text() == SHOW_FACE_RENDER_STR)
        {
            sceneMenu->insertAction(perspectiveMenu->menuAction(), action);
        }
        else if (action->text() == SHOW_POINTS_RENDER_STR)
        {
            sceneMenu->insertAction(perspectiveMenu->menuAction(), action);
        }
        else if (action->text() == SHOW_WIREFRAME_RENDER_STR)
        {
            sceneMenu->insertAction(perspectiveMenu->menuAction(), action);
        }
        else if (action->text() == SHOW_VERT_RENDER_STR)
        {
            sceneMenu->insertAction(perspectiveMenu->menuAction(), action);
        }
        else if (action->text() == SHOW_THRESHOLD_STR)
        {
            sceneMenu->insertAction(perspectiveMenu->menuAction(), action);
        }

        //添加快捷键
        if (action->text() == FRONTSTR)
        {
            //action->setShortcut(tr("a"));
        }
    }
}

void AnkerScenePlugin::recMsgfromManager(PluginMessageData metaData)
{
    qDebug() << tr("AnkerScenePlugin...\n");
    if (metaData.msg == QString("Plugin UI initialization running in the QMainWindow constructor")
        && metaData.object != NULL)
    {
        initPluginGui(qobject_cast<QMainWindow*>(metaData.object));
    }
    
}

void AnkerScenePlugin::initialize(ControlInterface* controlmanager, RichParameterList* globalParameterList)
{
    if (controlmanager == nullptr || globalParameterList == nullptr)
    {
        return;
    }
    QWidget* viewWidget = new QWidget;
    QHBoxLayout* hLayout = new QHBoxLayout;
    viewWidget->setLayout(hLayout);

    QToolButton* threedButton = new QToolButton;
    threedButton->setIconSize(QSize(80, 80));
    threedButton->setGeometry(0, 0, 100, 100);  
    threedButton->setAutoRaise(true);
    threedButton->setToolButtonStyle(Qt::ToolButtonTextUnderIcon);
    threedButton->setText(tr("3D"));
    hLayout->addWidget(threedButton);

    QToolButton* topButton = new QToolButton;
    topButton->setIconSize(QSize(80, 80));
    topButton->setGeometry(0, 0, 100, 100);  
    topButton->setAutoRaise(true);
    topButton->setToolButtonStyle(Qt::ToolButtonTextUnderIcon);
    topButton->setText(tr("Top"));
    hLayout->addWidget(topButton);

    QToolButton* bottomButton = new QToolButton;
    bottomButton->setIconSize(QSize(80, 80));
    bottomButton->setGeometry(0, 0, 100, 100); 
    bottomButton->setAutoRaise(true);
    bottomButton->setToolButtonStyle(Qt::ToolButtonTextUnderIcon);
    bottomButton->setText(tr("Bottom"));
    hLayout->addWidget(bottomButton);

    QToolButton* leftButton = new QToolButton;
    leftButton->setIconSize(QSize(80, 80));
    leftButton->setGeometry(0, 0, 100, 100); 
    leftButton->setAutoRaise(true);
    leftButton->setToolButtonStyle(Qt::ToolButtonTextUnderIcon);
    leftButton->setText(tr("Left"));
    hLayout->addWidget(leftButton);

    QToolButton* rightButton = new QToolButton;
    rightButton->setIconSize(QSize(80, 80));
    rightButton->setGeometry(0, 0, 100, 100); 
    rightButton->setAutoRaise(true);
    rightButton->setToolButtonStyle(Qt::ToolButtonTextUnderIcon);
    rightButton->setText(tr("Right"));
    hLayout->addWidget(rightButton);

    QToolButton* frontButton = new QToolButton;
    frontButton->setIconSize(QSize(80, 80));
    frontButton->setGeometry(0, 0, 100, 100);  
    frontButton->setAutoRaise(true);
    frontButton->setToolButtonStyle(Qt::ToolButtonTextUnderIcon);
    frontButton->setText(tr("Front"));
    hLayout->addWidget(frontButton);

    QToolButton* backButton = new QToolButton;
    backButton->setIconSize(QSize(80, 80));
    backButton->setGeometry(0, 0, 100, 100);  
    backButton->setAutoRaise(true);
    backButton->setToolButtonStyle(Qt::ToolButtonTextUnderIcon);
    backButton->setText(tr("Back"));
    hLayout->addWidget(backButton);


    for (QAction* action : actionList)
    {
        switch (ID(action))
        {
        case DP_SHOW_THREED:
            threedButton->setDefaultAction(action);
            break;
        case DP_SHOW_TOP_Z_IS_UP:
            topButton->setDefaultAction(action);
            break;
        case DP_SHOW_BOTTOM_Z_IS_UP:
            bottomButton->setDefaultAction(action);
            break;
        case DP_SHOW_LEFT_Z_IS_UP:
            leftButton->setDefaultAction(action);
            break;
        case DP_SHOW_RIGHT_Z_IS_UP:
            rightButton->setDefaultAction(action);
            break;
        case DP_SHOW_FRONT_Z_IS_UP:
            frontButton->setDefaultAction(action);
            break;
        case DP_SHOW_BACK_Z_IS_UP:
            backButton->setDefaultAction(action);
            break;
        default:
            break;
        }

    }

    controlmanager->addWidgetToView(viewWidget);
    QMenu* menu = controlmanager->addMenu(control::constants::M_SCENE);
    if (menu != nullptr)
    {
        addActionToMenu(menu);
    }
}

MESHLAB_PLUGIN_NAME_EXPORTER(AnkerScenePlugin)
