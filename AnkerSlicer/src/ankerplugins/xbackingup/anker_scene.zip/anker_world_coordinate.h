/****************************************************************************
* MeshLab                                                           o o     *
* A versatile mesh processing toolbox                             o     o   *
*                                                                _   O  _   *
* Copyright(C) 2005                                                \/)\/    *
* Visual Computing Lab                                            /\/|      *
* ISTI - Italian National Research Council                           |      *
*                                                                    \      *
* All rights reserved.                                                      *
*                                                                           *
* This program is free software; you can redistribute it and/or modify      *
* it under the terms of the GNU General Public License as published by      *
* the Free Software Foundation; either version 2 of the License, or         *
* (at your option) any later version.                                       *
*                                                                           *
* This program is distributed in the hope that it will be useful,           *
* but WITHOUT ANY WARRANTY; without even the implied warranty of            *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
* GNU General Public License (http://www.gnu.org/licenses/gpl.txt)          *
* for more details.                                                         *
*                                                                           *
****************************************************************************/
/****************************************************************************
Revision 0.1  2021/10/27 12:10:53  Aden Hu
****************************************************************************/

#ifndef ANKER_WORLD_COORLDINATE_H
#define ANKER_WORLD_COORLDINATE_H

#include <wrap/gui/coordinateframe.h>
using namespace vcg;

#define WORLD_COORDINATE_NAME_STR tr("Show World Coordinate")
#define LOCAL_COORDINATE_NAME_STR tr("Show Local Coordinate")

#define LOCAL_BBOX_NAME_STR tr("Show Model Box")
#define WORLD_BBOX_NAME_STR tr("Show Scene Box")
#define SCENE_CENTER_PLANE_NAME_STR tr("Show Center Plane")

class AnkerWorldCoordinate : public MovableCoordinateFrame
{
public:
	AnkerWorldCoordinate(float size, const Point3f& p = Point3f(0.0f, 0.0f, 0.0f), const Quaternionf& r = Quaternionf(0, Point3f(0, 0, 1)));

	virtual ~AnkerWorldCoordinate() {}

	virtual void Render(QGLWidget* glw, QPainter* p = NULL);
};


class AnkerLocalCoordinate : public MovableCoordinateFrame
{
public:
	AnkerLocalCoordinate(float size, const Point3f& p = Point3f(0.0f, 0.0f, 0.0f), const Quaternionf& r = Quaternionf(0, Point3f(0, 0, 1)));
	AnkerLocalCoordinate(float size, const Matrix44f& m);
	virtual ~AnkerLocalCoordinate() {}

	virtual void Render(QGLWidget* glw, QPainter* p = NULL);

private:
	Matrix44f m_matrix;
};

class LocalCoordinate
{
public:
	LocalCoordinate(float size, const Point3f &p, const Matrix44f& m);

	void render();

private:
	Matrix44f m_matrix;
	float m_size;
	Point3f m_center;
	float m_linewidth;
};




#endif // !ANKER_WORLD_COORLDINATE_H
