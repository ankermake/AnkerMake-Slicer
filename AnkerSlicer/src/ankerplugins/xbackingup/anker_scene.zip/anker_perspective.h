/****************************************************************************
* MeshLab                                                           o o     *
* A versatile mesh processing toolbox                             o     o   *
*                                                                _   O  _   *
* Copyright(C) 2005                                                \/)\/    *
* Visual Computing Lab                                            /\/|      *
* ISTI - Italian National Research Council                           |      *
*                                                                    \      *
* All rights reserved.                                                      *
*                                                                           *
* This program is free software; you can redistribute it and/or modify      *
* it under the terms of the GNU General Public License as published by      *
* the Free Software Foundation; either version 2 of the License, or         *
* (at your option) any later version.                                       *
*                                                                           *
* This program is distributed in the hope that it will be useful,           *
* but WITHOUT ANY WARRANTY; without even the implied warranty of            *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
* GNU General Public License (http://www.gnu.org/licenses/gpl.txt)          *
* for more details.                                                         *
*                                                                           *
****************************************************************************/
/****************************************************************************
Revision 0.1  2021/10/27 12:03:03  Aden Hu
****************************************************************************/


#ifndef ANKER_PERSPECTIVE_H
#define ANKER_PERSPECTIVE_H
#include <GL/glew.h>
#include <meshlab/glarea.h>
#include <QObject>
#include <QString>

#define FRONTSTR tr("Front")
#define BACKSTR tr("Back")
#define RIGHTSTR tr("Right")
#define LEFTSTR tr("Left")
#define TOPSTR tr("Top")
#define BOTTOMSTR tr("Bottom")
#define THREEDSTR tr("3D View")

#define TOP_Z_IS_UP_STR tr("Top View")
#define BOTTOM_Z_IS_UP_STR tr("Bottom View")
#define LEFT_Z_IS_UP_STR tr("Left View")
#define RIGHT_Z_IS_UP_STR tr("Right View")
#define FRONT_Z_IS_UP_STR tr("Front View")
#define BACK_Z_IS_UP_STR tr("Back View")

#define HORIZONTAL_PLUS_STR tr("Horizontal +")
#define HORIZONTAL_SUBTRACT_STR tr("Horizontal -")
#define VERTICAL_PLUS_STR tr("Vertical +")
#define VERTICAL_SUBTRACT_STR tr("Vertical -")
#define AXIAL_PLUS_STR tr("Axial +")
#define AXIAL_SUBTRACT_STR tr("Axial -")


#define TOOGLESTR tr("Toggle Orthographic Camera")

#define PERSPECTIVE_PROJECTION_STR tr("Perspective Projection")
#define PARALLERL_PROJECTION_STR tr("Parallerl Projection")

enum PerspectiveType
{
    TOGGLE_ORTHOGRAPHIC_CAMREA = 0x0100,
    ORTHOVIEW = 0x0101,
    TRACKBALL_STEP = 0x0102,
    PERSPECTIVE_PROJECTION = 0x0200,
    PARALLEL_PROJECTION = 0x0201,
};

class Perspective : QObject {

public:
    Perspective(GLArea* glArea);

    void perspective(PerspectiveType type, const QString& name);
    void _toggleOrtho();
    void _createOrthoView(const QString& name);
    void _trackballStep(const QString& name);

    void _setView(const PerspectiveType type);
 
    void initializeShot(Shotm& shot);
    float getCameraDistance();
    void loadShot(const QPair<Shotm, float>& shotAndScale);


    // This parameter is the one that controls HOW LARGE IS THE TRACKBALL ICON ON THE SCREEN.
    inline float viewRatio() const { return 1.75f; }
    inline float clipRatioNearDefault() const { return 0.1f; }
    inline float clipRatioFarDefault() const { return 500.0f; }
    inline float fovDefault() const { return 30.0f; }
private:
    float _fov;
    /*
   Given a shot "refCamera" and a trackball "track", computes a new shot which is equivalent
   to apply "refCamera" o "track" (via CPU).
   */
    template <class T>
    vcg::Shot<T> track2ShotCPU(vcg::Shot<T>& refCamera, vcg::Trackball* track) {
        vcg::Shot<T> view;

        //double _near, _far;
        //_near = 0.1;
        //_far = 100;

        //get shot extrinsics matrix
        vcg::Matrix44<T> shotExtr;
        refCamera.GetWorldToExtrinsicsMatrix().ToMatrix(shotExtr);

        vcg::Matrix44<T> model2;
        model2 = (shotExtr)*vcg::Matrix44<T>::Construct(track->Matrix());
        vcg::Matrix44<T> model;
        model2.ToMatrix(model);

        //get translation out of modelview
        vcg::Point3<T> tra;
        tra[0] = model[0][3]; tra[1] = model[1][3]; tra[2] = model[2][3];
        model[0][3] = model[1][3] = model[2][3] = 0;

        //get pure rotation out of modelview
        double det = model.Determinant();
        double idet = 1 / pow(det, 1 / 3.0); //inverse of the determinant
        model *= idet;
        model[3][3] = 1;
        view.Extrinsics.SetRot(model);

        //get pure translation out of modelview
        vcg::Matrix44<T> imodel = model;
        vcg::Transpose(imodel);
        tra = -(imodel * tra);
        tra *= idet;
        view.Extrinsics.SetTra(vcg::Point3<T>::Construct(tra));

        //use same current intrinsics
        view.Intrinsics = refCamera.Intrinsics;

        return view;
    }


    /*
 Given a shot "from" and a trackball "track", updates "track" with "from" extrinsics.
 A translation involving cameraDistance is included. This is necessary to compensate
 a transformation that OpenGL performs at the end of the graphic pipeline.
 */
    template <class T>
    void shot2Track(const vcg::Shot<T>& from, const float cameraDist, vcg::Trackball& tb) {

        vcg::Quaternion<T> qfrom; qfrom.FromMatrix(from.Extrinsics.Rot());

        tb.track.rot = vcg::Quaternionf::Construct(qfrom);
        tb.track.tra = (vcg::Point3f::Construct(-from.Extrinsics.Tra()));
        tb.track.tra += vcg::Point3f::Construct(tb.track.rot.Inverse().Rotate(vcg::Point3f(0, 0, cameraDist))) * (1 / tb.track.sca);
    }


private:
    GLArea* _glArea;
};


#endif // !ANKER_PERSPECTIVE_H
