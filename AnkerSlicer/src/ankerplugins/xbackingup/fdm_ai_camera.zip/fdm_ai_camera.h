#ifndef FDM_AI_CAMERA_H
#define FDM_AI_CAMERA_H

#include "common/controlInterface/controlInterface.h"
#include <common/plugins/interfaces/anker_plugin.h>
#include <common/ml_shared_data_context/ml_shared_data_context.h>
#include <QMainWindow>
#include "../common/ak_const.h"
/*
需求：
    接口，接收 GCode文件Path
    输出，
    
*/


class FdmAiCamera : public QObject, public AnkerPlugin
{
    Q_OBJECT
    MESHLAB_PLUGIN_IID_EXPORTER(Anker_PLUGIN_IID)
    Q_INTERFACES(AnkerPlugin)
    QString pluginName() const final;// MeshLabPlugin interface
    enum {
        DP_DOCK_FDM_AI_CAMERA,
    };

    //QMainWindow* MW;

public:
    FdmAiCamera();
    ~FdmAiCamera();
    void initialize(ControlInterface *controlmanager, RichParameterList * globalParameterList) override{}


    // MeshLabPlugin interface
public:
    void recMsgfromManager(PluginMessageData) override;
signals:
    void sendMsg2Manager(PluginMessageData) override;
};


#endif // FDM_SETTING_H
