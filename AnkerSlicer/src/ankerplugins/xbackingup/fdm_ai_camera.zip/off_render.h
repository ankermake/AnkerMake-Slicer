#ifndef OFF_RENDER_H
#define OFF_RENDER_H

#include "OpenGlOffscreenSurface.h"
#include "GcodeViewer.h"
#include <QOpenGLExtraFunctions>
#include <QOpenGLFunctions_3_3_Core>

class offRender : public OpenGlOffscreenSurface,protected /*QOpenGLExtraFunctions*/QOpenGLFunctions_3_3_Core
{
public:
    explicit offRender(
            QScreen* targetScreen = nullptr,
            const QSize& size = QSize (1, 1));

    explicit offRender(
            QOpenGLContext *shareContext,
            QSurfaceFormat shareFormat,
            QScreen* targetScreen = nullptr,
            const QSize& size = QSize (1, 1));

    virtual ~offRender() override;
    void setView(GcodeViewer* viewPass);
    void render_toolpaths();
protected:
    virtual void initializeGL() override;

    virtual void resizeGL(
            int width,
            int height) override;

    virtual void paintGL() override;

private:
    GcodeViewer* m_viewer_ptr = NULL;
};

#endif // OFF_RENDER_H
