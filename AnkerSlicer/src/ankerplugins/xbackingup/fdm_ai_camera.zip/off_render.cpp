#include "off_render.h"

void glAssertRecentCallImpl(const char* file_name, unsigned int line, const char* function_name)
{
    GLenum err = glGetError();
    if (err == GL_NO_ERROR)
        return;
    const char* sErr = 0;
    switch (err) {
    case GL_INVALID_ENUM:       sErr = "Invalid Enum";      break;
    case GL_INVALID_VALUE:      sErr = "Invalid Value";     break;
    // be aware that GL_INVALID_OPERATION is generated if glGetError is executed between the execution of glBegin and the corresponding execution of glEnd
    case GL_INVALID_OPERATION:  sErr = "Invalid Operation"; break;
    case GL_STACK_OVERFLOW:     sErr = "Stack Overflow";    break;
    case GL_STACK_UNDERFLOW:    sErr = "Stack Underflow";   break;
    case GL_OUT_OF_MEMORY:      sErr = "Out Of Memory";     break;
    default:                    sErr = "Unknown";           break;
    }
    //TODO: BOOST_LOG_TRIVIAL(error) << "OpenGL error in " << file_name << ":" << line << ", function " << function_name << "() : " << (int)err << " - " << sErr;
    assert(false);
}

using namespace Anker;
offRender::offRender(
        QScreen*     targetScreen,
        const QSize& size)
    : OpenGlOffscreenSurface(targetScreen, size) {

    }

offRender::offRender(
        QOpenGLContext *shareContext,
        QSurfaceFormat shareFormat,
        QScreen*     targetScreen,
        const QSize& size)
    : OpenGlOffscreenSurface(shareContext,shareFormat,targetScreen, size) {

    }


offRender::~offRender() {}


void offRender::initializeGL() {}


void offRender::resizeGL(int width, int height) {}

void offRender::setView(GcodeViewer* viewPass)
{
    this->m_viewer_ptr = viewPass;
};

#include <QDebug>
void offRender::paintGL()
{
    if(this->m_viewer_ptr!=NULL)
    {
       qDebug()  << m_viewer_ptr->m_buffers[8].paths.size();
       this->render_toolpaths();
    }
    else
    {
        functions()->glClearColor(1,0,0,1);
        functions()->glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    }
}

static EMoveType buffer_type(unsigned char id) {
    return static_cast<EMoveType>(static_cast<unsigned char>(EMoveType::Retract) + id);
}

static unsigned char buffer_id(EMoveType type) {
    return static_cast<unsigned char>(type) - static_cast<unsigned char>(EMoveType::Retract);
}

void offRender::render_toolpaths()
{
    auto render_as_triangles = [this](const GcodeViewer::TBuffer& buffer, unsigned int ibuffer_id, QOpenGLShaderProgram& shader) {
        for (const GcodeViewer::RenderPath& path : buffer.render_paths) {
            if (path.ibuffer_id == ibuffer_id) {
                //set_uniform_color(path.color, shader);
                int id = -1;
                id=glGetUniformLocation(shader.programId(), "uniform_color");
                if (id >= 0) {
                    glsafe(glUniform4fv(id, 1, static_cast<const GLfloat*>(path.color.data())));
                }
                glsafe(glMultiDrawElements(GL_TRIANGLES, (const GLsizei*)path.sizes.data(), GL_UNSIGNED_SHORT, (const void* const*)path.offsets.data(), (GLsizei)path.sizes.size()));
            }
        }
    };

    unsigned char begin_id = buffer_id(EMoveType::Retract);
    unsigned char end_id = buffer_id(EMoveType::Count);
    for (unsigned char i = begin_id; i < end_id; ++i) {
        const GcodeViewer::TBuffer& buffer = m_viewer_ptr->m_buffers[i];
        if (!buffer.visible || !buffer.has_data())
            continue;
        //TODO 选择shader
         m_viewer_ptr->shaderProgram.bind();
         for (size_t j = 0; j < buffer.indices.size(); ++j) {
             const GcodeViewer::IBuffer& i_buffer = buffer.indices[j];

             functions()->glBindBuffer(GL_ARRAY_BUFFER, i_buffer.vbo);
             glsafe(glVertexPointer(buffer.vertices.position_size_floats(), GL_FLOAT, buffer.vertices.vertex_size_bytes(), (const void*)buffer.vertices.position_offset_size()));
             glsafe(glEnableClientState(GL_VERTEX_ARRAY));
             bool has_normals = buffer.vertices.normal_size_floats() > 0;
             if (has_normals) {
                 glsafe(glNormalPointer(GL_FLOAT, buffer.vertices.vertex_size_bytes(), (const void*)buffer.vertices.normal_offset_size()));
                 glsafe(glEnableClientState(GL_NORMAL_ARRAY));
             }

             glsafe(glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, i_buffer.ibo));
             render_as_triangles(buffer, static_cast<unsigned int>(j), m_viewer_ptr->shaderProgram);
             glsafe(glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0));

             if (has_normals)
                 glsafe(glDisableClientState(GL_NORMAL_ARRAY));

             glsafe(glDisableClientState(GL_VERTEX_ARRAY));
             glsafe(glBindBuffer(GL_ARRAY_BUFFER, 0));
         }

         m_viewer_ptr->shaderProgram.release();

    }


}
