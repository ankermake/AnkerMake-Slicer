#include "fdm_ai_camera.h"
#include <numeric>
#include <QMainWindow>
#include <QTimer>
#include <QAction>
#include <QList>
#include <QMenu>
#include <meshlab/glarea.h>
#include <QOpenGLContext>

#include <QElapsedTimer>
#include "common/ak_const.h"

#include "off_render.h"


QString FdmAiCamera::pluginName() const
{
    return AkConst::Plugin::FDM_AI_CAMERA;
}


FdmAiCamera::FdmAiCamera()
{
    //typeList << DP_DOCK_FDM_AI_CAMERA ;

//    if(this->processor == NULL){
//         this->processor = std::make_unique<Anker::GCodeProcessor>();
//    }

}


#include <QDebug>
void FdmAiCamera::recMsgfromManager(PluginMessageData metaData)
{
    qDebug() << tr("AnkerScenePlugin...\n");

    //获取gcode 路径
    if (metaData.from == AkConst::Plugin::FDM_GCODE_PARSER
            && metaData.msg == AkConst::Msg::OFF_SCREEN_RENDER){
        //QOpenGLContext context;
        //context.setShareContext((QOpenGLContext*)metaData.map.value(AkConst::Param::GL_CONTEXT,NULL).value<void*>());
        GcodeViewer* viewPass = (GcodeViewer*)metaData.map.value(AkConst::Param::GCODE_VIEWER,NULL).value<void*>();

        offRender paintSurface((QOpenGLContext*)metaData.map.value(AkConst::Param::GL_CONTEXT,NULL).value<void*>(),metaData.map.value(AkConst::Param::GL_FORMAT,NULL).value<QSurfaceFormat>());

        paintSurface.resize(1080,720);
        paintSurface.setView(viewPass);
        paintSurface.render();
        QImage image = paintSurface.grabFramebuffer();
        image.save("test.jpg");
    }

}





FdmAiCamera::~FdmAiCamera()
{

//    if(this->processor != NULL){
//         this->processor = NULL;
//    }

//    if(this->mviewer.size() > 0){
//        for (auto iter = this->mviewer.begin();iter != this->mviewer.end(); iter++){
//            if((*iter) != NULL)
//            {
//                (*iter) = NULL;
//            }
//        }
//    }


};
