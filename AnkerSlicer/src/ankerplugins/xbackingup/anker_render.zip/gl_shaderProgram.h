/****************************************************************************
* MeshLab                                                           o o     *
* A versatile mesh processing toolbox                             o     o   *
*                                                                _   O  _   *
* Copyright(C) 2005                                                \/)\/    *
* Visual Computing Lab                                            /\/|      *
* ISTI - Italian National Research Council                           |      *
*                                                                    \      *
* All rights reserved.                                                      *
*                                                                           *
* This program is free software; you can redistribute it and/or modify      *
* it under the terms of the GNU General Public License as published by      *
* the Free Software Foundation; either version 2 of the License, or         *
* (at your option) any later version.                                       *
*                                                                           *
* This program is distributed in the hope that it will be useful,           *
* but WITHOUT ANY WARRANTY; without even the implied warranty of            *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
* GNU General Public License (http://www.gnu.org/licenses/gpl.txt)          *
* for more details.                                                         *
*                                                                           *
****************************************************************************/
/****************************************************************************
Revision 0.1  2021/11/09 16:15:15  Aden Hu
****************************************************************************/

#ifndef ANKER_RENDER_PLUGINS_GL_SHADERPROGRAM_H
#define ANKER_RENDER_PLUGINS_GL_SHADERPROGRAM_H

#include <GL/glew.h>

#include <string>
#include <vector>
#include <QMatrix4x4>
#include "gl_buffer.h"
#include "gl_vertexArrayObject.h"

class GLShaderProgram
{
public:
	GLShaderProgram();
	~GLShaderProgram();

	void addShaderFromSourceFile(const std::string& fileName, GLenum shaderType);

	void bind();
	void link();
	void update();
	void release();

	void enableAttributeArray(GLuint index);
	void setAttributeBuffer(GLuint index, GLint size, GLenum type,
		GLboolean normalized, GLsizei stride, const GLvoid* pointer);

	GLuint getProgramId() const;
	GLuint getUniformLocation(const std::string& name) const;

	void setUniformValue(const std::string& name, const float v0);
	void setUniformValue(const std::string& name, const float v0, const float v1);
	void setUniformValue(const std::string& name, const float v0, const float v1, const float v2);
	void setUniformValue(const std::string& name, const float v0, const float v1, const float v2, const float v3);

	void setUniformValue(const std::string& name, const QVector4D& v);
	void setUniformValue(const std::string& name, const QMatrix4x4& m);
	void setUniformValue(GLuint location, const QMatrix4x4& value);
	void setUniformValue(const std::string& name, const QMatrix3x3& m);

private:
	GLuint m_program;
	std::vector<GLuint> m_shaders;
};




#endif // !ANKER_RENDER_PLUGINS_GL_SHADERPROGRAM_H
