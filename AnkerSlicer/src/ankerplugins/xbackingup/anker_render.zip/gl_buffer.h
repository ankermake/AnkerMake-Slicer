/****************************************************************************
* MeshLab                                                           o o     *
* A versatile mesh processing toolbox                             o     o   *
*                                                                _   O  _   *
* Copyright(C) 2005                                                \/)\/    *
* Visual Computing Lab                                            /\/|      *
* ISTI - Italian National Research Council                           |      *
*                                                                    \      *
* All rights reserved.                                                      *
*                                                                           *
* This program is free software; you can redistribute it and/or modify      *
* it under the terms of the GNU General Public License as published by      *
* the Free Software Foundation; either version 2 of the License, or         *
* (at your option) any later version.                                       *
*                                                                           *
* This program is distributed in the hope that it will be useful,           *
* but WITHOUT ANY WARRANTY; without even the implied warranty of            *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
* GNU General Public License (http://www.gnu.org/licenses/gpl.txt)          *
* for more details.                                                         *
*                                                                           *
****************************************************************************/
/****************************************************************************
Revision 0.1  2021/11/09 15:19:30  Aden Hu
****************************************************************************/
#ifndef ANKER_RENDER_PLUGINS_GL_BUFFER_H
#define ANKER_RENDER_PLUGINS_GL_BUFFER_H
#include <GL/glew.h>
#include <stdlib.h>


class GLBuffer
{
public:
	GLBuffer();
	~GLBuffer();

	void create(GLenum type, GLuint size);
	void bind();
	void release();
	void destroy();
	void setUsagePattern();
	void allocate(const GLfloat* data, int count);

	GLuint getVboId() const;
private:
	GLuint m_vbo;
	GLenum m_type;
};




#endif // !ANKER_RENDER_PLUGINS_GL_BUFFER_H
