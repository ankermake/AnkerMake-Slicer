/****************************************************************************
* MeshLab                                                           o o     *
* A versatile mesh processing toolbox                             o     o   *
*                                                                _   O  _   *
* Copyright(C) 2005                                                \/)\/    *
* Visual Computing Lab                                            /\/|      *
* ISTI - Italian National Research Council                           |      *
*                                                                    \      *
* All rights reserved.                                                      *
*                                                                           *
* This program is free software; you can redistribute it and/or modify      *
* it under the terms of the GNU General Public License as published by      *
* the Free Software Foundation; either version 2 of the License, or         *
* (at your option) any later version.                                       *
*                                                                           *
* This program is distributed in the hope that it will be useful,           *
* but WITHOUT ANY WARRANTY; without even the implied warranty of            *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
* GNU General Public License (http://www.gnu.org/licenses/gpl.txt)          *
* for more details.                                                         *
*                                                                           *
****************************************************************************/
#include "gl_shaderProgram.h"

#include <iostream>
#include <fstream>
#include <QDebug>
#include <QString>
#define ERR_BUFFER 1024
static inline GLuint createShader(const std::string& text, GLenum shaderType);
static inline std::string checkShaderError(GLuint shader, GLuint flag, bool isProgram, const std::string& errorMessage);
//???????????????????
static inline  std::string loadShader(const std::string& fileName);

static inline std::string checkShaderError(GLuint shader, GLuint flag, bool isProgram, const std::string& errorMessage)
{
	std::string errorStr;
	GLint success = 0;
	GLchar error[ERR_BUFFER] = { 0 };

	if (isProgram)
	{
		glGetProgramiv(shader, flag, &success);
	}
	else
	{
		glGetShaderiv(shader, flag, &success);
	}

	if (success == GL_FALSE)
	{
		if (isProgram)
		{
			glGetProgramInfoLog(shader, sizeof(error), NULL, error);
		}
		else
		{
			glGetShaderInfoLog(shader, sizeof(error), NULL, error);
		}
		errorStr = errorMessage + ": " + error + "\n";
	}
	return errorStr;
}

static inline std::string loadShader(const std::string& fileName)
{
	std::ifstream file;
	file.open(fileName.c_str());

	std::string output;
	std::string line;

	if (file.is_open())
	{
		while (file.good())
		{
			getline(file, line);
			output.append(line + "\n");
		}
	}
	else
	{
		qDebug() << QObject::tr("Unable to load shader: ") << QString::fromStdString(fileName);
	}
	return output;
}

static inline GLuint createShader(const std::string& text, GLenum shaderType)
{
	GLuint shader = glCreateShader(shaderType);
	if (shader == 0)
	{
		qDebug() << QObject::tr("Error: Shader creation failure.");
	}

	const GLchar* shaderSourceString[1];
	GLint shaderSourceStringLength[1];
	shaderSourceString[0] = text.c_str();
	shaderSourceStringLength[0] = text.length();

	glShaderSource(shader, 1, shaderSourceString, shaderSourceStringLength);
	return shader;
}

GLShaderProgram::GLShaderProgram()
{
	m_program = glCreateProgram();
}

GLShaderProgram::~GLShaderProgram()
{
	for (int i = 0; i < m_shaders.size(); i++)
	{
		glDetachShader(m_program, m_shaders[i]);
		glDeleteShader(m_shaders[i]);
	}
	glDeleteProgram(m_program);
}

void GLShaderProgram::addShaderFromSourceFile(const std::string& fileName, GLenum shaderType)
{
	GLuint m_shader = createShader(loadShader(fileName), shaderType);
	glCompileShader(m_shader);
	m_shaders.push_back(m_shader);
}

void GLShaderProgram::bind()
{
	glUseProgram(m_program);
}

void GLShaderProgram::link()
{
	for (int i = 0; i < m_shaders.size(); i++)
	{
		glAttachShader(m_program, m_shaders[i]);
	}
	glLinkProgram(m_program);
	checkShaderError(m_program, GL_LINK_STATUS, true, "Error: Progma Linking invalid.");
	glValidateProgram(m_program);
	checkShaderError(m_program, GL_VALIDATE_STATUS, true, "Error: Progma Validate invalid.");
}

void GLShaderProgram::update()
{

}

void GLShaderProgram::release()
{
	glUseProgram(0);
}

void GLShaderProgram::enableAttributeArray(GLuint index)
{
	glEnableVertexAttribArray(index);
}

void GLShaderProgram::setAttributeBuffer(GLuint index, GLint size, GLenum type,
	GLboolean normalized, GLsizei stride, const GLvoid* pointer)
{
	glVertexAttribPointer(index, size, type, normalized, stride, pointer);
}


GLuint GLShaderProgram::getProgramId() const
{
	return m_program;
}

GLuint GLShaderProgram::getUniformLocation(const std::string& name) const
{
	return glGetUniformLocation(m_program, (GLchar*)name.c_str());
}

void GLShaderProgram::setUniformValue(const std::string& name, const float v0)
{
	GLint location = glGetUniformLocation(m_program, (GLchar*)name.c_str());
	glUniform1f(location, v0);
}

void GLShaderProgram::setUniformValue(const std::string& name, const float v0, const float v1)
{
	GLint location = glGetUniformLocation(m_program, (GLchar*)name.c_str());
	glUniform2f(location, v0, v1);
}

void GLShaderProgram::setUniformValue(const std::string& name, const float v0, const float v1, const float v2)
{
	GLint location = glGetUniformLocation(m_program, (GLchar*)name.c_str());
	glUniform3f(location, v0, v1, v2);
}

void GLShaderProgram::setUniformValue(const std::string& name, const float v0, const float v1, const float v2, const float v3)
{
	GLint location = glGetUniformLocation(m_program, (GLchar*)name.c_str());
	glUniform4f(location, v0, v1, v2, v3);
}

void GLShaderProgram::setUniformValue(const std::string& name, const QVector4D& v)
{
	setUniformValue(name, v.x(), v.y(), v.z(), v.w());
}
void GLShaderProgram::setUniformValue(const std::string& name, const QMatrix4x4& m)
{
	GLint location = glGetUniformLocation(m_program, (GLchar*)name.c_str());
	glUniformMatrix4fv(location, 1, false, m.data());
}
void GLShaderProgram::setUniformValue(GLuint location, const QMatrix4x4& m)
{
	glProgramUniformMatrix4fv(m_program, location, 1, false, m.data());
}
void GLShaderProgram::setUniformValue(const std::string& name, const QMatrix3x3& m)
{
	GLint location = glGetUniformLocation(m_program, (GLchar*)name.c_str());
	glUniformMatrix3fv(location, 1, false, m.data());
}
