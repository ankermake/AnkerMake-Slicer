/****************************************************************************
* MeshLab                                                           o o     *
* A versatile mesh processing toolbox                             o     o   *
*                                                                _   O  _   *
* Copyright(C) 2005                                                \/)\/    *
* Visual Computing Lab                                            /\/|      *
* ISTI - Italian National Research Council                           |      *
*                                                                    \      *
* All rights reserved.                                                      *
*                                                                           *
* This program is free software; you can redistribute it and/or modify      *
* it under the terms of the GNU General Public License as published by      *
* the Free Software Foundation; either version 2 of the License, or         *
* (at your option) any later version.                                       *
*                                                                           *
* This program is distributed in the hope that it will be useful,           *
* but WITHOUT ANY WARRANTY; without even the implied warranty of            *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
* GNU General Public License (http://www.gnu.org/licenses/gpl.txt)          *
* for more details.                                                         *
*                                                                           *
****************************************************************************/

#include "anker_render.h"

#include <QDebug>
#include <meshlab/glarea.h>

AnkerRenderPlugin::AnkerRenderPlugin()
{
	initActionList();
}

QString AnkerRenderPlugin::pluginName() const
{
	return QString("AnkerRender");
}

void AnkerRenderPlugin::init(QAction* a, MeshDocument& m, MLSceneGLSharedDataContext::PerMeshRenderingDataMap& mp, GLArea* gla)
{
	if (gla == NULL)
	{
		return;
	}
	gla->makeCurrent();

	MultiViewer_Container* mvcont = gla->mvc();

	if (mvcont == NULL)
	{
		return;
	}

	MLSceneGLSharedDataContext* shared = mvcont->sharedDataContext();
	if (shared == NULL)
	{
		return;
	}
	//MeshModel* addNewMesh(const CMeshO& mesh, const QString& Label, bool setAsCurrent=true);
	CMeshO mesh;
	shared->meshDoc().addNewMesh(mesh, tr("Mesh Test"));
	qDebug() << tr("Anker Render Plugin Init: ") << shared->meshDoc().objectName();
}

void AnkerRenderPlugin::initActionList()
{
	_actionList << new QAction(tr("Anker Render"), this);
}

void AnkerRenderPlugin::finalize(QAction* a, MeshDocument* m, GLArea* gla)
{

}

void AnkerRenderPlugin::render(QAction* a, MeshDocument& m, MLSceneGLSharedDataContext::PerMeshRenderingDataMap& mp, GLArea* gla)
{

}

void AnkerRenderPlugin::recMsgfromManager(PluginMessageData metametaData)
{

}



MESHLAB_PLUGIN_NAME_EXPORTER(AnkerRenderPlugin)
