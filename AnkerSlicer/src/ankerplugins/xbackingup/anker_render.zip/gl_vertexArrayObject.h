/****************************************************************************
* MeshLab                                                           o o     *
* A versatile mesh processing toolbox                             o     o   *
*                                                                _   O  _   *
* Copyright(C) 2005                                                \/)\/    *
* Visual Computing Lab                                            /\/|      *
* ISTI - Italian National Research Council                           |      *
*                                                                    \      *
* All rights reserved.                                                      *
*                                                                           *
* This program is free software; you can redistribute it and/or modify      *
* it under the terms of the GNU General Public License as published by      *
* the Free Software Foundation; either version 2 of the License, or         *
* (at your option) any later version.                                       *
*                                                                           *
* This program is distributed in the hope that it will be useful,           *
* but WITHOUT ANY WARRANTY; without even the implied warranty of            *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
* GNU General Public License (http://www.gnu.org/licenses/gpl.txt)          *
* for more details.                                                         *
*                                                                           *
****************************************************************************/
/****************************************************************************
Revision 0.1  2021/11/09 15:52:36  Aden Hu
****************************************************************************/

#ifndef ANKER_RENDER_PLUGINS_GL_VERTEXARRAYOBJECT_H
#define ANKER_RENDER_PLUGINS_GL_VERTEXARRAYOBJECT_H
#include <GL/glew.h>

class GLVertexArrayObject
{
public:
	GLVertexArrayObject();
	~GLVertexArrayObject();

	void create(GLuint size);
	void bind();
	void destroy();
	void release();

	GLuint getVaoId() const;

private:
	GLuint m_vao;
};






#endif // !ANKER_RENDER_PLUGINS_GL_VERTEXARRAYOBJECT_H

