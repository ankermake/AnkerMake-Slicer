/****************************************************************************
* MeshLab                                                           o o     *
* A versatile mesh processing toolbox                             o     o   *
*                                                                _   O  _   *
* Copyright(C) 2005                                                \/)\/    *
* Visual Computing Lab                                            /\/|      *
* ISTI - Italian National Research Council                           |      *
*                                                                    \      *
* All rights reserved.                                                      *
*                                                                           *
* This program is free software; you can redistribute it and/or modify      *
* it under the terms of the GNU General Public License as published by      *
* the Free Software Foundation; either version 2 of the License, or         *
* (at your option) any later version.                                       *
*                                                                           *
* This program is distributed in the hope that it will be useful,           *
* but WITHOUT ANY WARRANTY; without even the implied warranty of            *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
* GNU General Public License (http://www.gnu.org/licenses/gpl.txt)          *
* for more details.                                                         *
*                                                                           *
****************************************************************************/
/****************************************************************************
Revision 0.1  2021/10/28 12:52:40  Aden Hu
****************************************************************************/

#ifndef ANKER_SCENE_PLUGIN_RENDER_H
#define ANKER_SCENE_PLUGIN_RENDER_H

#include <GL/glew.h>
#include <common/plugins/interfaces/render_plugin.h>
#include <QObject>
#include <QString>
class AnkerRenderPlugin : public QObject, public RenderPlugin {
	Q_OBJECT
	MESHLAB_PLUGIN_IID_EXPORTER(RENDER_PLUGIN_IID)
	Q_INTERFACES(RenderPlugin)

	QList<QAction*> _actionList;
	bool _supported;
public:
	AnkerRenderPlugin();
	virtual ~AnkerRenderPlugin(){}

	QString pluginName() const;

	QList<QAction*> actions() {
		if (_actionList.isEmpty()) initActionList();
		return _actionList;
	}

	void initActionList();

	virtual bool isSupported() { return _supported; }
	virtual void init(QAction* a, MeshDocument& m, MLSceneGLSharedDataContext::PerMeshRenderingDataMap& mp, GLArea* gla);
	virtual void finalize(QAction* a, MeshDocument* m, GLArea* gla);
	virtual void render(QAction* a, MeshDocument& m, MLSceneGLSharedDataContext::PerMeshRenderingDataMap& mp, GLArea* gla);
	
public:
	virtual void recMsgfromManager(PluginMessageData);
    void initialize(ControlInterface *controlmanager, RichParameterList * globalParameterList){}
signals:
	void sendMsg2Manager(PluginMessageData);

private:
};


#endif // !ANKER_SCENE_PLUGIN_RENDER_H
