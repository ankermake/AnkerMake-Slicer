/****************************************************************************
 * MeshLab                                                           o o     *
 * A versatile mesh processing toolbox                             o     o   *
 *                                                                _   O  _   *
 * Copyright(C) 2008                                                \/)\/    *
 * Visual Computing Lab                                            /\/|      *
 * ISTI - Italian National Research Council                           |      *
 *                                                                    \      *
 * All rights reserved.                                                      *
 *                                                                           *
 * This program is free software; you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation; either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)          *
 * for more details.                                                         *
 *                                                                           *
 ****************************************************************************/

#include <meshlab/glarea.h>
#include "edit_meshmirrortransform.h"
#include <wrap/qt/gl_label.h>
#include <wrap/gui/trackball.h>
#include "wrap/gl/space.h"
#include "common/GeoAndShow/TransformPack.h"
#include "common/GeoAndShow/CHLine3D.h"
#include "common/GeoAndShow/CHBaseAlg.h"
#include "QPalette"
#include "edit_meshtransform_factory.h"

using namespace vcg;

EditMeshMirrorTransformTool::EditMeshMirrorTransformTool()
{
    m_operateMoveZ = 0;
    m_paramUI = 0;
}

bool EditMeshMirrorTransformTool::startEdit(MeshDocument& md, GLArea* gla, MLSceneGLSharedDataContext* scenedata)
{
    curScene = gla->m_scene;
    if (curScene->m_pickCommand->m_selectedObjs.size() == 0)
    {
        return false;
    }

    for (auto actionIt = transformActionsList.begin(); actionIt != transformActionsList.end(); actionIt++)
    {
        if ((*actionIt)->text() == QString("Mirror"))
        {
            (*actionIt)->setIcon(QIcon(":/images/fdm_mirror_icon_s.png"));
            break;
        }
    }

    m_editMeshModels = curScene->m_pickCommand->m_selectedObjs;
    m_firstMesh = *m_editMeshModels.begin();

    m_operateMoveZ = 0;

    m_paramUI = new CHModelMirrorTransformParamsSetUI();
    EditMeshTransformFactory::m_conInt->addWidgetToModelTransForm(m_paramUI, 4);
    connect(m_paramUI, SIGNAL(sendWhichButtonClicked(int)), this, SLOT(receiveButtonClicked(int)));
    connect(m_paramUI->m_resetButton, SIGNAL(clicked()), this, SLOT(reset()));//??

    //初始化
    for (std::set<CHMeshShowObjPtr>::iterator it = m_editMeshModels.begin(); it != m_editMeshModels.end(); it++)
    {
        EditMeshTransformFactory::initMeshModelEulerParams(*it);
    }
    m_initValues.resize(m_editMeshModels.size());
    int p = 0;
    for (std::set<CHMeshShowObjPtr>::iterator it = m_editMeshModels.begin(); it != m_editMeshModels.end(); it++)
    {
        m_initValues[p] = (*it)->m_params;
        p++;
    }

    //多模型时计算操作中心
    //if (m_editMeshModels.size() > 1)
    {
        CHAABB3D aabb;
        for (std::set<CHMeshShowObjPtr>::iterator it = m_editMeshModels.begin(); it != m_editMeshModels.end(); it++)
        {
            aabb.add((*it)->calSimilarAABB());
        }
        m_operationCenter = aabb.getCenterPoint();
    }

    return true;
}

void EditMeshMirrorTransformTool::endEdit(MeshDocument& md, GLArea*, MLSceneGLSharedDataContext*)
{
    if (m_paramUI)
    {
        delete m_paramUI;
        m_paramUI = 0;
    }
    for (auto actionIt = transformActionsList.begin(); actionIt != transformActionsList.end(); actionIt++)
    {
        if ((*actionIt)->text() == QString("Mirror"))
        {
            (*actionIt)->setIcon(QIcon(":/images/fdm_mirror_icon_e.png"));
            break;
        }
    }
}

void EditMeshMirrorTransformTool::decorate(MeshModel& meshmodel, GLArea* gla, QPainter* mypainter)
{
}

void EditMeshMirrorTransformTool::mousePressEvent(QMouseEvent* event, MeshModel& meshmodel, GLArea* gla)
{

}

void EditMeshMirrorTransformTool::mouseMoveEvent(QMouseEvent* event, MeshModel& meshmodel, GLArea* gla)
{
}

void EditMeshMirrorTransformTool::mouseReleaseEvent(QMouseEvent* event, MeshModel& meshmodel, GLArea* gla)
{
}

void EditMeshMirrorTransformTool::receiveButtonClicked(int index)
{
    CHAABB3D aabb;//?????????
    int p = 0;
    for (std::set<CHMeshShowObjPtr>::iterator it = m_editMeshModels.begin(); it != m_editMeshModels.end(); it++)
    {
        (*it)->m_params[index] = -(*it)->m_params[index];

        //if (m_editMeshModels.size() > 1)//?????????????????????????
        {
            //????
            float t1 = (*it)->m_rotCenter[index] + (*it)->m_params[index + 6];
            (*it)->m_params[index + 6] += 2 * ((m_operationCenter + QVector3D(0, 0, m_operateMoveZ))[index] - t1);

            //????
            //????????
            QVector3D curCenter = m_operationCenter + QVector3D(0, 0, m_operateMoveZ);
            QMatrix4x4 tran1, tran2, tran3;
            tran1.translate(-curCenter);
            QVector3D scaleValue(1, 1, 1);
            scaleValue[index] = -1;
            tran2.scale(scaleValue);
            tran3.translate(curCenter);
            QMatrix4x4 newSumMatrix = tran3 * tran2 * tran1 * (*it)->getTransform();//???????????

            QMatrix4x4 ttran1, ttran2, ttran3, ttran4;
            ttran1.translate(-(*it)->m_rotCenter);
            ttran2.scale((*it)->m_params[0], (*it)->m_params[1], (*it)->m_params[2]);
            ttran3.translate(QVector3D((*it)->m_params[6], (*it)->m_params[7], (*it)->m_params[8]));
            ttran4.translate((*it)->m_rotCenter);
            QMatrix4x4 pureRotMatrix = (ttran4 * ttran3).inverted() * newSumMatrix * (ttran2 * ttran1).inverted();

            double angleX, angleY, angleZ;
            CHBaseAlg::instance()->calEulerAnglesFromRotMatrix(pureRotMatrix, angleX, angleY, angleZ);
            //???0-2pi??
            (*it)->m_params[3] = angleX / CH_PI * 180.0;
            (*it)->m_params[4] = angleY / CH_PI * 180.0;
            (*it)->m_params[5] = angleZ / CH_PI * 180.0;
            adjustSingleAngle((*it)->m_params[3]);
            adjustSingleAngle((*it)->m_params[4]);
            adjustSingleAngle((*it)->m_params[5]);
        }

        //??????
        (*it)->setTransform(CHBaseAlg::instance()->calTransformFromParams((*it)->m_rotCenter, (*it)->m_params));

        if (true/*m_lockToPrintPlatform*/)
        {
            aabb.add((*it)->calRealAABB());
        }
        p++;
    }

    if (m_lockToPrintPlatform)
    {
        float moveZ = -aabb.m_Zmin;
        m_operateMoveZ += moveZ;
        for (std::set<CHMeshShowObjPtr>::iterator it = m_editMeshModels.begin(); it != m_editMeshModels.end(); it++)
        {
            (*it)->m_params[8] = (*it)->m_params[8] + moveZ;

            //?????????
            (*it)->m_realAABB.m_Zmin += moveZ;
            (*it)->m_realAABB.m_Zmax += moveZ;

            //??????
            QMatrix4x4 sumtran1 = CHBaseAlg::instance()->calTransformFromParams((*it)->m_rotCenter, (*it)->m_params);

            //????
            (*it)->setTransform(sumtran1);
        }
    }

    for (std::set<CHMeshShowObjPtr>::iterator it = m_editMeshModels.begin(); it != m_editMeshModels.end(); it++)
    {
        CH3DPrintModelPtr meshPtr = dynamic_pointer_cast<CH3DPrintModel>(*it);
        if (meshPtr != NULL)
        {
            meshPtr->isSceneIn(meshPtr->getRealAABB(), getDoc()->m_machineBox->getBaseAABB());
        }
    }

    curScene->refresh();
}

void EditMeshMirrorTransformTool::reset()
{
    CHAABB3D aabb;//?????????
    int p = 0;
    for (std::set<CHMeshShowObjPtr>::iterator it = m_editMeshModels.begin(); it != m_editMeshModels.end(); it++)
    {
        if (m_editMeshModels.size() == 1)//?????????????????????????0
        {
            for (int i = 0; i < 3; i++)
            {
                (*it)->m_params[i] = fabs((*it)->m_params[i]);
            }
        }
        else
        {
            (*it)->m_params = m_initValues[p];
        }

        //??????
        (*it)->setTransform(CHBaseAlg::instance()->calTransformFromParams((*it)->m_rotCenter, (*it)->m_params));

        if (true/*m_lockToPrintPlatform*/)//??????????????????????????
        {
            aabb.add((*it)->calRealAABB());
        }
        p++;

        CH3DPrintModelPtr meshPtr = dynamic_pointer_cast<CH3DPrintModel>(*it);
        if (meshPtr != NULL)
        {
            meshPtr->isSceneIn(meshPtr->getRealAABB(), getDoc()->m_machineBox->getBaseAABB());
        }
    }

    if (m_lockToPrintPlatform)
    {
        float moveZ = -aabb.m_Zmin;
        m_operateMoveZ += moveZ;
        for (std::set<CHMeshShowObjPtr>::iterator it = m_editMeshModels.begin(); it != m_editMeshModels.end(); it++)
        {
            (*it)->m_params[8] = (*it)->m_params[8] + moveZ;

            //?????????
            (*it)->m_realAABB.m_Zmin += moveZ;
            (*it)->m_realAABB.m_Zmax += moveZ;

            //??????
            QMatrix4x4 sumtran1 = CHBaseAlg::instance()->calTransformFromParams((*it)->m_rotCenter, (*it)->m_params);

            //????
            (*it)->setTransform(sumtran1);
        }
    }

    curScene->refresh();
}

void EditMeshMirrorTransformTool::adjustSingleAngle(float& angle)
{
    int n = (int)(angle / 360.0);
    if (angle < 0)
    {
        n--;
    }
    angle = angle - 360.0 * n;
}


