#ifndef EditMeshTransformFactoryPLUGIN_H
#define EditMeshTransformFactoryPLUGIN_H

#include "common/plugins/interfaces/anker_edit_plugin.h"
#include <common/plugins/interfaces/edit_plugin.h>
#include <common/controlInterface/controlInterface.h>
#include "common/GeoAndShow/CHMeshShowObj.h"

using namespace control;


class ActionEditTool : public QAction{
    Q_OBJECT
public:
    using QAction::QAction;
    inline QString getDescription()const {return whatsThis();}
    inline void    setDescription(const QString & des){return setWhatsThis(des);}
    EditTool* ankerEditTool{nullptr};
};


class EditMeshTransformFactory : public QObject, public EditPlugin
{
	    Q_OBJECT
		MESHLAB_PLUGIN_IID_EXPORTER(EDIT_PLUGIN_IID)
		Q_INTERFACES(EditPlugin)

public:
             EditMeshTransformFactory();
    virtual ~EditMeshTransformFactory() {}

    virtual QString pluginName() const override;

	//get the edit tool for the given action
    virtual EditTool* getEditTool(const QAction*) override;

	//get the description for the given action
    virtual QString getEditToolDescription(const QAction*) override;

    virtual void recMsgfromManager(PluginMessageData) override;
    virtual void sendMsg2Manager(PluginMessageData) override;

    virtual void initialize(ControlInterface *controlmanager, RichParameterList * globalParameterList) override;

	static void initMeshModelEulerParams(CHMeshShowObjPtr tmm);

private:
    void initActionEditTools();
    ActionEditTool* rotateMeshTransform {nullptr};
    ActionEditTool* moveMeshTransform   {nullptr};
    ActionEditTool* scaleMeshTransform  {nullptr};
    ActionEditTool* mirrorMeshTransform {nullptr};
    ActionEditTool* manualSupport       {nullptr};
    ActionEditTool* anyFaceTransform    {nullptr};

public:
    static ControlInterface* m_conInt;
};

extern bool m_lockToPrintPlatform;
extern bool m_lockScaleRatio;
extern bool m_clearSupport;
extern std::list<QAction*> transformActionsList;

#endif


