/****************************************************************************
 * MeshLab                                                           o o     *
 * A versatile mesh processing toolbox                             o     o   *
 *                                                                _   O  _   *
 * Copyright(C) 2008                                                \/)\/    *
 * Visual Computing Lab                                            /\/|      *
 * ISTI - Italian National Research Council                           |      *
 *                                                                    \      *
 * All rights reserved.                                                      *
 *                                                                           *
 * This program is free software; you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation; either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)          *
 * for more details.                                                         *
 *                                                                           *
 ****************************************************************************/
#ifndef EditMeshRotationTransformTool_H
#define EditMeshRotationTransformTool_H

#include <QObject>
#include <QStringList>
#include <QList>

#include <common/plugins/interfaces/edit_plugin.h>
#include "CHModelTransformParamsSetUI.h"
#include "CHLineSegment3DShowObj.h"
#include "CHCircleShowObj.h"
#include "CHPointShowObj.h"


DEF_PTR(CHLocalCoordinateAxis)
class CHLocalCoordinateAxis :public CHShowObj
{
public:
	CHLocalCoordinateAxis();
	virtual ~CHLocalCoordinateAxis();

public:
	void create(QVector3D center, double lenth);

	virtual void draw();
	virtual bool pick(int pixelX, int pixelY, double* mm, double* pm, int* vp, PickResult& result, int pickTol = 10);
	
private:
	CHLineSegment3DShowObjPtr m_axisX;
	CHLineSegment3DShowObjPtr m_axisY;
	CHLineSegment3DShowObjPtr m_axisZ;
};


DEF_PTR(CHAdjustCircle)
//??????
class CHAdjustCircle :public CHShowObj
{
public:
	CHAdjustCircle();
	virtual ~CHAdjustCircle();

public:
	void create(QVector3D center, double rad, QVector3D nor, QVector3D refVec, QColor color);

	virtual void draw();
	virtual bool pick(int pixelX, int pixelY, double* mm, double* pm, int* vp, PickResult& result, int pickTol = 10);
	virtual void setStatus(ObjStatus status);

public:
	CHCircleShowObjPtr m_circleBody;
	CHLineSegment3DShowObjPtr m_lineBody;
	CHPointShowObjPtr m_adjustPointBody;
};


enum OperateType
{
	OScale = 0,
	ORotate,
	OMove
};


class EditMeshRotationTransformTool : public QObject, public EditTool
{
	Q_OBJECT

public:

  EditMeshRotationTransformTool(OperateType type = ORotate);
  virtual ~EditMeshRotationTransformTool() {}
  //static const QString info();
  virtual bool startEdit(MeshModel &/*m*/, GLArea * /*parent*/, MLSceneGLSharedDataContext* /*cont*/);
  virtual void endEdit(MeshModel &/*m*/, GLArea * /*parent*/, MLSceneGLSharedDataContext* /*cont*/);
  virtual void decorate(MeshModel &, GLArea *,QPainter*);
  virtual void mousePressEvent(QMouseEvent *, MeshModel &, GLArea * );
  virtual void mouseMoveEvent(QMouseEvent *, MeshModel &, GLArea * );
  virtual void mouseReleaseEvent(QMouseEvent *event, MeshModel &, GLArea * );

  public
Q_SLOTS:
	void showAxis(bool showed);
	void receiveParams(vector<float> params);

Q_SIGNALS:
	void sendParams(vector<float> params);

private:
	QMatrix4x4 calTransformFromParams();
	void calEulerAnglesFromRotMatrix(QMatrix4x4 rotTran);
	void adjustSingleAngle(float& angle);
	void adjustAnglesBetweenZeroAnd360();

	//????????
	void refreshRotationFrame();

	//????????
	void refreshMoveFrame();

private:
	OperateType m_operationType;
	CHModelTransformParamsSetUI* m_paramUI;
	GLArea* m_glView;
	MeshModel* m_meshModel;
	bool m_CoordZToZero;//??Z?????????

	//?????
	CHLocalCoordinateAxisPtr m_CoordAxis1;
	CHLocalCoordinateAxisPtr m_CoordAxis2;

	//??????
	CHAdjustCirclePtr m_adjustCircleX;
	CHAdjustCirclePtr m_adjustCircleY;
	CHAdjustCirclePtr m_adjustCircleZ;
	std::vector<CHShowObjPtr> m_allPickObjs;

	std::vector<CHShowObjPtr> m_allShowObjs;

	CHShowObjPtr m_pickedObj;
	int m_stepFlag;//?cmd?m_step???????????????
	float m_value[3];//??????????
	CHLineSegment3DShowObjPtr m_adjustShowCurve;//????????????

/*------------------------------------------------------????----------------------------------------------------*/
	CHLineSegment3DShowObjPtr m_adjustAxisX;
	CHLineSegment3DShowObjPtr m_adjustAxisY;
	CHLineSegment3DShowObjPtr m_adjustAxisZ;
	CHPointShowObjPtr m_adjustOrigin;//????

	QVector3D m_pickCoord;
/*------------------------------------------------------????----------------------------------------------------*/



	//?????mouse?????????????????glarea??????glLoadIdentity????
	GLdouble mm[16];
	GLdouble pm[16];
	GLint vp[4];
};

#endif
