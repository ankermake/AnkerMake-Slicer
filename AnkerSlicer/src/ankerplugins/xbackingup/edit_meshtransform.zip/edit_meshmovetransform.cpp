/****************************************************************************
 * MeshLab                                                           o o     *
 * A versatile mesh processing toolbox                             o     o   *
 *                                                                _   O  _   *
 * Copyright(C) 2008                                                \/)\/    *
 * Visual Computing Lab                                            /\/|      *
 * ISTI - Italian National Research Council                           |      *
 *                                                                    \      *
 * All rights reserved.                                                      *
 *                                                                           *
 * This program is free software; you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation; either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)          *
 * for more details.                                                         *
 *                                                                           *
 ****************************************************************************/

#include <meshlab/glarea.h>
#include "edit_meshmovetransform.h"
#include <wrap/qt/gl_label.h>
#include <wrap/gui/trackball.h>
#include "wrap/gl/space.h"
#include "common/GeoAndShow/TransformPack.h"
#include "common/GeoAndShow/CHLine3D.h"
#include "common/GeoAndShow/CHBaseAlg.h"
#include "QPalette"
#include "edit_meshtransform_factory.h"

#include "QOpenGLFramebufferObject"
#include "common/support/supportdata.h"
#include "common/support/supportmeshfactory.h"


using namespace vcg;

CHAxisWithArrow::CHAxisWithArrow()
{
}

CHAxisWithArrow::~CHAxisWithArrow()
{
}

void CHAxisWithArrow::create(QVector3D center, QVector3D axisDir, float axisLenth, float rad, float height)
{
    setDirty(true);

    QVector3D et = center + axisDir * axisLenth;
    m_axis = CHLineSegment3DShowObjPtr(new CHLineSegment3DShowObj);
    m_axis->create(center, et);

    m_arrow = CHConePtr(new CHCone);
    m_arrow->create(rad, height);
    QMatrix4x4 matrix1 = TransformPack::rotMat(QVector3D(0, 0, 1), axisDir, QVector3D(0, 0, 0));
    QMatrix4x4 matrix2;
    matrix2.translate(et);
    m_arrow->transform(matrix2 * matrix1);

    m_baseShowObjs.push_back(m_axis);
    m_baseShowObjs.push_back(m_arrow);
}

bool CHAxisWithArrow::pick(int pixelX, int pixelY, PickResult& result, int pickTol)
{
    m_axis->setTransform(getTransform());
    if (!m_axis->pick(pixelX, pixelY, result, pickTol))
    {
        return false;
    }
    result.m_pickObj = shared_from_this();
    return true;
}

EditMeshMoveTransformTool::EditMeshMoveTransformTool()
{
    m_paramUI = 0;
    m_stepFlag = 0;
    //m_meshModel = 0;
    //m_CoordZToZero = true;
}

bool EditMeshMoveTransformTool::startEdit(MeshDocument& md, GLArea* gla, MLSceneGLSharedDataContext* scenedata)
{
#if 0  //andrew测试代码
    curScene = gla->m_scene;
    SupportMeshFactory inst;
    QList<CHShowObjPtr> objs = inst.GenerateSupportMeshes(SupportData::instance()->GetSupportLines());
    for (int i = 0; i < objs.size(); i++)
    {
        objs[i]->updateToScene();
    }
#endif

    //Box3m plat(Point3f(0, 0, 0), Point3f(100, 100, 300));
    //meshmodel.adjustToSuitableSize(plat);

    //截屏测试
    //QPixmap pmp(gla->size());
    //gla->render(&pmp);
    //pmp = gla->grab(QRect(QPoint(0, 0), gla->size()));
    //QImage im = gla->grabFrameBuffer();
    //im.save("C:/1.jpg");
    //pmp.save("C:/1.jpg");

    //离屏渲染
    //QOffscreenSurface;
    //QOpenGLFramebufferObject

    curScene = gla->m_scene;
    if (curScene->m_pickCommand->m_selectedObjs.size() == 0)
    {
        return false;
    }

    for (auto actionIt = transformActionsList.begin(); actionIt != transformActionsList.end(); actionIt++)
    {
        if ((*actionIt)->text() == QString("Move"))
        {
            (*actionIt)->setIcon(QIcon(":/images/fdm_move_icon_s.png"));
            break;
        }
    }

    m_editMeshModels = curScene->m_pickCommand->m_selectedObjs;
    m_firstMesh = *m_editMeshModels.begin();

    m_stepFlag = 0;
    m_pickedObj = 0;

    m_paramUI = new CHModelMoveTransformParamsSetUI();
    EditMeshTransformFactory::m_conInt->addWidgetToModelTransForm(m_paramUI, 1);
    connect(this, SIGNAL(sendParams(vector<float>)), m_paramUI, SLOT(receiveParams(vector<float>)));
    connect(m_paramUI, SIGNAL(sendParams(vector<float>)), this, SLOT(receiveParams(vector<float>)));
    connect(m_paramUI->m_resetButton, SIGNAL(clicked()), this, SLOT(resetBtnClicked()));
    disconnect(getGlobalPick().get(), SIGNAL(resetSeletedObjsSig()), getGlobalPick().get(), SLOT(resetSelectedObjs()));
    connect(getGlobalPick().get(), SIGNAL(resetSeletedObjsSig()), this, SLOT(resetSelectedObjsClicked()));
    //初始化
    for (std::set<CHMeshShowObjPtr>::iterator it = m_editMeshModels.begin(); it != m_editMeshModels.end(); it++)
    {
        EditMeshTransformFactory::initMeshModelEulerParams(*it);
    }
    m_values.resize(m_editMeshModels.size());
    m_initValues.resize(m_editMeshModels.size());
    int p = 0;
    for (std::set<CHMeshShowObjPtr>::iterator it = m_editMeshModels.begin(); it != m_editMeshModels.end(); it++)
    {
        m_values[p].resize(3);
        m_initValues[p].resize(3);
        m_initValues[p][0] = (*it)->m_params[6];
        m_initValues[p][1] = (*it)->m_params[7];
        m_initValues[p][2] = (*it)->m_params[8];
        p++;
    }

    //多模型时计算操作中心
    CHAABB3D aabb;
    for (std::set<CHMeshShowObjPtr>::iterator it = m_editMeshModels.begin(); it != m_editMeshModels.end(); it++)
    {
        aabb.add((*it)->calSimilarAABB());
    }
    //if (m_editMeshModels.size() > 1)
    {
        m_operationCenter = aabb.getCenterPoint();
    }
    /*else
    {
        m_operationCenter = m_firstMesh->m_rotCenter + QVector3D(m_firstMesh->m_params[6], m_firstMesh->m_params[7], m_firstMesh->m_params[8]);
    } */

    submitToUI();

    //创建平移调节框架
    double ratio = 0.5;
    double maxLenth = max(max(aabb.getLenX(), aabb.getLenY()), aabb.getLenZ()) * ratio;
    //QVector3D originCreateCenter(m_meshModel->m_rotCenter[0], m_meshModel->m_rotCenter[1], m_meshModel->m_rotCenter[2]);
    QVector3D originCreateCenter = m_operationCenter;
    float trad = 1.5;
    float theight = 11;
    m_adjustAxisX = CHAxisWithArrowPtr(new CHAxisWithArrow);
    m_adjustAxisX->create(originCreateCenter, QVector3D(1, 0, 0), maxLenth, trad, theight);
    m_adjustAxisX->setColor(QColor(125, 0, 0));
    m_adjustAxisX->setCalLight(false);
    m_adjustAxisY = CHAxisWithArrowPtr(new CHAxisWithArrow);
    m_adjustAxisY->create(originCreateCenter, QVector3D(0, 1, 0), maxLenth, trad, theight);
    m_adjustAxisY->setColor(QColor(0, 125, 0));
    m_adjustAxisY->setCalLight(false);
    m_adjustAxisZ = CHAxisWithArrowPtr(new CHAxisWithArrow);
    m_adjustAxisZ->create(originCreateCenter, QVector3D(0, 0, 1), maxLenth, trad, theight);
    m_adjustAxisZ->setColor(QColor(0, 0, 125));
    m_adjustAxisZ->setCalLight(false);
    m_adjustOrigin = CHPointShowObjPtr(new CHPointShowObj);
    m_adjustOrigin->create(originCreateCenter);
    m_adjustOrigin->setColor(QColor(125, 0, 125));
    m_adjustOrigin->setSize(8);

    //刷新平移调节框架
    refreshMoveFrame();

    m_allPickObjs.push_back(m_adjustAxisX);
    m_allPickObjs.push_back(m_adjustAxisY);
    m_allPickObjs.push_back(m_adjustAxisZ);
    m_allPickObjs.push_back(m_adjustOrigin);

    for (int i = 0; i < m_allPickObjs.size(); i++)
    {
        m_allPickObjs[i]->setLightTest(false);
        /*if (dynamic_pointer_cast<CHAssembly>(m_allPickObjs[i]))
        {
            dynamic_pointer_cast<CHAssembly>(m_allPickObjs[i])->injectPropertiesToChildren();
        }*/
        m_allPickObjs[i]->updateToScene();
    }

    return true;
}

void EditMeshMoveTransformTool::endEdit(MeshDocument& md, GLArea*, MLSceneGLSharedDataContext*)
{
    if (m_paramUI)
    {
        delete m_paramUI;
        m_paramUI = 0;
    }

    for (int i = 0; i < m_allPickObjs.size(); i++)
    {
        m_allPickObjs[i]->setDelete(true);
        /*if (dynamic_pointer_cast<CHAssembly>(m_allPickObjs[i]))
        {
            dynamic_pointer_cast<CHAssembly>(m_allPickObjs[i])->injectPropertiesToChildren();
        }*/
        m_allPickObjs[i]->updateToScene();
    }

    m_allPickObjs.clear();

    for (auto actionIt = transformActionsList.begin(); actionIt != transformActionsList.end(); actionIt++)
    {
        if ((*actionIt)->text() == QString("Move"))
        {
            (*actionIt)->setIcon(QIcon(":/images/fdm_move_icon_e.png"));
            break;
        }
    }

    disconnect(getGlobalPick().get(), SIGNAL(resetSeletedObjsSig()), this, SLOT(resetSelectedObjsClicked()));
    connect(getGlobalPick().get(), SIGNAL(resetSeletedObjsSig()), getGlobalPick().get(), SLOT(resetSelectedObjs()));
}

void EditMeshMoveTransformTool::decorate(MeshModel& meshmodel, GLArea* gla, QPainter* mypainter)
{
    return;
    glGetDoublev(GL_MODELVIEW_MATRIX, mm);
    glGetDoublev(GL_PROJECTION_MATRIX, pm);
    glGetIntegerv(GL_VIEWPORT, vp);

    glDisable(GL_DEPTH_TEST);
    for (int i = 0; i < m_allPickObjs.size(); i++)
    {
        if (m_allPickObjs[i] && m_allPickObjs[i]->getVisuable())
        {
            //m_allPickObjs[i]->draw();
        }
    }
    glEnable(GL_DEPTH_TEST);
}

void EditMeshMoveTransformTool::mousePressEvent(QMouseEvent* event, MeshModel& meshmodel, GLArea* gla)
{
    if (event->button() == Qt::LeftButton && m_pickedObj)
    {
        m_stepFlag = 1;

        int i = 0;
        for (std::set<CHMeshShowObjPtr>::iterator it = m_editMeshModels.begin(); it != m_editMeshModels.end(); it++)
        {
            m_values[i][0] = (*it)->m_params[6];
            m_values[i][1] = (*it)->m_params[7];
            m_values[i][2] = (*it)->m_params[8];

            i++;
        }
    }
}

void EditMeshMoveTransformTool::mouseMoveEvent(QMouseEvent* event, MeshModel& meshmodel, GLArea* gla)
{
    if (m_stepFlag == 0)
    {
        //计算pick对象
        CHShowObjPtr curPickedObj = 0;
        double pickTol = 10;
        vector<PickResult> curPickerObjs;
        for (int i = 0; i < m_allPickObjs.size(); i++)
        {
            PickResult result;
            if (m_allPickObjs[i]->pick(event->pos().x(), event->pos().y(), result, pickTol))
            {
                curPickerObjs.push_back(result);
            }
        }
        int num = (int)curPickerObjs.size();
        if (num == 1)
        {
            curPickedObj = curPickerObjs[0].m_pickObj;

            m_pickCoord = curPickerObjs[0].m_ptOnObj;//免得鼠标按下的时候重新计算
        }
        else if (num > 1)
        {
            std::sort(curPickerObjs.begin(), curPickerObjs.end(), CHShowObj::pred1);//深度排序
            double ttol = 0.001;
            vector<PickResult> minDeepObjs;//深度一样的可能有好几个
            minDeepObjs.push_back(curPickerObjs[0]);
            for (int i = 1; i < num; i++)
            {
                if (fabs(curPickerObjs[i].m_deep - curPickerObjs[0].m_deep) < ttol)
                {
                    minDeepObjs.push_back(curPickerObjs[i]);
                }
            }

            std::sort(minDeepObjs.begin(), minDeepObjs.end(), CHShowObj::pred2);//pick优先级排序
            curPickedObj = minDeepObjs[0].m_pickObj;

            m_pickCoord = minDeepObjs[0].m_ptOnObj;//免得鼠标按下的时候重新计算
        }

        if (m_pickedObj != curPickedObj)//只有与上次的结果不一样才会去刷新界面
        {
            for (int i = 0; i < m_allPickObjs.size(); i++)
            {
                m_allPickObjs[i]->setStatus(general);
                /*if (dynamic_pointer_cast<CHAssembly>(m_allPickObjs[i]))
                {
                    dynamic_pointer_cast<CHAssembly>(m_allPickObjs[i])->injectPropertiesToChildren();
                }*/
            }
            m_pickedObj = curPickedObj;
            if (m_pickedObj)
            {
                m_pickedObj->setStatus(canPicked);
                /*if (dynamic_pointer_cast<CHAssembly>(m_pickedObj))
                {
                    dynamic_pointer_cast<CHAssembly>(m_pickedObj)->injectPropertiesToChildren();
                }*/
            }
            curScene->refresh();
        }
    }
    else if (m_stepFlag == 1) //开始平移操作
    {
        QVector3D np, fp;
        curScene->getCurNearFarPoint(event->pos().x(), event->pos().y(), np, fp);
        CHLine3DPtr ray(new CHLine3D);
        ray->create(np, fp);

        if (dynamic_pointer_cast<CHPointShowObj>(m_pickedObj))//自由移动
        {
            //计算与z=0平面的交点（有问题，应该贴着原点所在z平面求交）
            QVector3D dir = ray->m_et - ray->m_st;
            float m = QVector3D::dotProduct(dir, QVector3D(0, 0, 1));
            if (fabs(m) > 0.0000001)//射线与平面不平行
            {
                float t = QVector3D::dotProduct(m_pickCoord - ray->m_st, QVector3D(0, 0, 1)) / m;
                QVector3D intersection = ray->m_st + dir * t;//直线与平面交点的坐标为st + t * dir

                int i = 0;
                for (std::set<CHMeshShowObjPtr>::iterator it = m_editMeshModels.begin(); it != m_editMeshModels.end(); it++)
                {
                    (*it)->m_params[6] = m_values[i][0] + intersection[0] - m_pickCoord[0];
                    (*it)->m_params[7] = m_values[i][1] + intersection[1] - m_pickCoord[1];
                    (*it)->m_params[8] = m_values[i][2] + intersection[2] - m_pickCoord[2];
                    i++;
                }
            }
        }
        else//沿坐标轴移动
        {
            CHLineSegment3DShowObjPtr moveLine = dynamic_pointer_cast<CHAxisWithArrow>(m_pickedObj)->m_axis;

            //可以近平面远平面建立世界坐标空间射线，与真实坐标轴求极值计算，也可以仿照pick映射到像素空间计算
            CHLine3DPtr line(new CHLine3D);
            line->create(TransformPack::pRot(moveLine->getTransform(), moveLine->m_st),
                TransformPack::pRot(moveLine->getTransform(), moveLine->m_et));

            LineLineExtremeResult result;
            CHBaseAlg::instance()->extremeBetweenLineAndLine(line, ray, result);

            int i = 0;
            for (std::set<CHMeshShowObjPtr>::iterator it = m_editMeshModels.begin(); it != m_editMeshModels.end(); it++)
            {
                (*it)->m_params[6] = m_values[i][0] + result.m_pt1[0] - m_pickCoord[0];
                (*it)->m_params[7] = m_values[i][1] + result.m_pt1[1] - m_pickCoord[1];
                (*it)->m_params[8] = m_values[i][2] + result.m_pt1[2] - m_pickCoord[2];
                i++;
            }
        }

        submitToUI();

        for (std::set<CHMeshShowObjPtr>::iterator it = m_editMeshModels.begin(); it != m_editMeshModels.end(); it++)
        {
            //计算变换矩阵
            QMatrix4x4 sumtran1 = CHBaseAlg::instance()->calTransformFromParams(QVector3D((*it)->m_rotCenter[0],
                (*it)->m_rotCenter[1], (*it)->m_rotCenter[2]), (*it)->m_params);

            //刷新模型
            (*it)->setTransform(sumtran1);
        }

        //刷新平移调节框架
        refreshMoveFrame();

        curScene->refresh();
    }
}

void EditMeshMoveTransformTool::mouseReleaseEvent(QMouseEvent* event, MeshModel& meshmodel, GLArea* gla)
{
    if (event->button() == Qt::LeftButton)
    {
        //???????????????????????????????????pick??????
        CHAABB3D aabb;//?????????
        for (std::set<CHMeshShowObjPtr>::iterator it = m_editMeshModels.begin(); it != m_editMeshModels.end(); it++)
        {
            aabb.add((*it)->calRealAABB());
        }

        //锁定z=0的打印平台
        if (m_lockToPrintPlatform)
        {
            //CHAABB3D aabb;//当前总的真实包围盒
            //for (std::set<CHMeshShowObjPtr>::iterator it = m_editMeshModels.begin(); it != m_editMeshModels.end(); it++)
            //{
            //	aabb.add((*it)->calRealAABB());
            //}
            float moveZ = -aabb.m_Zmin;

            for (std::set<CHMeshShowObjPtr>::iterator it = m_editMeshModels.begin(); it != m_editMeshModels.end(); it++)
            {
                (*it)->m_params[8] = (*it)->m_params[8] + moveZ;

                //?????????
                (*it)->m_realAABB.m_Zmin += moveZ;
                (*it)->m_realAABB.m_Zmax += moveZ;

                //计算变换矩阵
                QMatrix4x4 sumtran1 = CHBaseAlg::instance()->calTransformFromParams(QVector3D((*it)->m_rotCenter[0],
                    (*it)->m_rotCenter[1], (*it)->m_rotCenter[2]), (*it)->m_params);

                //刷新模型
                (*it)->setTransform(sumtran1);
            }

            submitToUI();

            //刷新平移调节框架
            refreshMoveFrame();
        }

        m_stepFlag = 0;
        m_pickedObj = 0;
        for (int i = 0; i < m_allPickObjs.size(); i++)
        {
            m_allPickObjs[i]->setStatus(general);
            /*if (dynamic_pointer_cast<CHAssembly>(m_allPickObjs[i]))
            {
                dynamic_pointer_cast<CHAssembly>(m_allPickObjs[i])->injectPropertiesToChildren();
            }*/
        }
        curScene->refresh();
    }

}

void EditMeshMoveTransformTool::resetBtnClicked()
{
    auto bIt = getGlobalPick()->m_selectedObjs.begin();
    auto eIt = getGlobalPick()->m_selectedObjs.end();
    for (bIt; bIt != eIt; bIt++)
    {
        std::dynamic_pointer_cast<CH3DPrintModel>(*bIt)->resetMove();
    }
    submitToUI();
}

void EditMeshMoveTransformTool::resetSelectedObjsClicked()
{
    getGlobalPick()->resetSelectedObjs();
    submitToUI();
}

void EditMeshMoveTransformTool::receiveParams(vector<float> params)
{
    CHAABB3D aabb;//当前总的真实包围盒
    int i = 0;
    for (std::set<CHMeshShowObjPtr>::iterator it = m_editMeshModels.begin(); it != m_editMeshModels.end(); it++)
    {
        (*it)->m_params[6] = params[0] + m_initValues[i][0];
        (*it)->m_params[7] = params[1] + m_initValues[i][1];
        (*it)->m_params[8] = params[2] + m_initValues[i][2];
        i++;
        //if (m_editMeshModels.size() == 1)//单模型不是重置为进入命令的状态，而是状态量直接设为0
        //{
        //    (*it)->m_params[6] = params[0];
        //    (*it)->m_params[7] = params[1];
        //    (*it)->m_params[8] = params[2];
        //}

        //计算变换矩阵
        (*it)->setTransform(CHBaseAlg::instance()->calTransformFromParams(QVector3D((*it)->m_rotCenter[0],
            (*it)->m_rotCenter[1], (*it)->m_rotCenter[2]), (*it)->m_params));

        if (true/*m_lockToPrintPlatform*/)//??????????????????????????
        {
            aabb.add((*it)->calRealAABB());
        }
    }

    if (m_lockToPrintPlatform)
    {
        float moveZ = -aabb.getLeftDownPoint().z();

        for (std::set<CHMeshShowObjPtr>::iterator it = m_editMeshModels.begin(); it != m_editMeshModels.end(); it++)
        {
            (*it)->m_params[8] = (*it)->m_params[8] + moveZ;

            //?????????
            (*it)->m_realAABB.m_Zmin += moveZ;
            (*it)->m_realAABB.m_Zmax += moveZ;

            //计算变换矩阵
            QMatrix4x4 sumtran1 = CHBaseAlg::instance()->calTransformFromParams(QVector3D((*it)->m_rotCenter[0],
                (*it)->m_rotCenter[1], (*it)->m_rotCenter[2]), (*it)->m_params);

            //刷新模型
            (*it)->setTransform(sumtran1);
        }

        submitToUI();
    }

    for (std::set<CHMeshShowObjPtr>::iterator it = m_editMeshModels.begin(); it != m_editMeshModels.end(); it++)
    {
        CH3DPrintModelPtr meshPtr = dynamic_pointer_cast<CH3DPrintModel>(*it);
        if (meshPtr != NULL)
        {
            meshPtr->isSceneIn(meshPtr->getRealAABB(), getDoc()->m_machineBox->getBaseAABB());
        }
    }

    //????????
    refreshMoveFrame();

    curScene->refresh();
}

void EditMeshMoveTransformTool::refreshMoveFrame()
{
    if (m_adjustAxisX == nullptr || m_adjustAxisY == nullptr || m_adjustAxisZ == nullptr || m_adjustOrigin == nullptr)
    {
        return;
    }
    QMatrix4x4 tran;
    tran.translate(QVector3D(m_firstMesh->m_params[6], m_firstMesh->m_params[7], m_firstMesh->m_params[8]) -
        QVector3D(m_initValues[0][0], m_initValues[0][1], m_initValues[0][2]));
    m_adjustAxisX->setTransform(tran);
    //m_adjustAxisX->injectPropertiesToChildren();
    m_adjustAxisY->setTransform(tran);
    //m_adjustAxisY->injectPropertiesToChildren();
    m_adjustAxisZ->setTransform(tran);
    //m_adjustAxisZ->injectPropertiesToChildren();
    m_adjustOrigin->setTransform(tran);
}

void EditMeshMoveTransformTool::submitToUI()
{
    vector<float> params(3);
    //if (m_editMeshModels.size() == 1)//单选输出模型本身平移状态量
    //{
    //    params[0] = m_firstMesh->m_params[6];
    //    params[1] = m_firstMesh->m_params[7];
    //    params[2] = m_firstMesh->m_params[8];
    //}
    //else//多选输出相对于初始保存量的增量
    {
        params[0] = m_firstMesh->m_params[6] - m_initValues[0][0];
        params[1] = m_firstMesh->m_params[7] - m_initValues[0][1];
        params[2] = m_firstMesh->m_params[8] - m_initValues[0][2];
    }
    emit sendParams(params);
}



