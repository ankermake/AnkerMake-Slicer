#include "CHModelMirrorTransformParamsSetUI.h"
#include "QPushButton"
#include "QBoxLayout"
#include "QValidator"
#include <QSignalMapper>
#include <QRegExp>



CHModelMirrorTransformParamsSetUI::CHModelMirrorTransformParamsSetUI(QWidget* parent)
    : BubbleWidget(parent)
{
    move(97, 566);
    setFixedSize(144, 172);

    setAutoFillBackground(true);
    QPalette pal = palette();
    pal.setColor(QPalette::Background, QColor(255, 255, 255, 255));
    setPalette(pal);

    QVBoxLayout* mainblaout = new QVBoxLayout(this);

    QFont font1;
    font1.setPixelSize(14);
    QLabel* mirrorLabel = new QLabel;
    mirrorLabel->setFont(font1);
    mirrorLabel->setText(tr("Mirror"));
    //mirrorLabel->setStyleSheet("QLabel{ \n\tfont: roboto;\n\twidth: 39px; \n\theight: 16px; \n\ttop: 578px; \n\tleft: 109px; \n\tcolor: #333333; \n }");

    m_resetButton = new QToolButton;
    m_resetButton->setIcon(QIcon(":/images/fdm_remakes_small_icon_n.png"));
    m_resetButton->setStyleSheet(QString::fromUtf8("QToolButton{\n"
        "   border: none;\n"
        "   background: transparent;\n"
        "   width: 13.4px;\n"
        "   height: 13.4px;\n"
        "   left: 212.3px;\n"
        "   top: 580.04px;\n"
        "}\n"));

    QHBoxLayout* hblaout1 = new QHBoxLayout;
    hblaout1->addWidget(mirrorLabel);
    hblaout1->addSpacing(64);
    hblaout1->addWidget(m_resetButton);
    hblaout1->setStretch(0, 39);
    hblaout1->setStretch(1, 64);
    hblaout1->setStretch(2, 13.4);
    mainblaout->addLayout(hblaout1);

    Line* line = new Line;
    line->setStyleSheet(QString::fromUtf8("QFrame{\n"
        "   width: 120px;\n"
        "   height: 1px;\n"
        "   top: 606px;\n"
        "   left: 109px;\n"
        "   color: #E7E7E9;\n"
        "}"));
    QHBoxLayout* hblaout2 = new QHBoxLayout;
    hblaout2->addWidget(line);
    mainblaout->addLayout(hblaout2);

    m_xButton = new QToolButton;
    QString xStr = QString("<font color=#E32525>X</font>") + tr(" Axis");
    QLabel* xStrLabel = new QLabel;
    xStrLabel->setText(xStr);
    xStrLabel->setAlignment(Qt::AlignCenter);
    xStrLabel->setAttribute(Qt::WA_TransparentForMouseEvents);
    xStrLabel->setStyleSheet(QString("QLabel{\n"
        "   width: 34px;\n"
        "   height: 14px;\n"
        "   top: 628px;\n"
        "   left: 152px;\n"
        "   font-size: 12px;\n"
        "}\n"
    ));
    QHBoxLayout* xhbLayout = new QHBoxLayout;
    xhbLayout->addWidget(xStrLabel, Qt::AlignCenter);
    m_xButton->setLayout(xhbLayout);
    m_xButton->setStyleSheet(QString::fromUtf8("QToolButton{\n"
        "   width: 120px;\n"
        "   height: 30px;\n"
        "   left: 109px;\n"
        "   top: 620px;\n"
        "   color: #EDEDED;\n"
        "   border: 1px solid #E7E7E9;\n"
        "   border-radius:4px;\n"
        "}\n"));
    mainblaout->addWidget(m_xButton);

    m_yButton = new QToolButton;
    QString yStr = QString("<font color=#62D361>Y</font>") + tr(" Axis");
    QLabel* yStrLabel = new QLabel;
    yStrLabel->setAlignment(Qt::AlignCenter);
    yStrLabel->setText(yStr);
    yStrLabel->setAttribute(Qt::WA_TransparentForMouseEvents);
    yStrLabel->setStyleSheet(QString("QLabel{\n"
        "   width: 34px;\n"
        "   height: 14px;\n"
        "   top: 666px;\n"
        "   left: 152px;\n"
        "   font-size: 12px;\n"
        "}\n"
    ));
    QHBoxLayout* yhbLayout = new QHBoxLayout;
    yhbLayout->addWidget(yStrLabel, Qt::AlignCenter);
    m_yButton->setLayout(yhbLayout);
    m_yButton->setStyleSheet(QString::fromUtf8("QToolButton{\n"
        "   width: 120px;\n"
        "   height: 30px;\n"
        "   left: 109px;\n"
        "   top: 658px;\n"
        "   color: #EDEDED;\n"
        "   border: 1px solid #E7E7E9;\n"
        "   border-radius:4px;\n"
        "}\n"));
    mainblaout->addWidget(m_yButton);

    m_zButton = new QToolButton;
    QString zStr = QString("<font color=#0167FF>Z</font>") + tr(" Axis");
    QLabel* zStrLabel = new QLabel;
    zStrLabel->setAlignment(Qt::AlignCenter);
    zStrLabel->setText(zStr);
    zStrLabel->setAttribute(Qt::WA_TransparentForMouseEvents);
    zStrLabel->setStyleSheet(QString("QLabel{\n"
        "   width: 34px;\n"
        "   height: 14px;\n"
        "   top: 704px;\n"
        "   left: 152px;\n"
        "   font-size: 12px;\n"
        "}\n"
    ));
    QHBoxLayout* zhbLayout = new QHBoxLayout;
    zhbLayout->addWidget(zStrLabel, Qt::AlignCenter);
    m_zButton->setLayout(zhbLayout);
    m_zButton->setStyleSheet(QString::fromUtf8("QToolButton{\n"
        "   width: 120px;\n"
        "   height: 30px;\n"
        "   left: 109px;\n"
        "   top: 696px;\n"
        "   color: #EDEDED;\n"
        "   border: 1px solid #E7E7E9;\n"
        "   border-radius:4px;\n"
        "}\n"));
    mainblaout->addWidget(m_zButton);

    connect(m_xButton, SIGNAL(clicked()), this, SLOT(xBtnClicked()));
    connect(m_yButton, SIGNAL(clicked()), this, SLOT(yBtnClicked()));
    connect(m_zButton, SIGNAL(clicked()), this, SLOT(zBtnClicked()));
    connect(m_resetButton, SIGNAL(clicked()), this, SLOT(reset()));
}

CHModelMirrorTransformParamsSetUI::~CHModelMirrorTransformParamsSetUI()
{

}

void CHModelMirrorTransformParamsSetUI::submit()
{
    if (sender() == m_xButton)
    {
        emit sendWhichButtonClicked(0);
    }
    else if (sender() == m_yButton)
    {
        emit sendWhichButtonClicked(1);
    }
    else if (sender() == m_zButton)
    {
        emit sendWhichButtonClicked(2);
    }
}

void CHModelMirrorTransformParamsSetUI::xBtnClicked()
{
    emit sendWhichButtonClicked(0);
}
void CHModelMirrorTransformParamsSetUI::yBtnClicked()
{
    emit sendWhichButtonClicked(1);
}
void CHModelMirrorTransformParamsSetUI::zBtnClicked()
{
    emit sendWhichButtonClicked(2);
}






