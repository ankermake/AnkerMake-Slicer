/****************************************************************************
 * MeshLab                                                           o o     *
 * A versatile mesh processing toolbox                             o     o   *
 *                                                                _   O  _   *
 * Copyright(C) 2008                                                \/)\/    *
 * Visual Computing Lab                                            /\/|      *
 * ISTI - Italian National Research Council                           |      *
 *                                                                    \      *
 * All rights reserved.                                                      *
 *                                                                           *
 * This program is free software; you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation; either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)          *
 * for more details.                                                         *
 *                                                                           *
 ****************************************************************************/

#include <meshlab/glarea.h>
#include "edit_meshrotationtransform.h"
#include <wrap/qt/gl_label.h>
#include <wrap/gui/trackball.h>
#include "wrap/gl/space.h"
#include "common/GeoAndShow/TransformPack.h"
#include "common/GeoAndShow/CHLine3D.h"
#include "common/GeoAndShow/CHBaseAlg.h"
#include "edit_meshtransform_factory.h"

using namespace vcg;


CHLocalCoordinateAxis::CHLocalCoordinateAxis()
{
}

CHLocalCoordinateAxis::~CHLocalCoordinateAxis()
{
}

void CHLocalCoordinateAxis::create(QVector3D center, double lenth)
{
    setDirty(true);

    m_axisX = CHLineSegment3DShowObjPtr(new CHLineSegment3DShowObj);
    m_axisX->create(center, center + QVector3D(lenth, 0, 0));
    m_axisX->setColor(QColor(125, 0, 0));

    m_axisY = CHLineSegment3DShowObjPtr(new CHLineSegment3DShowObj);
    m_axisY->create(center, center + QVector3D(0, lenth, 0));
    m_axisY->setColor(QColor(0, 125, 0));

    m_axisZ = CHLineSegment3DShowObjPtr(new CHLineSegment3DShowObj);
    m_axisZ->create(center, center + QVector3D(0, 0, lenth));
    m_axisZ->setColor(QColor(0, 0, 125));

    m_baseShowObjs.push_back(m_axisX);
    m_baseShowObjs.push_back(m_axisY);
    m_baseShowObjs.push_back(m_axisZ);
}

CHAdjustCircle::CHAdjustCircle()
{
}

CHAdjustCircle::~CHAdjustCircle()
{
}

void CHAdjustCircle::create(QVector3D center, double rad, QVector3D nor, QVector3D refVec)
{
    setDirty(true);

    m_circleBody = CHCircleShowObjPtr(new CHCircleShowObj);
    m_circleBody->create(center, rad, nor, refVec);

    m_lineBody = CHLineSegment3DShowObjPtr(new CHLineSegment3DShowObj);
    m_lineBody->create(center, center + refVec * rad);

    m_adjustPointBody = CHPointShowObjPtr(new CHPointShowObj);
    m_adjustPointBody->create(center + refVec * rad);
    m_adjustPointBody->setSize(8);

    m_baseShowObjs.push_back(m_circleBody);
    m_baseShowObjs.push_back(m_lineBody);
    m_baseShowObjs.push_back(m_adjustPointBody);
}

EditMeshRotationTransformTool::EditMeshRotationTransformTool()
{
    m_paramUI = 0;
    m_stepFlag = 0;
    m_adjustShowCurve = 0;
    m_operateMoveZ = 0;
}

bool EditMeshRotationTransformTool::startEdit(MeshDocument& md, GLArea* gla, MLSceneGLSharedDataContext* scenedata)
{
    //设置图标明暗
    curScene = gla->m_scene;
    if (curScene->m_pickCommand->m_selectedObjs.size() == 0)
    {
        return false;
    }
    for (auto actionIt = transformActionsList.begin(); actionIt != transformActionsList.end(); actionIt++)
    {
        if ((*actionIt)->text() == QString("Rotate"))
        {
            (*actionIt)->setIcon(QIcon(":/images/fdm_rotate_icon_s.png"));
            break;
        }
    }
    m_editMeshModels = curScene->m_pickCommand->m_selectedObjs;
    m_firstMesh = *m_editMeshModels.begin();

    m_stepFlag = 0;
    m_adjustShowCurve = 0;
    m_pickedObj = 0;
    m_operateMoveZ = 0;

    m_paramUI = new CHModelRotationTransformParamsSetUI();
    EditMeshTransformFactory::m_conInt->addWidgetToModelTransForm(m_paramUI, 2);
    connect(this, SIGNAL(sendParams(vector<float>)), m_paramUI, SLOT(receiveParams(vector<float>)));
    connect(m_paramUI, SIGNAL(sendParams(vector<float>)), this, SLOT(receiveParams(vector<float>)));
    connect(m_paramUI->m_resetButton, SIGNAL(clicked()), this, SLOT(resetBtnClicked()));
    disconnect(getGlobalPick().get(), SIGNAL(resetSeletedObjsSig()), getGlobalPick().get(), SLOT(resetSelectedObjs()));
    connect(getGlobalPick().get(), SIGNAL(resetSeletedObjsSig()), this, SLOT(resetSelectedObjsClicked()));
    //connect(m_paramUI, SIGNAL(showAxis(bool)), this, SLOT(showAxis(bool)));

    //???
    for (std::set<CHMeshShowObjPtr>::iterator it = m_editMeshModels.begin(); it != m_editMeshModels.end(); it++)
    {
        EditMeshTransformFactory::initMeshModelEulerParams(*it);
    }
    m_values.resize(m_editMeshModels.size());
    m_initValues.resize(m_editMeshModels.size());
    int p = 0;
    for (std::set<CHMeshShowObjPtr>::iterator it = m_editMeshModels.begin(); it != m_editMeshModels.end(); it++)
    {
        m_values[p].resize(6);
        m_initValues[p].resize(6);
        m_initValues[p][0] = (*it)->m_params[3];
        m_initValues[p][1] = (*it)->m_params[4];
        m_initValues[p][2] = (*it)->m_params[5];
        m_initValues[p][3] = (*it)->m_params[6];
        m_initValues[p][4] = (*it)->m_params[7];
        m_initValues[p][5] = (*it)->m_params[8];
        p++;
    }

    //多模型时计算操作中心
    CHAABB3D aabb;
    for (std::set<CHMeshShowObjPtr>::iterator it = m_editMeshModels.begin(); it != m_editMeshModels.end(); it++)
    {
        aabb.add((*it)->calSimilarAABB());
    }
    //if (m_editMeshModels.size() > 1)
    {
        m_operationCenter = aabb.getCenterPoint();
    }
    /*else
    {
        m_operationCenter = m_firstMesh->m_rotCenter + QVector3D(m_firstMesh->m_params[6], m_firstMesh->m_params[7], m_firstMesh->m_params[8]);
    } */

    submitToUI();

    //创建参考坐标系
    double ratio = 0.5;
    double maxLenth = max(max(aabb.getLenX(), aabb.getLenY()), aabb.getLenZ()) * ratio;
    QVector3D originCreateCenter = m_operationCenter;
    m_CoordAxis1 = CHLocalCoordinateAxisPtr(new CHLocalCoordinateAxis);
    m_CoordAxis1->create(originCreateCenter, maxLenth);
    m_CoordAxis1->setVisuable(false);
    m_CoordAxis2 = CHLocalCoordinateAxisPtr(new CHLocalCoordinateAxis);
    m_CoordAxis2->create(originCreateCenter, maxLenth);
    m_CoordAxis2->setVisuable(false);
    //m_CoordAxis2->setTransform(CHBaseAlg::instance()->calTransformFromParams(QVector3D(m_meshModel->m_rotCenter[0],
        //m_meshModel->m_rotCenter[1], m_meshModel->m_rotCenter[2]), m_meshModel->m_params));//??????????

    //创建旋转框架
    double rad = sqrt(aabb.getLenX() * aabb.getLenX() + aabb.getLenY() * aabb.getLenY() + aabb.getLenZ() * aabb.getLenZ()) / 2;
    m_adjustCircleX = CHAdjustCirclePtr(new CHAdjustCircle);
    m_adjustCircleX->create(originCreateCenter, rad, QVector3D(1, 0, 0), QVector3D(0, -1, 0));
    m_adjustCircleX->setColor(QColor(125, 0, 0));
    m_adjustCircleY = CHAdjustCirclePtr(new CHAdjustCircle);
    m_adjustCircleY->create(originCreateCenter, rad, QVector3D(0, 1, 0), QVector3D(0, 0, 1));
    m_adjustCircleY->setColor(QColor(0, 125, 0));
    m_adjustCircleZ = CHAdjustCirclePtr(new CHAdjustCircle);
    m_adjustCircleZ->create(originCreateCenter, rad, QVector3D(0, 0, 1), QVector3D(1, 0, 0));
    m_adjustCircleZ->setColor(QColor(0, 0, 125));

    //刷新旋转调节框架
    refreshRotationFrame();

    m_allPickObjs.push_back(m_adjustCircleX);
    m_allPickObjs.push_back(m_adjustCircleY);
    m_allPickObjs.push_back(m_adjustCircleZ);

    m_allShowObjs.push_back(m_CoordAxis1);
    m_allShowObjs.push_back(m_CoordAxis2);
    m_allShowObjs.push_back(m_adjustCircleX);
    m_allShowObjs.push_back(m_adjustCircleY);
    m_allShowObjs.push_back(m_adjustCircleZ);
    m_adjustShowCurve = CHLineSegment3DShowObjPtr(new CHLineSegment3DShowObj);
    m_adjustShowCurve->setVisuable(false);
    m_allShowObjs.push_back(m_adjustShowCurve);
    for (int i = 0; i < m_allShowObjs.size(); i++)
    {
        m_allShowObjs[i]->updateToScene();
    }

    return true;
}

void EditMeshRotationTransformTool::endEdit(MeshDocument& md, GLArea*, MLSceneGLSharedDataContext*)
{
    if (m_paramUI)
    {
        delete m_paramUI;
        m_paramUI = 0;
    }

    for (int i = 0; i < m_allShowObjs.size(); i++)
    {
        m_allShowObjs[i]->setDelete(true);
        /*if (dynamic_pointer_cast<CHAssembly>(m_allShowObjs[i]))
        {
            dynamic_pointer_cast<CHAssembly>(m_allShowObjs[i])->injectPropertiesToChildren();
        }*/
        m_allShowObjs[i]->updateToScene();
    }

    m_allPickObjs.clear();
    m_allShowObjs.clear();

    for (auto actionIt = transformActionsList.begin(); actionIt != transformActionsList.end(); actionIt++)
    {
        if ((*actionIt)->text() == QString("Rotate"))
        {
            (*actionIt)->setIcon(QIcon(":/images/fdm_rotate_icon_e.png"));
            break;
        }
    }

    disconnect(getGlobalPick().get(), SIGNAL(resetSeletedObjsSig()), this, SLOT(resetSelectedObjsClicked()));
    connect(getGlobalPick().get(), SIGNAL(resetSeletedObjsSig()), getGlobalPick().get(), SLOT(resetSelectedObjs()));
}

void EditMeshRotationTransformTool::decorate(MeshModel& meshmodel, GLArea* gla, QPainter* mypainter)
{
    return;
    //GLdouble mm[16], pm[16]; GLint vp[4];
    glGetDoublev(GL_MODELVIEW_MATRIX, mm);
    glGetDoublev(GL_PROJECTION_MATRIX, pm);
    glGetIntegerv(GL_VIEWPORT, vp);

    //glDisable(GL_DEPTH_TEST);
    for (int i = 0; i < m_allShowObjs.size(); i++)
    {
        if (m_allShowObjs[i] && m_allShowObjs[i]->getVisuable())
        {
            //m_allShowObjs[i]->draw();
        }
    }

    //glEnable(GL_DEPTH_TEST);

    //mypainter->drawLine(QPoint(gla->width()-300, gla->height() - 300), QPoint(gla->width(), gla->height()));

}

void EditMeshRotationTransformTool::mousePressEvent(QMouseEvent* event, MeshModel& meshmodel, GLArea* gla)
{
    //BoxBorder::getInstancePtr()->setParam(gla, meshmodel);
    if (event->button() == Qt::LeftButton && m_pickedObj)
    {
        CHAdjustCirclePtr pickObj = dynamic_pointer_cast<CHAdjustCircle>(m_pickedObj);

        m_stepFlag = 1;
        int i = 0;
        for (std::set<CHMeshShowObjPtr>::iterator it = m_editMeshModels.begin(); it != m_editMeshModels.end(); it++)
        {
            m_values[i][0] = (*it)->m_params[3];
            m_values[i][1] = (*it)->m_params[4];
            m_values[i][2] = (*it)->m_params[5];
            m_values[i][3] = (*it)->m_params[6];
            m_values[i][4] = (*it)->m_params[7];
            m_values[i][5] = (*it)->m_params[8];
            i++;

            CH3DPrintModelPtr meshPtr = dynamic_pointer_cast<CH3DPrintModel>(*it);
            if (meshPtr != NULL)
            {
                meshPtr->isSceneIn(meshPtr->calRealAABB(), getDoc()->m_machineBox->getBaseAABB());
            }
        }

        QVector3D pt1 = pickObj->m_lineBody->m_st;
        QVector3D pt2 = pickObj->m_lineBody->m_et;
        QMatrix4x4 sumMat = pickObj->getTransform() /** pickObj->m_lineBody->getTransform()*/;
        pt1 = TransformPack::pRot(sumMat, pt1);
        pt2 = TransformPack::pRot(sumMat, pt2);

        //m_adjustShowCurve = CHLineSegmentShowObjPtr(new CHLineSegmentShowObj);
        m_adjustShowCurve->create(pt1, pt2);
        m_adjustShowCurve->setVisuable(true);
        m_adjustShowCurve->setTransform(QMatrix4x4());//??????????
        m_adjustShowCurve->setColor(pickObj->getColor());
        m_adjustShowCurve->updateToScene();

        curScene->refresh();
    }
}

void EditMeshRotationTransformTool::mouseMoveEvent(QMouseEvent* event, MeshModel&, GLArea* gla)
{
    if (m_stepFlag == 0)
    {
        CHShowObjPtr curPickedObj = 0;
        double pickTol = 10;
        for (int i = 0; i < m_allPickObjs.size(); i++)
        {
            PickResult result;
            if (m_allPickObjs[i]->pick(event->pos().x(), event->pos().y(), result, pickTol))
            {
                curPickedObj = m_allPickObjs[i];
                break;
            }
        }

        if (m_pickedObj != curPickedObj)//只有与上次的结果不一样才会去刷新界面
        {
            for (int i = 0; i < m_allPickObjs.size(); i++)
            {
                m_allPickObjs[i]->setStatus(general);
                /*if (dynamic_pointer_cast<CHAssembly>(m_allPickObjs[i]))
                {
                    dynamic_pointer_cast<CHAssembly>(m_allPickObjs[i])->injectPropertiesToChildren();
                }*/
            }
            m_pickedObj = curPickedObj;
            if (m_pickedObj)
            {
                m_pickedObj->setStatus(canPicked);
                /*if (dynamic_pointer_cast<CHAssembly>(m_pickedObj))
                {
                    dynamic_pointer_cast<CHAssembly>(m_pickedObj)->injectPropertiesToChildren();
                }*/
            }
            curScene->refresh();
        }
    }
    else if (m_stepFlag == 1) //开始旋转操作
    {
        CHAdjustCirclePtr pickObj = dynamic_pointer_cast<CHAdjustCircle>(m_pickedObj);

        /*QVector3D realCenter = pickObj->m_circleBody->m_center + QVector3D(m_meshModel->m_params[6],
            m_meshModel->m_params[7], m_meshModel->m_params[8]);*/
        QVector3D realCenter = m_operationCenter + QVector3D(0, 0, m_operateMoveZ);

        QVector3D st, et;
        curScene->getCurNearFarPoint(event->pos().x(), event->pos().y(), st, et);
        QVector3D dir = et - st;
        float m = QVector3D::dotProduct(dir, pickObj->m_circleBody->m_nor);
        if (fabs(m) > 0.0000001)//射线与平面不平行
        {
            float t = QVector3D::dotProduct(realCenter - st, pickObj->m_circleBody->m_nor) / m;
            QVector3D intersection = st + dir * t;//直线与平面交点的坐标为st + t * dir

            //计算旋转角度
            QVector3D tvec = intersection - realCenter;
            tvec.normalize();
            double angle = acos(QVector3D::dotProduct(tvec, pickObj->m_circleBody->m_refVec));
            QVector3D outvec = QVector3D::crossProduct(pickObj->m_circleBody->m_refVec, tvec);
            if (QVector3D::dotProduct(outvec, pickObj->m_circleBody->m_nor) < 0)
            {
                angle = -angle;
            }

            //刷新中间线
            QMatrix4x4 stran = TransformPack::rotMat(realCenter, pickObj->m_circleBody->m_nor, angle);
            m_adjustShowCurve->setTransform(stran);

            int i = 0;
            for (std::set<CHMeshShowObjPtr>::iterator it = m_editMeshModels.begin(); it != m_editMeshModels.end(); it++)
            {
                //计算纯旋转矩阵
                QMatrix4x4 tran1, tran2, tran3, tran4;
                tran1.rotate(m_values[i][0], QVector3D(1, 0, 0));
                tran2.rotate(m_values[i][1], QVector3D(0, 1, 0));
                tran3.rotate(m_values[i][2], QVector3D(0, 0, 1));
                tran4.rotate(angle / CH_PI * 180.0, pickObj->m_circleBody->m_nor);//度数

                double angleX, angleY, angleZ;
                QMatrix4x4 rotTran = tran4 * tran3 * tran2 * tran1;
                CHBaseAlg::instance()->calEulerAnglesFromRotMatrix(rotTran, angleX, angleY, angleZ);
                //处理到0-2pi之间
                (*it)->m_params[3] = angleX / CH_PI * 180.0;
                (*it)->m_params[4] = angleY / CH_PI * 180.0;
                (*it)->m_params[5] = angleZ / CH_PI * 180.0;
                adjustSingleAngle((*it)->m_params[3]);
                adjustSingleAngle((*it)->m_params[4]);
                adjustSingleAngle((*it)->m_params[5]);

                //还要计算位移效果
                QVector3D currentMeshCenter = (*it)->m_rotCenter + QVector3D(m_values[i][3], m_values[i][4], m_values[i][5]);
                QVector3D newCenter = TransformPack::pRot(stran, currentMeshCenter);
                QVector3D sumMove = newCenter - (*it)->m_rotCenter;
                (*it)->m_params[6] = sumMove[0];
                (*it)->m_params[7] = sumMove[1];
                (*it)->m_params[8] = sumMove[2];

                i++;
            }

            submitToUI();

            for (std::set<CHMeshShowObjPtr>::iterator it = m_editMeshModels.begin(); it != m_editMeshModels.end(); it++)
            {
                //计算变换矩阵
                QMatrix4x4 sumtran1 = CHBaseAlg::instance()->calTransformFromParams(QVector3D((*it)->m_rotCenter[0],
                    (*it)->m_rotCenter[1], (*it)->m_rotCenter[2]), (*it)->m_params);

                //刷新模型
                (*it)->setTransform(sumtran1);
            }

            //刷新参考坐标系
            //m_CoordAxis2->setTransform(sumtran1);

            curScene->refresh();
        }
    }
}

void EditMeshRotationTransformTool::mouseReleaseEvent(QMouseEvent* event, MeshModel& meshmodel, GLArea* gla)
{
    if (event->button() == Qt::LeftButton)
    {
        //???????????????????????????????????pick??????
        CHAABB3D aabb;//当前总的真实包围盒
        for (std::set<CHMeshShowObjPtr>::iterator it = m_editMeshModels.begin(); it != m_editMeshModels.end(); it++)
        {
            aabb.add((*it)->calRealAABB());
        }

        //锁定z=0的打印平台
        if (m_lockToPrintPlatform)
        {
            //CHAABB3D aabb;//?????????
            //for (std::set<CHMeshShowObjPtr>::iterator it = m_editMeshModels.begin(); it != m_editMeshModels.end(); it++)
            //{
            //	aabb.add((*it)->calRealAABB());
            //}
            float moveZ = -aabb.m_Zmin;
            m_operateMoveZ += moveZ;

            for (std::set<CHMeshShowObjPtr>::iterator it = m_editMeshModels.begin(); it != m_editMeshModels.end(); it++)
            {
                (*it)->m_params[8] = (*it)->m_params[8] + moveZ;

                //?????????
                (*it)->m_realAABB.m_Zmin += moveZ;
                (*it)->m_realAABB.m_Zmax += moveZ;

                //计算变换矩阵
                QMatrix4x4 sumtran1 = CHBaseAlg::instance()->calTransformFromParams(QVector3D((*it)->m_rotCenter[0],
                    (*it)->m_rotCenter[1], (*it)->m_rotCenter[2]), (*it)->m_params);

                //刷新模型
                (*it)->setTransform(sumtran1);
            }

            //刷新参考坐标系
            //m_CoordAxis2->setTransform(sumtran1);

            refreshRotationFrame();
        }

        m_stepFlag = 0;
        m_pickedObj = 0;
        for (int i = 0; i < m_allPickObjs.size(); i++)
        {
            m_allPickObjs[i]->setStatus(general);
            /*if (dynamic_pointer_cast<CHAssembly>(m_allPickObjs[i]))
            {
                dynamic_pointer_cast<CHAssembly>(m_allPickObjs[i])->injectPropertiesToChildren();
            }*/
        }
        m_adjustShowCurve->setVisuable(false);
        curScene->refresh();
    }
    //BoxBorder::getInstancePtr()->setParam(gla, meshmodel);
}

void EditMeshRotationTransformTool::showAxis(bool showed)
{
    m_CoordAxis1->setVisuable(showed);
    m_CoordAxis2->setVisuable(showed);

    curScene->refresh();
}

void EditMeshRotationTransformTool::receiveParams(vector<float> params)
{
    CHAABB3D aabb;//?????????
    int i = 0;
    for (std::set<CHMeshShowObjPtr>::iterator it = m_editMeshModels.begin(); it != m_editMeshModels.end(); it++)
    {
        /*if (m_editMeshModels.size() == 1)//单模型不是重置为进入命令的状态，而是状态量直接设为0
        {
            (*it)->m_params[3] = params[0];
            (*it)->m_params[4] = params[1];
            (*it)->m_params[5] = params[2];
        }
        else  */
        {
            //都以进入命令最初状态的、起算
            //反算出每个模型的欧拉角
            //计算纯旋转矩阵
            QMatrix4x4 tran1, tran2, tran3, tran4, tran5, tran6;
            tran1.rotate(m_initValues[i][0], QVector3D(1, 0, 0));
            tran2.rotate(m_initValues[i][1], QVector3D(0, 1, 0));
            tran3.rotate(m_initValues[i][2], QVector3D(0, 0, 1));
            tran4.rotate(params[0], QVector3D(1, 0, 0));
            tran5.rotate(params[1], QVector3D(0, 1, 0));
            tran6.rotate(params[2], QVector3D(0, 0, 1));

            double angleX, angleY, angleZ;
            QMatrix4x4 rotTran = tran6 * tran5 * tran4 * tran3 * tran2 * tran1;
            CHBaseAlg::instance()->calEulerAnglesFromRotMatrix(rotTran, angleX, angleY, angleZ);
            //处理到0-2pi之间
            (*it)->m_params[3] = angleX / CH_PI * 180.0;
            (*it)->m_params[4] = angleY / CH_PI * 180.0;
            (*it)->m_params[5] = angleZ / CH_PI * 180.0;
            adjustSingleAngle((*it)->m_params[3]);
            adjustSingleAngle((*it)->m_params[4]);
            adjustSingleAngle((*it)->m_params[5]);

            //还要计算位移效果
            //以每个模型的中心相对于总中心的向量来计算
            QVector3D vecDir = (*it)->m_rotCenter + QVector3D(m_initValues[i][3], m_initValues[i][4], m_initValues[i][5]) - m_operationCenter;
            QMatrix4x4 ttran1, ttran2, ttran3;
            ttran1.rotate(params[0], QVector3D(1, 0, 0));
            ttran2.rotate(params[1], QVector3D(0, 1, 0));
            ttran3.rotate(params[2], QVector3D(0, 0, 1));
            QVector3D newCenter = TransformPack::vRot(ttran3 * ttran2 * ttran1, vecDir) + m_operationCenter +
                QVector3D(0, 0, m_operateMoveZ);//这里是否以当前点计算需要讨论
            (*it)->m_params[6] = newCenter[0] - (*it)->m_rotCenter[0];
            (*it)->m_params[7] = newCenter[1] - (*it)->m_rotCenter[1];
            (*it)->m_params[8] = newCenter[2] - (*it)->m_rotCenter[2];
        }

        //计算变换矩阵
        (*it)->setTransform(CHBaseAlg::instance()->calTransformFromParams(QVector3D((*it)->m_rotCenter[0],
            (*it)->m_rotCenter[1], (*it)->m_rotCenter[2]), (*it)->m_params));

        if (true/*m_lockToPrintPlatform*/)//??????????????????????????
        {
            aabb.add((*it)->calRealAABB());
        }
        i++;
    }

    if (m_lockToPrintPlatform)
    {
        float moveZ = -aabb.m_Zmin;
        m_operateMoveZ += moveZ;
        for (std::set<CHMeshShowObjPtr>::iterator it = m_editMeshModels.begin(); it != m_editMeshModels.end(); it++)
        {
            (*it)->m_params[8] = (*it)->m_params[8] + moveZ;

            //?????????
            (*it)->m_realAABB.m_Zmin += moveZ;
            (*it)->m_realAABB.m_Zmax += moveZ;

            //计算变换矩阵
            QMatrix4x4 sumtran1 = CHBaseAlg::instance()->calTransformFromParams(QVector3D((*it)->m_rotCenter[0],
                (*it)->m_rotCenter[1], (*it)->m_rotCenter[2]), (*it)->m_params);

            //刷新模型
            (*it)->setTransform(sumtran1);
        }
    }

    //刷新参考坐标系
    //m_CoordAxis2->setTransform(sumtran1);

    //刷新旋转调节框架
    refreshRotationFrame();
    for (std::set<CHMeshShowObjPtr>::iterator it = m_editMeshModels.begin(); it != m_editMeshModels.end(); it++)
    {
        CH3DPrintModelPtr meshPtr = dynamic_pointer_cast<CH3DPrintModel>(*it);
        if (meshPtr != NULL)
        {
            meshPtr->isSceneIn(meshPtr->getRealAABB(), getDoc()->m_machineBox->getBaseAABB());
        }
    }

    curScene->refresh();
}

void EditMeshRotationTransformTool::resetBtnClicked()
{
    auto bIt = getGlobalPick()->m_selectedObjs.begin();
    auto eIt = getGlobalPick()->m_selectedObjs.end();
    for (bIt; bIt != eIt; bIt++)
    {
        std::dynamic_pointer_cast<CH3DPrintModel>(*bIt)->resetRot();
    }
    submitToUI();
}

void EditMeshRotationTransformTool::resetSelectedObjsClicked()
{
    getGlobalPick()->resetSelectedObjs();
    submitToUI();
}

void EditMeshRotationTransformTool::adjustSingleAngle(float& angle)
{
    int n = (int)(angle / 360.0);
    if (angle < 0)
    {
        n--;
    }
    angle = angle - 360.0 * n;
}

void EditMeshRotationTransformTool::refreshRotationFrame()
{
    if (m_adjustCircleX == nullptr || m_adjustCircleY == nullptr || m_adjustCircleZ == nullptr)
        return;
    QMatrix4x4 tran;
    tran.translate(QVector3D(0, 0, m_operateMoveZ));
    m_adjustCircleX->setTransform(tran);
    //m_adjustCircleX->injectPropertiesToChildren();
    m_adjustCircleY->setTransform(tran);
    //m_adjustCircleY->injectPropertiesToChildren();
    m_adjustCircleZ->setTransform(tran);
    //m_adjustCircleZ->injectPropertiesToChildren();
}

void EditMeshRotationTransformTool::submitToUI()
{
    vector<float> params(3);
    /*if (m_editMeshModels.size() == 1)//单选输出模型本身旋转状态量
    {
        params[0] = m_firstMesh->m_params[3];
        params[1] = m_firstMesh->m_params[4];
        params[2] = m_firstMesh->m_params[5];
    }
    else*///每个旋转模型的增量并不相同，不能仿照平移计算
    {
        //计算多模型当作一个整体的总的纯旋转矩阵
        /*QVector3D centerStart = QVector3D(mesh.m_rotCenter[0], mesh.m_rotCenter[1], mesh.m_rotCenter[2]) +
            QVector3D(m_initValues[0][3], m_initValues[0][4], m_initValues[0][5]);
        QVector3D centerEnd = QVector3D(mesh.m_rotCenter[0], mesh.m_rotCenter[1], mesh.m_rotCenter[2]) +
            QVector3D(mesh.m_params[6], mesh.m_rotCenter[7], mesh.m_rotCenter[8]);
        QMatrix4x4 rotTran = TransformPack::rotMat(centerStart - m_operationCenter, centerEnd - m_operationCenter,
            QVector3D(0, 0, 0));*/
        QMatrix4x4 tran1, tran2, tran3, tran4, tran5, tran6;
        tran1.rotate(m_initValues[0][0], QVector3D(1, 0, 0));
        tran2.rotate(m_initValues[0][1], QVector3D(0, 1, 0));
        tran3.rotate(m_initValues[0][2], QVector3D(0, 0, 1));
        tran4.rotate(m_firstMesh->m_params[3], QVector3D(1, 0, 0));
        tran5.rotate(m_firstMesh->m_params[4], QVector3D(0, 1, 0));
        tran6.rotate(m_firstMesh->m_params[5], QVector3D(0, 0, 1));
        //(tran3 * tran2 * tran1).inverted()可以优化
        QMatrix4x4 rotTran = tran6 * tran5 * tran4 * (tran3 * tran2 * tran1).inverted();

        double angleX, angleY, angleZ;
        CHBaseAlg::instance()->calEulerAnglesFromRotMatrix(rotTran, angleX, angleY, angleZ);

        //处理到0-2pi之间
        params[0] = angleX / CH_PI * 180.0;
        params[1] = angleY / CH_PI * 180.0;
        params[2] = angleZ / CH_PI * 180.0;
        adjustSingleAngle(params[0]);
        adjustSingleAngle(params[1]);
        adjustSingleAngle(params[2]);
    }
    emit sendParams(params);
}



