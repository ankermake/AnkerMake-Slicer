/****************************************************************************
 * MeshLab                                                           o o     *
 * A versatile mesh processing toolbox                             o     o   *
 *                                                                _   O  _   *
 * Copyright(C) 2008                                                \/)\/    *
 * Visual Computing Lab                                            /\/|      *
 * ISTI - Italian National Research Council                           |      *
 *                                                                    \      *
 * All rights reserved.                                                      *
 *                                                                           *
 * This program is free software; you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation; either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)          *
 * for more details.                                                         *
 *                                                                           *
 ****************************************************************************/

#include <meshlab/glarea.h>
#include "edit_meshrotationtransform.h"
#include <wrap/qt/gl_label.h>
#include <wrap/gui/trackball.h>
#include "wrap/gl/space.h"
#include "TransformPack.h"
#include "CHLine3D.h"
#include "CHBaseAlg.h"


using namespace vcg;


CHLocalCoordinateAxis::CHLocalCoordinateAxis()
{
}

CHLocalCoordinateAxis::~CHLocalCoordinateAxis()
{
}

void CHLocalCoordinateAxis::create(QVector3D center, double lenth)
{
	m_axisX = CHLineSegment3DShowObjPtr(new CHLineSegment3DShowObj);
	m_axisX->create(center, center + QVector3D(lenth, 0, 0));
	m_axisX->setColor(QColor(125, 0, 0));

	m_axisY = CHLineSegment3DShowObjPtr(new CHLineSegment3DShowObj);
	m_axisY->create(center, center + QVector3D(0, lenth, 0));
	m_axisY->setColor(QColor(0, 125, 0));

	m_axisZ = CHLineSegment3DShowObjPtr(new CHLineSegment3DShowObj);
	m_axisZ->create(center, center + QVector3D(0, 0, lenth));
	m_axisZ->setColor(QColor(0, 0, 125));
}

void CHLocalCoordinateAxis::draw()
{
	if (m_axisX)
	{
		QMatrix4x4 tmat = m_axisX->getTransform();
		m_axisX->setTransform(m_tran * tmat);
		m_axisX->draw();
		m_axisX->setTransform(tmat);//??

		tmat = m_axisY->getTransform();
		m_axisY->setTransform(m_tran * tmat);
		m_axisY->draw();
		m_axisY->setTransform(tmat);//??

		tmat = m_axisZ->getTransform();
		m_axisZ->setTransform(m_tran * tmat);
		m_axisZ->draw();
		m_axisZ->setTransform(tmat);//??
	}
}

bool CHLocalCoordinateAxis::pick(int pixelX, int pixelY, double* mm, double* pm, int* vp, PickResult& result, int pickTol)
{
	return false;
}

CHAdjustCircle::CHAdjustCircle()
{
}

CHAdjustCircle::~CHAdjustCircle()
{
}

void CHAdjustCircle::create(QVector3D center, double rad, QVector3D nor, QVector3D refVec, QColor color)
{
	//m_orginColor = color;
	setColor(color);

	m_circleBody = CHCircleShowObjPtr(new CHCircleShowObj);
	m_circleBody->create(center, rad, nor, refVec);
	m_circleBody->setColor(color);

	m_lineBody = CHLineSegment3DShowObjPtr(new CHLineSegment3DShowObj);
	m_lineBody->create(center, center + refVec * rad);
	m_lineBody->setColor(color);

	m_adjustPointBody = CHPointShowObjPtr(new CHPointShowObj);
	m_adjustPointBody->create(center + refVec * rad);
	m_adjustPointBody->setColor(color);

}

void CHAdjustCircle::draw()
{
	if (m_circleBody)
	{
		QMatrix4x4 tmat = m_circleBody->getTransform();
		m_circleBody->setTransform(m_tran * tmat);
		m_circleBody->draw();
		m_circleBody->setTransform(tmat);//??

		tmat = m_lineBody->getTransform();
		m_lineBody->setTransform(m_tran * tmat);
		m_lineBody->draw();
		m_lineBody->setTransform(tmat);

		tmat = m_adjustPointBody->getTransform();
		m_adjustPointBody->setTransform(m_tran * tmat);
		m_adjustPointBody->draw();
		m_adjustPointBody->setTransform(tmat);
	}
}

bool CHAdjustCircle::pick(int pixelX, int pixelY, double* mm, double* pm, int* vp, PickResult& result, int pickTol)
{
	//QMatrix4x4 tran = m_adjustPointBody->getTransform();
	//m_adjustPointBody->setTransform(m_tran * tran);
	//bool out = m_adjustPointBody->pick(pixelX, pixelY, mm, pm, vp, result, pickTol);
	//m_adjustPointBody->setTransform(tran);//??
	//result.m_pickObj = shared_from_this();


	QMatrix4x4 tran = m_lineBody->getTransform();
	m_lineBody->setTransform(m_tran * tran);
	bool out = m_lineBody->pick(pixelX, pixelY, mm, pm, vp, result, pickTol);
	m_lineBody->setTransform(tran);//??
	result.m_pickObj = shared_from_this();

	return out;
}

void CHAdjustCircle::setStatus(ObjStatus status)
{
	m_status = status;
	if (m_circleBody)
	{
		m_circleBody->setStatus(status);
		m_lineBody->setStatus(status);
		m_adjustPointBody->setStatus(status);
	}
}

EditMeshRotationTransformTool::EditMeshRotationTransformTool(OperateType type)
{
	m_operationType = type;
	m_stepFlag = 0;
	m_glView = 0;
	m_meshModel = 0;
	m_adjustShowCurve = 0;
	m_CoordZToZero = true;
}

//const QString EditMeshTransformTool::info()
//{
//	if (m_operationType == ORotate)
//	{
//
//	}
//    return tr("transform mesh model");
//}

bool EditMeshRotationTransformTool::startEdit(MeshModel& meshmodel, GLArea* gla, MLSceneGLSharedDataContext* scenedata)
{
    //connect(this, SIGNAL(suspendEditToggle()), gla, SLOT(suspendEditToggle()));

	m_stepFlag = 0;	
	m_adjustShowCurve = 0;
	m_pickedObj = 0;
	m_glView = gla;
	m_meshModel = &meshmodel;

	m_paramUI = new CHModelTransformParamsSetUI(gla);
	m_paramUI->show();

	connect(this, SIGNAL(sendParams(vector<float>)), m_paramUI, SLOT(receiveParams(vector<float>)));
	connect(m_paramUI, SIGNAL(sendParams(vector<float>)), this, SLOT(receiveParams(vector<float>)));
	connect(m_paramUI, SIGNAL(showAxis(bool)), this, SLOT(showAxis(bool)));

	
	Box3f aabb = meshmodel.cm.bbox;
	if ((int)meshmodel.cm.m_params.size() == 0)//??????
	{
		Point3f pt = aabb.Center();

		meshmodel.cm.m_rotCenter[0] = pt.X();
		meshmodel.cm.m_rotCenter[1] = pt.Y();
		meshmodel.cm.m_rotCenter[2] = pt.Z();
		meshmodel.cm.m_params.resize(9);
		for (int i = 0; i < 3; i++)
		{
			meshmodel.cm.m_params[i] = 1;
		}
		for (int i = 3; i < 9; i++)
		{
			meshmodel.cm.m_params[i] = 0;
		}
	}
	emit sendParams(meshmodel.cm.m_params);


	//???????
	double ratio = 0.5;
	double maxLenth = max(max(aabb.DimX(), aabb.DimY()), aabb.DimZ()) * ratio;
	QVector3D originCreateCenter(meshmodel.cm.m_rotCenter[0], meshmodel.cm.m_rotCenter[1], meshmodel.cm.m_rotCenter[2]);
	
	m_CoordAxis1 = CHLocalCoordinateAxisPtr(new CHLocalCoordinateAxis);
	m_CoordAxis1->create(originCreateCenter, maxLenth);
	m_CoordAxis1->setVisuable(false);
	m_CoordAxis2 = CHLocalCoordinateAxisPtr(new CHLocalCoordinateAxis);
	m_CoordAxis2->create(originCreateCenter, maxLenth);
	m_CoordAxis2->setVisuable(false);
	m_CoordAxis2->setTransform(calTransformFromParams());//??????????
	if (m_operationType == ORotate)
	{
		//??????
		double rad = sqrt(aabb.DimX() * aabb.DimX() + aabb.DimY() * aabb.DimY() + aabb.DimZ() * aabb.DimZ()) / 2;
		m_adjustCircleX = CHAdjustCirclePtr(new CHAdjustCircle);
		m_adjustCircleX->create(originCreateCenter, rad, QVector3D(1, 0, 0), QVector3D(0, -1, 0), QColor(125, 0, 0));
		m_adjustCircleY = CHAdjustCirclePtr(new CHAdjustCircle);
		m_adjustCircleY->create(originCreateCenter, rad, QVector3D(0, 1, 0), QVector3D(0, 0, 1), QColor(0, 125, 0));
		m_adjustCircleZ = CHAdjustCirclePtr(new CHAdjustCircle);
		m_adjustCircleZ->create(originCreateCenter, rad, QVector3D(0, 0, 1), QVector3D(1, 0, 0), QColor(0, 0, 125));

		//????????
		refreshRotationFrame();

		m_allPickObjs.push_back(m_adjustCircleX);
		m_allPickObjs.push_back(m_adjustCircleY);
		m_allPickObjs.push_back(m_adjustCircleZ);

		m_allShowObjs.push_back(m_CoordAxis1);
		m_allShowObjs.push_back(m_CoordAxis2);
		m_allShowObjs.push_back(m_adjustCircleX);
		m_allShowObjs.push_back(m_adjustCircleY);
		m_allShowObjs.push_back(m_adjustCircleZ);
		m_adjustShowCurve = CHLineSegment3DShowObjPtr(new CHLineSegment3DShowObj);
		m_adjustShowCurve->setVisuable(false);
		m_allShowObjs.push_back(m_adjustShowCurve);
	}
	else if (m_operationType == OMove)
	{
		m_adjustAxisX = CHLineSegment3DShowObjPtr(new CHLineSegment3DShowObj);
		m_adjustAxisX->create(originCreateCenter, originCreateCenter + QVector3D(maxLenth, 0, 0));
		m_adjustAxisX->setColor(QColor(125, 0, 0));
		m_adjustAxisY = CHLineSegment3DShowObjPtr(new CHLineSegment3DShowObj);
		m_adjustAxisY->create(originCreateCenter, originCreateCenter + QVector3D(0, maxLenth, 0));
		m_adjustAxisY->setColor(QColor(0, 125, 0));
		m_adjustAxisZ = CHLineSegment3DShowObjPtr(new CHLineSegment3DShowObj);
		m_adjustAxisZ->create(originCreateCenter, originCreateCenter + QVector3D(0, 0, maxLenth));
		m_adjustAxisZ->setColor(QColor(0, 0, 125));
		m_adjustOrigin = CHPointShowObjPtr(new CHPointShowObj);
		m_adjustOrigin->create(originCreateCenter);
		m_adjustOrigin->setColor(QColor(125, 0, 125));

		//????????
		refreshMoveFrame();

		m_allPickObjs.push_back(m_adjustAxisX);
		m_allPickObjs.push_back(m_adjustAxisY);
		m_allPickObjs.push_back(m_adjustAxisZ);
		m_allPickObjs.push_back(m_adjustOrigin);

		m_allShowObjs.push_back(m_CoordAxis1);
		m_allShowObjs.push_back(m_CoordAxis2);
		m_allShowObjs.push_back(m_adjustAxisX);
		m_allShowObjs.push_back(m_adjustAxisY);
		m_allShowObjs.push_back(m_adjustAxisZ);
		m_allShowObjs.push_back(m_adjustOrigin);
	}
	else if (m_operationType == OScale)
	{




	}

	return true;
}

void EditMeshRotationTransformTool::endEdit(MeshModel&, GLArea*, MLSceneGLSharedDataContext*)
{
	delete m_paramUI;

	m_allPickObjs.clear();
	m_allShowObjs.clear();

}

void EditMeshRotationTransformTool::decorate(MeshModel& meshmodel, GLArea* gla, QPainter* mypainter)
{
	//GLdouble mm[16], pm[16]; GLint vp[4];
	glGetDoublev(GL_MODELVIEW_MATRIX, mm);
	glGetDoublev(GL_PROJECTION_MATRIX, pm);
	glGetIntegerv(GL_VIEWPORT, vp);

	//glDisable(GL_DEPTH_TEST);
	if (m_operationType == ORotate)
	{
		for (int i = 0; i < m_allShowObjs.size(); i++)
		{
			if (m_allShowObjs[i] && m_allShowObjs[i]->getVisuable())
			{
				m_allShowObjs[i]->draw();
			}
		}
	}
	else if (m_operationType == OMove)
	{
		glDisable(GL_DEPTH_TEST);
		for (int i = 0; i < m_allShowObjs.size(); i++)
		{
			if (m_allShowObjs[i] && m_allShowObjs[i]->getVisuable())
			{
				m_allShowObjs[i]->draw();
			}
		}
		glEnable(GL_DEPTH_TEST);
	}
	else if (m_operationType == OScale)
	{


	}

	//glEnable(GL_DEPTH_TEST);

	//mypainter->drawLine(QPoint(gla->width()-300, gla->height() - 300), QPoint(gla->width(), gla->height()));

}

void EditMeshRotationTransformTool::mousePressEvent(QMouseEvent* event, MeshModel&, GLArea*)
{
	if (m_operationType == ORotate)
	{
		if (event->button() == Qt::LeftButton && m_pickedObj)
		{			
			CHAdjustCirclePtr pickObj = dynamic_pointer_cast<CHAdjustCircle>(m_pickedObj);

			m_stepFlag = 1;
			m_value[0] = m_meshModel->cm.m_params[3];
			m_value[1] = m_meshModel->cm.m_params[4];
			m_value[2] = m_meshModel->cm.m_params[5];

			QVector3D pt1 = pickObj->m_lineBody->m_st;
			QVector3D pt2 = pickObj->m_lineBody->m_et;
			QMatrix4x4 sumMat = pickObj->getTransform() * pickObj->m_lineBody->getTransform();
			pt1 = TransformPack::pRot(sumMat, pt1);
			pt2 = TransformPack::pRot(sumMat, pt2);

			//m_adjustShowCurve = CHLineSegmentShowObjPtr(new CHLineSegmentShowObj);
			m_adjustShowCurve->create(pt1, pt2);
			m_adjustShowCurve->setVisuable(true);
			m_adjustShowCurve->setTransform(QMatrix4x4());//??????????
			m_adjustShowCurve->setColor(pickObj->getColor());

			m_glView->update();			
		}
	}
	else if (m_operationType == OMove)
	{
		if (event->button() == Qt::LeftButton && m_pickedObj)
		{
			m_stepFlag = 1;
			m_value[0] = m_meshModel->cm.m_params[6];
			m_value[1] = m_meshModel->cm.m_params[7];
			m_value[2] = m_meshModel->cm.m_params[8];

			//?pick????z=0???
			if (dynamic_pointer_cast<CHPointShowObj>(m_pickedObj))
			{
				//?????????????m_pickCoord?????????????????
				double nres[3];
				double fres[3];
				gluUnProject(event->pos().x(), vp[3] - event->pos().y(), -1.0, mm, pm, vp, &nres[0], &nres[1], &nres[2]);
				gluUnProject(event->pos().x(), vp[3] - event->pos().y(), 1.0, mm, pm, vp, &fres[0], &fres[1], &fres[2]);
				CHLine3DPtr ray(new CHLine3D);
				ray->create(QVector3D(nres[0], nres[1], nres[2]), QVector3D(fres[0], fres[1], fres[2]));
				
				//???z=0?????
				QVector3D dir = ray->m_et - ray->m_st;
				float m = dir[2]/*QVector3D::dotProduct(dir, QVector3D(0,0,1))*/;
				if (fabs(m) > 0.0000001)//????????
				{
					float t = -ray->m_st[2] /* QVector3D::dotProduct( -ray->m_st, QVector3D(0, 0, 1))*/ / m;
					m_pickCoord = ray->m_st + dir * t;//???????????st + t * dir
				}
			}
		}
	}
	else if (m_operationType == OScale)
	{


	}
}

void EditMeshRotationTransformTool::mouseMoveEvent(QMouseEvent* event, MeshModel& meshmodel, GLArea* gla)
{
	//??????
	//??????GL_MODELVIEW_MATRIX??????????????decorate????
	/*GLdouble mm[16], pm[16]; GLint vp[4];
	glGetDoublev(GL_MODELVIEW_MATRIX, mm);
	glGetDoublev(GL_PROJECTION_MATRIX, pm);
	glGetIntegerv(GL_VIEWPORT, vp);*/
	if (m_operationType == ORotate)
	{
		if (m_stepFlag == 0)
		{
			CHShowObjPtr curPickedObj = 0;
			double pickTol = 10;
			for (int i = 0; i < m_allPickObjs.size(); i++)
			{
				PickResult result;
				if (m_allPickObjs[i]->pick(event->pos().x(), event->pos().y(), mm, pm, vp, result, pickTol))
				{
					curPickedObj = /*dynamic_pointer_cast<CHAdjustCircle>*/(m_allPickObjs[i]);
					break;
				}
			}

			if (m_pickedObj != curPickedObj)//??????????????????
			{
				for (int i = 0; i < m_allPickObjs.size(); i++)
				{
					m_allPickObjs[i]->setStatus(general);
				}
				m_pickedObj = curPickedObj;
				if (m_pickedObj)
				{
					m_pickedObj->setStatus(canPicked);
				}
				gla->update();
			}
		}
		else if (m_stepFlag == 1) //??????
		{
			CHAdjustCirclePtr pickObj = dynamic_pointer_cast<CHAdjustCircle>(m_pickedObj);

			QVector3D realCenter = pickObj->m_circleBody->m_center + QVector3D(meshmodel.cm.m_params[6],
				meshmodel.cm.m_params[7], meshmodel.cm.m_params[8]);

			double nres[3];
			double fres[3];
			gluUnProject(event->pos().x(), vp[3] - event->pos().y(), -1.0, mm, pm, vp, &nres[0], &nres[1], &nres[2]);
			gluUnProject(event->pos().x(), vp[3] - event->pos().y(), 1.0, mm, pm, vp, &fres[0], &fres[1], &fres[2]);
			QVector3D st(nres[0], nres[1], nres[2]);
			QVector3D et(fres[0], fres[1], fres[2]);
			QVector3D dir = et - st;
			float m = QVector3D::dotProduct(dir, pickObj->m_circleBody->m_nor);
			if (fabs(m) > 0.0000001)//????????
			{
				float t = QVector3D::dotProduct(realCenter - st, pickObj->m_circleBody->m_nor) / m;
				QVector3D intersection = st + dir * t;//???????????st + t * dir

				//??????
				QVector3D tvec = intersection - realCenter;
				tvec.normalize();
				double angle = acos(QVector3D::dotProduct(tvec, pickObj->m_circleBody->m_refVec));
				QVector3D outvec = QVector3D::crossProduct(pickObj->m_circleBody->m_refVec, tvec);
				if (QVector3D::dotProduct(outvec, pickObj->m_circleBody->m_nor) < 0)
				{
					angle = -angle;
				}

				//?????
				QMatrix4x4 stran = TransformPack::rotMat(realCenter, pickObj->m_circleBody->m_nor, angle);
				m_adjustShowCurve->setTransform(stran);


				//???????
				QMatrix4x4 tran1, tran2, tran3, tran4;
				tran1.rotate(m_value[0], QVector3D(1, 0, 0));
				tran2.rotate(m_value[1], QVector3D(0, 1, 0));
				tran3.rotate(m_value[2], QVector3D(0, 0, 1));
				tran4.rotate(angle / CH_PI * 180.0, pickObj->m_circleBody->m_nor);//??

				calEulerAnglesFromRotMatrix(tran4 * tran3 * tran2 * tran1);//???????????
				emit sendParams(m_meshModel->cm.m_params);

				//??????
				QMatrix4x4 sumtran1 = calTransformFromParams();

				//????
				m_meshModel->cm.Tr = Matrix44m(sumtran1.transposed().data());

				//???????
				m_CoordAxis2->setTransform(sumtran1);
				gla->update();
			}
		}
	}
	else if (m_operationType == OMove)
	{
		if (m_stepFlag == 0)
		{
			//??pick??
			CHShowObjPtr curPickedObj = 0;
			double pickTol = 10;
			vector<PickResult> curPickerObjs;
			for (int i = 0; i < m_allPickObjs.size(); i++)
			{
				PickResult result;
				if (m_allPickObjs[i]->pick(event->pos().x(), event->pos().y(), mm, pm, vp, result, pickTol))
				{
					curPickerObjs.push_back(result);
				}
			}
			int num = (int)curPickerObjs.size();
			if (num == 1)
			{
				curPickedObj = curPickerObjs[0].m_pickObj;

				m_pickCoord = curPickerObjs[0].m_ptOnObj;//?????????????
			}
			else if(num > 1)
			{
				std::sort(curPickerObjs.begin(), curPickerObjs.end(), CHShowObj::pred1);//????
				double ttol = 0.001;
				vector<PickResult> minDeepObjs;//???????????
				minDeepObjs.push_back(curPickerObjs[0]);
				for (int i = 1; i < num; i++)
				{
					if (fabs(curPickerObjs[i].m_deep - curPickerObjs[0].m_deep) < ttol)
					{
						minDeepObjs.push_back(curPickerObjs[i]);
					}
				}

				std::sort(minDeepObjs.begin(), minDeepObjs.end(), CHShowObj::pred2);//pick?????
				curPickedObj = minDeepObjs[0].m_pickObj;

				m_pickCoord = minDeepObjs[0].m_ptOnObj;//?????????????
			}

			if (m_pickedObj != curPickedObj)//??????????????????
			{
				for (int i = 0; i < m_allPickObjs.size(); i++)
				{
					m_allPickObjs[i]->setStatus(general);
				}
				m_pickedObj = curPickedObj;
				if (m_pickedObj)
				{
					m_pickedObj->setStatus(canPicked);
				}
				gla->update();
			}
		}
		else if (m_stepFlag == 1) //??????
		{
			//????
			double nres[3];
			double fres[3];
			gluUnProject(event->pos().x(), vp[3] - event->pos().y(), -1.0, mm, pm, vp, &nres[0], &nres[1], &nres[2]);
			gluUnProject(event->pos().x(), vp[3] - event->pos().y(), 1.0, mm, pm, vp, &fres[0], &fres[1], &fres[2]);
			CHLine3DPtr ray(new CHLine3D);
			ray->create(QVector3D(nres[0], nres[1], nres[2]), QVector3D(fres[0], fres[1], fres[2]));

			if (dynamic_pointer_cast<CHPointShowObj>(m_pickedObj))//????
			{
				//???z=0??????????????????z?????
				QVector3D dir = ray->m_et - ray->m_st;
				float m = dir[2]/*QVector3D::dotProduct(dir, QVector3D(0,0,1))*/;
				if (fabs(m) > 0.0000001)//????????
				{
					float t = -ray->m_st[2] /* QVector3D::dotProduct( -ray->m_st, QVector3D(0, 0, 1))*/ / m;
					QVector3D intersection = ray->m_st + dir * t;//???????????st + t * dir

					m_meshModel->cm.m_params[6] = m_value[0] + intersection[0] - m_pickCoord[0];
					m_meshModel->cm.m_params[7] = m_value[1] + intersection[1] - m_pickCoord[1];
					m_meshModel->cm.m_params[8] = m_value[2] + intersection[2] - m_pickCoord[2];
				}
			}
			else//??????
			{
				CHLineSegment3DShowObjPtr moveLine = dynamic_pointer_cast<CHLineSegment3DShowObj>(m_pickedObj);

				//????????????????????????????????????pick?????????
				QVector3D coord1 = moveLine->m_st;
				QVector3D coord2 = moveLine->m_et;
				coord1 = TransformPack::pRot(moveLine->getTransform(), coord1);
				coord2 = TransformPack::pRot(moveLine->getTransform(), coord2);
				CHLine3DPtr line(new CHLine3D);
				line->create(coord1, coord2);

				LineLineExtremeResult result;
				CHBaseAlg::instance()->extremeBetweenLineAndLine(line, ray, result);

				//
				m_meshModel->cm.m_params[6] = m_value[0] + result.m_pt1[0] - m_pickCoord[0];
				m_meshModel->cm.m_params[7] = m_value[1] + result.m_pt1[1] - m_pickCoord[1];
				m_meshModel->cm.m_params[8] = m_value[2] + result.m_pt1[2] - m_pickCoord[2];
			}

			emit sendParams(m_meshModel->cm.m_params);

			//??????
			QMatrix4x4 sumtran1 = calTransformFromParams();

			//????
			m_meshModel->cm.Tr = Matrix44m(sumtran1.transposed().data());

			//????????
			refreshMoveFrame();

			//???????
			m_CoordAxis2->setTransform(sumtran1);
			gla->update();			
		}
	}
	else if (m_operationType == OScale)
	{


	}




}

void EditMeshRotationTransformTool::mouseReleaseEvent(QMouseEvent* event, MeshModel&, GLArea*)
{
	//??z=0?????

	if (m_operationType == ORotate)
	{
		if (event->button() == Qt::LeftButton)
		{
			m_stepFlag = 0;
			m_pickedObj = 0;
			for (int i = 0; i < m_allPickObjs.size(); i++)
			{
				m_allPickObjs[i]->setStatus(general);
			}

			m_adjustShowCurve->setVisuable(false);
			m_glView->update();
		}
	}
	else if (m_operationType == OMove)
	{
		if (event->button() == Qt::LeftButton)
		{
			m_stepFlag = 0;
			m_pickedObj = 0;
			for (int i = 0; i < m_allPickObjs.size(); i++)
			{
				m_allPickObjs[i]->setStatus(general);
			}
			m_glView->update();
		}
	}
	else if (m_operationType == OScale)
	{


	}
}

void EditMeshRotationTransformTool::showAxis(bool showed)
{
	m_CoordAxis1->setVisuable(showed);
	m_CoordAxis2->setVisuable(showed);
	m_glView->update();
}

void EditMeshRotationTransformTool::receiveParams(vector<float> params)
{
	m_meshModel->cm.m_params = params;
	//adjustAnglesBetweenZeroAnd360();//????????

	//emit sendParams(m_params);//?????????

	//??????
	QMatrix4x4 sumtran1 = calTransformFromParams();

	//????
	m_meshModel->cm.Tr = Matrix44m(sumtran1.transposed().data());
	//m_meshbody->setModelTran(sumtran1);

	//???????
	m_CoordAxis2->setTransform(sumtran1);

	if (m_operationType == ORotate)
	{
		//????????
		refreshRotationFrame();
	}
	else if (m_operationType == OMove)
	{
		//????????
		refreshMoveFrame();
	}
	else if (m_operationType == OScale)
	{

	}

	m_glView->update();
}

QMatrix4x4 EditMeshRotationTransformTool::calTransformFromParams()
{
	QMatrix4x4 tran1, tran2, tran3, tran4, tran5, tran6, tran7;
	tran1.translate(QVector3D(-m_meshModel->cm.m_rotCenter[0], -m_meshModel->cm.m_rotCenter[1], -m_meshModel->cm.m_rotCenter[2]));
	tran2.scale(m_meshModel->cm.m_params[0], m_meshModel->cm.m_params[1], m_meshModel->cm.m_params[2]);
	tran3.rotate(m_meshModel->cm.m_params[3], QVector3D(1, 0, 0));
	tran4.rotate(m_meshModel->cm.m_params[4], QVector3D(0, 1, 0));
	tran5.rotate(m_meshModel->cm.m_params[5], QVector3D(0, 0, 1));
	tran6.translate(QVector3D(m_meshModel->cm.m_params[6], m_meshModel->cm.m_params[7], m_meshModel->cm.m_params[8]));//??????????????????????
	tran7.translate(QVector3D(m_meshModel->cm.m_rotCenter[0], m_meshModel->cm.m_rotCenter[1], m_meshModel->cm.m_rotCenter[2]));

	return tran7 * tran6 * tran5 * tran4 * tran3 * tran2 * tran1;
}

void EditMeshRotationTransformTool::calEulerAnglesFromRotMatrix(QMatrix4x4 rotTran)
{
	float value[4][4];
	float* tdata = rotTran.transposed().data();//data???opengl??????
	for (int i = 0; i < 4; i++)
	{
		for (int j = 0; j < 4; j++)
		{
			value[i][j] = tdata[i * 4 + j];
		}
	}

	double angleX, angleY, angleZ;
	double tol = 0.00000001;
	if (fabs(value[2][0] - 1) <= tol)//=1
	{
		angleY = -CH_PI / 2.0;
		angleZ = 0;//???????
		angleX = -angleZ + atan2(-value[0][1], -value[0][2]);
	}
	else if (fabs(value[2][0] + 1) <= tol)//=-1
	{
		angleY = CH_PI / 2.0;
		angleZ = 0;//???????
		angleX = angleZ + atan2(value[0][1], value[0][2]);
	}
	else   //!= ??1
	{
		angleY = -asin(value[2][0]);
		//angleY = FZ_PI - angleY;//?????????

		double tt = cos(angleY);
		angleX = atan2(value[2][1] / tt, value[2][2] / tt);
		angleZ = atan2(value[1][0] / tt, value[0][0] / tt);
	}

	//???0-2pi??
	m_meshModel->cm.m_params[3] = angleX / CH_PI * 180.0;
	m_meshModel->cm.m_params[4] = angleY / CH_PI * 180.0;
	m_meshModel->cm.m_params[5] = angleZ / CH_PI * 180.0;
	adjustAnglesBetweenZeroAnd360();
}

void EditMeshRotationTransformTool::adjustSingleAngle(float& angle)
{
	int n = (int)(angle / 360.0);
	if (angle < 0)
	{
		n--;
	}
	angle = angle - 360.0 * n;
}

void EditMeshRotationTransformTool::adjustAnglesBetweenZeroAnd360()
{
	adjustSingleAngle(m_meshModel->cm.m_params[3]);
	adjustSingleAngle(m_meshModel->cm.m_params[4]);
	adjustSingleAngle(m_meshModel->cm.m_params[5]);
}

void EditMeshRotationTransformTool::refreshRotationFrame()
{
	float maxScale = max(max(fabs(m_meshModel->cm.m_params[0]), fabs(m_meshModel->cm.m_params[1])), fabs(m_meshModel->cm.m_params[2]));
	QMatrix4x4 adjustCircleTran1 = TransformPack::scale(QVector3D(m_meshModel->cm.m_rotCenter[0], m_meshModel->cm.m_rotCenter[1],
		m_meshModel->cm.m_rotCenter[2]), maxScale, maxScale, maxScale);
	QMatrix4x4 adjustCircleTran2;
	adjustCircleTran2.translate(QVector3D(m_meshModel->cm.m_params[6], m_meshModel->cm.m_params[7], m_meshModel->cm.m_params[8]));
	QMatrix4x4 sumtran2 = adjustCircleTran2 * adjustCircleTran1;
	m_adjustCircleX->setTransform(sumtran2);
	m_adjustCircleY->setTransform(sumtran2);
	m_adjustCircleZ->setTransform(sumtran2);
}

void EditMeshRotationTransformTool::refreshMoveFrame()
{
	float maxScale = max(max(fabs(m_meshModel->cm.m_params[0]), fabs(m_meshModel->cm.m_params[1])), fabs(m_meshModel->cm.m_params[2]));
	QMatrix4x4 adjustCircleTran1 = TransformPack::scale(QVector3D(m_meshModel->cm.m_rotCenter[0], m_meshModel->cm.m_rotCenter[1],
		m_meshModel->cm.m_rotCenter[2]), maxScale, maxScale, maxScale);
	QMatrix4x4 adjustCircleTran2;
	adjustCircleTran2.translate(QVector3D(m_meshModel->cm.m_params[6], m_meshModel->cm.m_params[7], m_meshModel->cm.m_params[8]));
	QMatrix4x4 sumtran2 = adjustCircleTran2 * adjustCircleTran1;
	m_adjustAxisX->setTransform(sumtran2);
	m_adjustAxisY->setTransform(sumtran2);
	m_adjustAxisZ->setTransform(sumtran2);
	m_adjustOrigin->setTransform(sumtran2);
}


