/****************************************************************************
 * MeshLab                                                           o o     *
 * A versatile mesh processing toolbox                             o     o   *
 *                                                                _   O  _   *
 * Copyright(C) 2008                                                \/)\/    *
 * Visual Computing Lab                                            /\/|      *
 * ISTI - Italian National Research Council                           |      *
 *                                                                    \      *
 * All rights reserved.                                                      *
 *                                                                           *
 * This program is free software; you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation; either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)          *
 * for more details.                                                         *
 *                                                                           *
 ****************************************************************************/

#include <meshlab/glarea.h>
#include "edit_manualsupport.h"
#include <wrap/qt/gl_label.h>
#include <wrap/gui/trackball.h>
#include "wrap/gl/space.h"
#include "common/GeoAndShow/TransformPack.h"
#include "common/GeoAndShow/CHLine3D.h"
#include "common/GeoAndShow/CHBaseAlg.h"
#include "QPalette"
#include "edit_meshtransform_factory.h"

#include "common/GeoAndShow/CHSphere.h"
#include "common/GeoAndShow/CHCylinder.h"
#include "common/GeoAndShow/CHTrapezoidBody.h"
#include "common/GeoAndShow/CHTetrahedron.h"
#include "common/support/supportmeshfactory.h"
#include "common/support/supportdata.h"

using namespace vcg;


ManualSupportTool::ManualSupportTool()
{
    m_cuboidShow = CHCuboidPtr(new CHCuboid);
    m_cuboidShow->create(4, 4, 1);
    m_cuboidShow->setVisuable(false);

    //m_cuboidShow = CHSupportCuboidPtr(new CHSupportCuboid);
    //m_cuboidShow->create(4, 4, 1);
    //m_cuboidShow->setVisuable(false);

    //m_cuboidShow->updateToScene();//exe的场景还没有设置过来，这里调不起作用
}

bool ManualSupportTool::startEdit(MeshDocument& md, GLArea* gla, MLSceneGLSharedDataContext* scenedata)
{
    curScene = gla->m_scene;

    for (auto actionIt = transformActionsList.begin(); actionIt != transformActionsList.end(); actionIt++)
    {
        if ((*actionIt)->text() == QString("Support"))
        {
            (*actionIt)->setIcon(QIcon(":/images/fdm_manual_icon_s.png"));
            break;
        }
    }
    m_cuboidShow->updateToScene();

#if 0  //测试基本实体建模功能
    CHSpherePtr sp(new CHSphere);
    sp->create(QVector3D(100, 100, 100), 10);
    sp->updateToScene();

    CHCuboidPtr cub(new CHCuboid);
    cub->create(20, 30, 40);
    cub->updateToScene();

    CHCylinderPtr cyl(new CHCylinder);
    cyl->create(5, 10, 20);
    cyl->updateToScene();
    QMatrix4x4 tran1;
    tran1.translate(QVector3D(50, 0, 0));
    cyl->setTransform(tran1);

    CHTrapezoidBodyPtr trab(new CHTrapezoidBody);
    trab->create(QVector3D(0, 30, 30), QVector3D(0, 0, 0), 20, 10, 20, 20);
    trab->updateToScene();
    QMatrix4x4 tran2;
    tran2.translate(QVector3D(0, 100, 0));
    trab->setTransform(tran2);

    CHTetrahedronPtr tth(new CHTetrahedron);
    tth->create(QVector3D(10, 30, 0), QVector3D(0, 0, 0), QVector3D(-20, 5, 0), QVector3D(0, 5, 20));
    tth->updateToScene();
    QMatrix4x4 tran3;
    tran3.translate(QVector3D(0, -100, 0));
    tth->setTransform(tran3);

#endif

    if (curScene->m_pickCommand->m_selectedObjs.size() == 0)
    {
        return false;
    }

    m_editMeshModels = curScene->m_pickCommand->m_selectedObjs;

    colorPrintModel = (*m_editMeshModels.begin())->getColor();
    colorSupportModel = QColor(125, 125, 0);
    angleSupport = 89.99;

    m_paramUI = new CHModelManualSupportParamsSetUI();
    EditMeshTransformFactory::m_conInt->addWidgetToModelTransForm(m_paramUI, 5);
    connect(m_paramUI, SIGNAL(profileSizeChanged(float, float)), this, SLOT(receiveCuboidSize(float, float)));

    return true;
}

void ManualSupportTool::endEdit(MeshDocument& md, GLArea*, MLSceneGLSharedDataContext*)
{
    //只是隐藏掉，并不删除
    if (m_cuboidShow->getVisuable())
    {
        m_cuboidShow->setVisuable(false);
        curScene->refresh();
    }

    if (m_paramUI)
    {
        delete m_paramUI;
        m_paramUI = 0;
    }

    for (auto actionIt = transformActionsList.begin(); actionIt != transformActionsList.end(); actionIt++)
    {
        if ((*actionIt)->text() == QString("Support"))
        {
            (*actionIt)->setIcon(QIcon(":/images/fdm_manual_icon_e.png"));
            break;
        }
    }
}

void ManualSupportTool::decorate(MeshModel& meshmodel, GLArea* gla, QPainter* mypainter)
{

}


void ManualSupportTool::mousePressEvent(QMouseEvent* event, MeshModel& meshmodel, GLArea* gla)
{
    do {
        // 0、 点击在空白处
        if (!m_pickedModel) {
            break;
        }

        // 1、 切换选中，可能是多个 print模型中的一个，或 多个 support 模型中的一个
        if (m_pickedModelLock != m_pickedModel) {
            //  取消 高亮
            if (int type = superShowObj(m_pickedModelLock)) {
                //if(1 == type){ m_pickedModelLock->setColor(colorPrintModel); }
                if (2 == type) { m_pickedModelLock->setColor(colorSupportModel); }
                m_pickedModelLock->updateToScene();
                curScene->refresh();
            }

            //  设置 高亮
            if (int type = superShowObj(m_pickedModel)) {
                //if(1 == type){ m_pickedModel->setColor(QColor(colorPrintModel.red() + 50, colorPrintModel.green() + 50, colorPrintModel.blue() + 50)); }
                if (2 == type) { m_pickedModel->setColor(QColor(colorSupportModel.red() + 50, colorSupportModel.green() + 50, colorSupportModel.blue() + 50)); }
                m_pickedModel->updateToScene();
                curScene->refresh();
            }

            m_pickedModelLock = m_pickedModel;
            break;
        }

        // 2、 再次pick中 m_pickedModelLock == m_pickedModel == thePrintModel
        // 2.1、pick中 PrintModel， 则添加支撑
        if (auto thePrintModel = std::dynamic_pointer_cast<CH3DPrintModel>(m_pickedModel)) {
            if (!checkSupportAngle(m_result, angleSupport)) { break; } //  倾角测试 不通过

            //CHSupportMeshPtr copyObj;
            CHShowObjPtr copyObj;
            m_cuboidShow->copy(copyObj);
            if (copyObj == nullptr)
                return;
            copyObj->setColor(colorSupportModel);
            copyObj->updateToScene();

            //添加支撑到3d打印模型

            thePrintModel->addSupportMesh(std::dynamic_pointer_cast<CHMeshShowObj>(copyObj));
            //thePrintModel->addSupportMesh(copyObj);

            //这里需要发信号，触发切片按钮还原
            if (nullptr != curScene->m_doc)
            {
                emit curScene->m_doc->modelObjsStatusChanged();
            }

            //thePrintModel->m_supportMeshes.push_back(std::dynamic_pointer_cast<CHMeshShowObj>(copyObj));

            //测试， 手动生成支撑
            //        QList<CHShowObjPtr> objs = SupportMeshFactory::instance()->GenerateSupportMeshes(SupportData::instance()->GetSupportLines(getSupportPoint()));
            //        for (int i = 0; i < objs.size(); i++)
            //        {
            //            objs[i]->setColor(QColor(245, 145, 0));
            //            objs[i]->updateToScene();
            //            thePrintModel->m_supportMeshes.push_back(std::dynamic_pointer_cast<CHMeshShowObj>(objs[i]));
            //        }
            break;
        }


        // 2.2、 再次pick中 支撑对象，则删除
        //   TODO: 应该增加 对象的父子关系
        for (auto printModel : m_editMeshModels) {
            auto thePrintModel = std::dynamic_pointer_cast<CH3DPrintModel>(printModel);
            int index = thePrintModel->m_supportMeshes.indexOf(m_pickedModel);
            if (index >= 0) {
                thePrintModel->deleteSupportMesh(m_pickedModel);
                //这里需要发信号，触发切片按钮还原
                if (nullptr != curScene->m_doc)
                {
                    emit curScene->m_doc->modelObjsStatusChanged();
                }
                break;
            }
        }

    } while (false);

}

//获取到pick的三角形数据
SupportPoint ManualSupportTool::getSupportPoint()
{
    SupportPoint sptPoint;
    sptPoint.touchPoint = m_result.m_pointOnMesh.m_pt;
    sptPoint.normal = m_result.m_pointOnMesh.m_nor;

    auto pickedModel = std::dynamic_pointer_cast<CH3DPrintModel>(m_result.m_pickObj);
    MyTriangle& face = pickedModel->m_trians[m_result.m_pointOnMesh.m_faceIndex];
    sptPoint.face.push_back(pickedModel->m_vertices[face.m_index1]);
    sptPoint.face.push_back(pickedModel->m_vertices[face.m_index2]);
    sptPoint.face.push_back(pickedModel->m_vertices[face.m_index3]);

    return sptPoint;
}


void ManualSupportTool::mouseMoveEvent(QMouseEvent* event, MeshModel& meshmodel, GLArea* gla)
{
    //
    std::vector<PickResult> allResults;
    for (auto printModel : m_editMeshModels)
        //for (std::set<CHMeshShowObjPtr>::iterator it = m_editMeshModels.begin(); it != m_editMeshModels.end(); it++)
    {
        auto thePrintModel = std::dynamic_pointer_cast<CH3DPrintModel>(printModel);

        PickResult printResult;
        if (thePrintModel->pick(event->pos().x(), event->pos().y(), printResult))
        {
            allResults.push_back(printResult);
        }

        for (auto theSupportMedel : thePrintModel->m_supportMeshes) {
            PickResult supportResult;
            if (theSupportMedel->pick(event->pos().x(), event->pos().y(), supportResult))
            {
                allResults.push_back(supportResult);
            }
        }
    }

    auto showSupportTip = [this](const PickResult& pickPrintResult) {
        QMatrix4x4 tran1, tran2;
        tran1.scale(1, 1, pickPrintResult.m_pointOnMesh.m_pt[2]);
        tran2.translate(QVector3D(pickPrintResult.m_pointOnMesh.m_pt[0], pickPrintResult.m_pointOnMesh.m_pt[1], 0));
        m_cuboidShow->setTransform(tran2 * tran1);
        m_cuboidShow->setVisuable(true);
        curScene->refresh();
    };


    auto hideSupportTip = [this]() {
        if (m_cuboidShow->getVisuable())
        {
            m_cuboidShow->setVisuable(false);
            curScene->refresh();
        }
    };


    do {
        m_pickedModel = 0;
        hideSupportTip();

        if (allResults.size() <= 0) {
            break;
        }

        //pick到对象
        std::sort(allResults.begin(), allResults.end(), CHShowObj::pred1);
        m_result = allResults[0];

        auto pickedModel = std::dynamic_pointer_cast<CHMeshShowObj>(m_result.m_pickObj);
        m_pickedModel = pickedModel;

        int type = superShowObj(pickedModel);
        if (1 == type) { //  pick 的 是 PrintModel，
            //  m_pickedModelLock == m_pickedModel == thePrintModel
            if (m_pickedModelLock == m_pickedModel) {
                if (!checkSupportAngle(m_result, angleSupport)) { break; } //  倾角测试 不通过
                showSupportTip(m_result);       //  显示 支撑 提示
            }
        }
        if (2 == type) { //  pick 在 现有的支撑上
        }

    } while (false);
}



void ManualSupportTool::mouseReleaseEvent(QMouseEvent* event, MeshModel& meshmodel, GLArea* gla)
{


}

void ManualSupportTool::receiveCuboidSize(float lenth, float wide)
{
    if (m_cuboidShow)
    {
        m_cuboidShow->setDelete(true);
        m_cuboidShow->updateToScene();
    }

    //m_cuboidShow = CHSupportCuboidPtr(new CHSupportCuboid);
    m_cuboidShow = CHCuboidPtr(new CHCuboid);
    m_cuboidShow->create(lenth, wide, 1);
    m_cuboidShow->setVisuable(false);
    m_cuboidShow->updateToScene();
}

int ManualSupportTool::superShowObj(CHShowObjPtr obj)
{
    if (!obj) { return 0; }
    if (std::dynamic_pointer_cast<CH3DPrintModel>(obj)) { return 1; }
    //if(std::dynamic_pointer_cast<CHCuboid      >(obj)) {return 2;}
    return 2;
}



bool ManualSupportTool::checkSupportAngle(const PickResult& pickPrintResult, float angle)
{
    QVector3D normal = pickPrintResult.m_pointOnMesh.m_nor.normalized();
    float r = std::acos(QVector3D::dotProduct(normal, QVector3D(0, 0, -1)));
    float a = r * 180 / M_PI;
    return a <= angle;
}

