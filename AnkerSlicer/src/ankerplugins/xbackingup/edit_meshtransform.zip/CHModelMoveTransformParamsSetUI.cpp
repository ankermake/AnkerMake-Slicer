#include "CHModelMoveTransformParamsSetUI.h"
#include "QPushButton"
#include "QBoxLayout"
#include "QValidator"
#include <QSignalMapper>
#include <QSpacerItem>
#include "edit_meshtransform_factory.h"

#define MAXNUM 999999
#define MINNUM -999999

CHModelMoveTransformParamsSetUI::CHModelMoveTransformParamsSetUI(QWidget* parent)
    : BubbleWidget(parent)
{
    move(97, 350);
    setFixedSize(192, 205);
    setAutoFillBackground(true);
    QPalette pal = palette();
    pal.setColor(QPalette::Background, QColor(255, 255, 255, 255));
    setPalette(pal);

    QVBoxLayout* mainblaout = new QVBoxLayout(this);

    QFont font1;
    font1.setPixelSize(14);
    QLabel* moveLabel = new QLabel;
    moveLabel->setFont(font1);
    moveLabel->setText(tr("Move"));
    //moveLabel->setStyleSheet("QLabel{ \n\tfont: roboto;\n\twidth: 35px; \n\theight: 16px; \n\ttop: 362px; \n\tleft: 109px; \n\tcolor: #333333; \n }");

    m_resetButton = new QToolButton;
    m_resetButton->setIcon(QIcon(":/images/fdm_remakes_small_icon_n.png"));
    m_resetButton->setStyleSheet(QString::fromUtf8("QToolButton{\n"
        "   border: none;\n"
        "   background: transparent;\n"
        "   width: 13.4px;\n"
        "   height: 13.4px;\n"
        "   left: 260.3px;\n"
        "   top: 364.04px;\n"
        "}\n"));

    QHBoxLayout* hblaout1 = new QHBoxLayout;
    hblaout1->addWidget(moveLabel);
    hblaout1->addSpacing(125);
    hblaout1->addWidget(m_resetButton);
    hblaout1->setStretch(0, 35);
    hblaout1->setStretch(1, 125);
    hblaout1->setStretch(2, 13.4);
    mainblaout->addLayout(hblaout1);

    Line* line = new Line;
    line->setStyleSheet(QString::fromUtf8("QFrame{\n"
        "   width: 168px;\n"
        "   height: 1px;\n"
        "   top: 390px;\n"
        "   left: 109px;\n"
        "   color: #E7E7E9;\n"
        "}"));
    QHBoxLayout* hblaout2 = new QHBoxLayout;
    hblaout2->addWidget(line);
    mainblaout->addLayout(hblaout2);

    QLabel* xLogo = new QLabel;
    QPixmap xLogoPixmap(":/images/fdm_move_x_icon_u.png");
    xLogo->setPixmap(xLogoPixmap);
    xLogo->setScaledContents(true);
    xLogo->setStyleSheet(QString::fromUtf8("QLabel{\n"
        "   width: 14.9px;\n"
        "   height: 30px;\n"
        "   top: 403px;\n"
        "   left: 105px;\n"
        "   font-size: 14px;\n"
        "}"));
    QLabel* xlabel = new QLabel(tr("X"));
    xlabel->setStyleSheet("QLabel{\n\twidth: 6px;\n\theight: 16px;\n\ttop: 410px;\n\tleft: 139px;\n\tcolor: #E32525;\n}");
    m_xMove = new QDoubleSpinBox;
    QHBoxLayout* xhlayout = new QHBoxLayout;
    xhlayout->addWidget(xLogo);
    xhlayout->addWidget(xlabel);
    xhlayout->addWidget(m_xMove);
    xhlayout->setStretch(0, 15);
    xhlayout->setStretch(1, 6);
    xhlayout->setStretch(2, 120);
    mainblaout->addLayout(xhlayout);

    m_xMove->setButtonSymbols(QAbstractSpinBox::NoButtons);
    m_xMove->setAutoFillBackground(true);
    m_xMove->setSuffix("mm");
    m_xMove->setStyleSheet(QString::fromUtf8("QDoubleSpinBox{\n"
        "width: 120px;\n"
        "height: 30px;\n"
        "top: 445px;\n"
        "left: 157px;\n"
        "border: 1px solid #E7E7E9;\n"
        "border-radius:4px;\n"
        "font-size: 12px;\n"
        "\n"
        "}"));

    QLabel* yLogo = new QLabel;
    QPixmap yLogoPixmap(":/images/fdm_move_y_icon_u.png");
    yLogo->setPixmap(yLogoPixmap);
    yLogo->setScaledContents(true);
    yLogo->setStyleSheet(QString::fromUtf8("QLabel{\n"
        "   width: 14.9px;\n"
        "   height: 30px;\n"
        "   top: 445px;\n"
        "   left: 105px;\n"
        "   font-size: 14px;\n"
        "}"));
    QLabel* ylabel = new QLabel(tr("Y"));
    ylabel->setStyleSheet("QLabel{\n\twidth: 6px;\n\theight: 16px;\n\ttop: 595px;\n\tleft: 139px;\n\tcolor: #62D361;\n}");
    m_yMove = new QDoubleSpinBox();
    m_yMove->setButtonSymbols(QAbstractSpinBox::NoButtons);
    m_yMove->setAutoFillBackground(true);
    m_yMove->setSuffix("mm");
    m_yMove->setStyleSheet(QString::fromUtf8("QDoubleSpinBox{\n"
        "width: 120px;\n"
        "height: 30px;\n"
        "top: 445px;\n"
        "left: 157px;\n"
        "border: 1px solid #E7E7E9;\n"
        "border-radius:4px;\n"
        "font-size: 12px;\n"
        "\n"
        "}"));

    QHBoxLayout* yhlayout = new QHBoxLayout;
    yhlayout->addWidget(yLogo);
    yhlayout->addWidget(ylabel);
    yhlayout->addWidget(m_yMove);
    yhlayout->setStretch(0, 15);
    yhlayout->setStretch(1, 6);
    yhlayout->setStretch(2, 120);
    mainblaout->addLayout(yhlayout);

    QLabel* zLogo = new QLabel;
    QPixmap zLogoPixmap(":/images/fdm_move_z_icon_u.png");
    zLogo->setPixmap(zLogoPixmap);
    zLogo->setScaledContents(true);
    zLogo->setStyleSheet(QString::fromUtf8("QLabel{\n"
        "   width: 14.9px;\n"
        "   height: 30px;\n"
        "   top: 487px;\n"
        "   left: 105px;\n"
        "   font-size: 14px;\n"
        "}"));
    QLabel* zlabel = new QLabel(tr("Z"));
    zlabel->setStyleSheet("QLabel{\n\twidth: 6px;\n\theight: 16px;\n\ttop: 637px;\n\tleft: 139px;\n\tcolor: #0167FF;\n}");
    m_zMove = new QDoubleSpinBox;
    m_zMove->setButtonSymbols(QAbstractSpinBox::NoButtons);
    m_zMove->setSuffix("mm");
    m_zMove->setAutoFillBackground(true);
    m_zMove->setStyleSheet(QString::fromUtf8("QDoubleSpinBox{\n"
        "width: 120px;\n"
        "height: 30px;\n"
        "top: 487px;\n"
        "left: 157px;\n"
        "border: 1px solid #E7E7E9;\n"
        "border-radius:4px;\n"
        "font-size: 12px;\n"
        "}"));

    QHBoxLayout* zhlayout = new QHBoxLayout;
    zhlayout->addWidget(zLogo);
    zhlayout->addWidget(zlabel);
    zhlayout->addWidget(m_zMove);
    zhlayout->setStretch(0, 15);
    zhlayout->setStretch(1, 6);
    zhlayout->setStretch(2, 120);
    mainblaout->addLayout(zhlayout);

    QLabel* keepLabel = new QLabel;
    keepLabel->setText("Keeping Lay On Panel");
    keepLabel->setStyleSheet(QString::fromUtf8("QLabel{\n"
        "   width: 116px;\n"
        "   height: 14px;\n"
        "   top: 529px;\n"
        "   left: 109px;\n"
        "   font: roboto;\n"
        "   font-size: 12px;\n"
        "}"));
    m_lockCheck = new SwitchButton;
    m_lockCheck->setFixedWidth(26);
    m_lockCheck->setFixedHeight(14);
    QHBoxLayout* hblaout3 = new QHBoxLayout;
    hblaout3->addWidget(keepLabel);
    hblaout3->addWidget(m_lockCheck, Qt::AlignRight);
    hblaout3->setStretch(0, 116);
    hblaout3->setStretch(1, 26);
    mainblaout->addLayout(hblaout3);

    mainblaout->setStretch(0, 20);
    mainblaout->setStretch(1, 1);
    mainblaout->setStretch(2, 30);
    mainblaout->setStretch(3, 30);
    mainblaout->setStretch(4, 30);
    mainblaout->setStretch(5, 14);
    m_allLineEdits.push_back(m_xMove);
    m_allLineEdits.push_back(m_yMove);
    m_allLineEdits.push_back(m_zMove);

    for (int i = 0; i < m_allLineEdits.size(); i++)
    {
        m_allLineEdits[i]->setDecimals(2);
        m_allLineEdits[i]->setMaximum(MAXNUM);
        m_allLineEdits[i]->setMinimum(MINNUM);
        connect(m_allLineEdits[i], SIGNAL(valueChanged(double)), this, SLOT(submit(double)));
    }
    m_lockCheck->setCheckState(m_lockToPrintPlatform);
    connect(m_lockCheck, SIGNAL(stateChanged(bool)), this, SLOT(setLock(bool)));
    //connect(m_resetButton, SIGNAL(clicked()), this, SLOT(reset()));
}

CHModelMoveTransformParamsSetUI::~CHModelMoveTransformParamsSetUI()
{

}

void CHModelMoveTransformParamsSetUI::disableLineEdit()
{
    m_xMove->setEnabled(false);
    m_yMove->setEnabled(false);
    m_zMove->setEnabled(false);
}

void CHModelMoveTransformParamsSetUI::receiveParams(vector<float> params)
{
    for (int i = 0; i < m_allLineEdits.size(); i++)
    {
        m_allLineEdits[i]->setValue(params[i]);
    }
}

void CHModelMoveTransformParamsSetUI::submit()
{
    vector<float> params(3);
    for (int i = 0; i < m_allLineEdits.size(); i++)
    {
        params[i] = m_allLineEdits[i]->value();
    }

    receiveParams(params);

    emit sendParams(params);
}

void CHModelMoveTransformParamsSetUI::submit(double)
{
    vector<float> params(3);
    for (int i = 0; i < m_allLineEdits.size(); i++)
    {
        params[i] = m_allLineEdits[i]->value();
    }

    receiveParams(params);

    emit sendParams(params);
}

void CHModelMoveTransformParamsSetUI::reset()
{
    for (int i = 0; i < m_allLineEdits.size(); i++)
    {
        m_allLineEdits[i]->setValue(0.00);
    }
    vector<float> params(3);
    params[0] = 0;
    params[1] = 0;
    params[2] = 0;
    emit sendParams(params);
}

void CHModelMoveTransformParamsSetUI::setLock()
{
    if (m_lockCheck->checkState())
    {
        m_lockToPrintPlatform = true;
    }
    else
    {
        m_lockToPrintPlatform = false;
    }
    submit();
}

void CHModelMoveTransformParamsSetUI::setLock(bool checked)
{
    m_lockToPrintPlatform = checked;
    submit(0.0);
}





