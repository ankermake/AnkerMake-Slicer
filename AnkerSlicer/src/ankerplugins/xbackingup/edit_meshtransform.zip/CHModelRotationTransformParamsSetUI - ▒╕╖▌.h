/*
*?????????????
*?????
*???2021?11?16?
*/


#ifndef CHModelRotationTransformParamsSetUI_H
#define CHModelRotationTransformParamsSetUI_H


#include <QDialog>
#include <QGroupBox>
#include <QScrollArea>
#include "QLabel"
#include "QLineEdit"
#include <vector>
#include "QPushButton"


using namespace std;

class CHModelRotationTransformParamsSetUI : public QWidget
{
    Q_OBJECT

public:
	CHModelRotationTransformParamsSetUI(QWidget *parent = Q_NULLPTR);
	~CHModelRotationTransformParamsSetUI() ;
	

	public
		Q_SLOTS:
	void receiveParams(vector<float> params);
	void submit();
	void reset();

Q_SIGNALS:
	void sendParams(vector<float> params);
	

private:
	QGroupBox * createParamsSetUI();
	void adjustSingleAngle(float& angle);

private:
		
	QLineEdit* m_xRot;
	QLineEdit* m_yRot;
	QLineEdit* m_zRot;

	QPushButton* m_resetButton;

	std::vector<QLineEdit*> m_allLineEdits;

};
#endif
