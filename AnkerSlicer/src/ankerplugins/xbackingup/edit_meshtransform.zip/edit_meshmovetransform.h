/****************************************************************************
 * MeshLab                                                           o o     *
 * A versatile mesh processing toolbox                             o     o   *
 *                                                                _   O  _   *
 * Copyright(C) 2008                                                \/)\/    *
 * Visual Computing Lab                                            /\/|      *
 * ISTI - Italian National Research Council                           |      *
 *                                                                    \      *
 * All rights reserved.                                                      *
 *                                                                           *
 * This program is free software; you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation; either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)          *
 * for more details.                                                         *
 *                                                                           *
 ****************************************************************************/
#ifndef EditMeshMoveTransformTool_H
#define EditMeshMoveTransformTool_H

#include <QObject>
#include <QStringList>
#include <QList>

#include <common/plugins/interfaces/edit_plugin.h>
#include "common/GeoAndShow/CHLineSegment3DShowObj.h"
#include "common/GeoAndShow/CHPointShowObj.h"
#include "CHModelMoveTransformParamsSetUI.h"
#include "common/GeoAndShow/CHAssembly.h"
#include "common/GeoAndShow/CHCone.h"


DEF_PTR(CHAxisWithArrow)
class CHAxisWithArrow :public CHAssembly
{
public:
    CHAxisWithArrow();
    virtual ~CHAxisWithArrow();

public:
    void create(QVector3D center, QVector3D axisDir, float axisLenth, float rad, float height);

    virtual bool pick(int pixelX, int pixelY, PickResult& result, int pickTol = 10);//?????????m_axis?pick?????


public:
    CHLineSegment3DShowObjPtr m_axis;
    CHConePtr m_arrow;

};

class EditMeshMoveTransformTool : public QObject, public EditTool
{
    Q_OBJECT

public:

    EditMeshMoveTransformTool();
    virtual ~EditMeshMoveTransformTool() {}
    virtual bool startEdit(MeshDocument& md, GLArea* /*parent*/, MLSceneGLSharedDataContext* /*cont*/);
    virtual void endEdit(MeshDocument& md, GLArea* /*parent*/, MLSceneGLSharedDataContext* /*cont*/);
    virtual void decorate(MeshModel&, GLArea*, QPainter*);
    virtual void mousePressEvent(QMouseEvent*, MeshModel&, GLArea*);
    virtual void mouseMoveEvent(QMouseEvent*, MeshModel&, GLArea*);
    virtual void mouseReleaseEvent(QMouseEvent* event, MeshModel&, GLArea*);


    public
Q_SLOTS:
    void receiveParams(vector<float> params);
    void resetBtnClicked();
    void resetSelectedObjsClicked();
Q_SIGNALS:
    void sendParams(vector<float> params);

private:
    //刷新平移调节框架
    void refreshMoveFrame();

    void submitToUI();


private:
    CHModelMoveTransformParamsSetUI* m_paramUI;
    std::set<CHMeshShowObjPtr> m_editMeshModels;
    CHMeshShowObjPtr m_firstMesh;//???????????????
    QVector3D m_operationCenter;

    CHAxisWithArrowPtr m_adjustAxisX;
    CHAxisWithArrowPtr m_adjustAxisY;
    CHAxisWithArrowPtr m_adjustAxisZ;
    CHPointShowObjPtr m_adjustOrigin;//调节原点
    std::vector<CHShowObjPtr> m_allPickObjs;

    QVector3D m_pickCoord;
    CHShowObjPtr m_pickedObj;
    int m_stepFlag;//同cmd的m_step，为了移植的方便，这里自己定义
    std::vector<std::vector<float>> m_values;//鼠标按下一刻保存的量
    std::vector<std::vector<float>> m_initValues;//初始平移量状态保存，用来做重置

    //为了解决在mouse事件中获取的模型视图矩阵是单位阵（glarea渲染框架调了glLoadIdentity）而设置
    GLdouble mm[16];
    GLdouble pm[16];
    GLint vp[4];

};

#endif
