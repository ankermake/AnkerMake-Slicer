/****************************************************************************
 * MeshLab                                                           o o     *
 * A versatile mesh processing toolbox                             o     o   *
 *                                                                _   O  _   *
 * Copyright(C) 2008                                                \/)\/    *
 * Visual Computing Lab                                            /\/|      *
 * ISTI - Italian National Research Council                           |      *
 *                                                                    \      *
 * All rights reserved.                                                      *
 *                                                                           *
 * This program is free software; you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation; either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)          *
 * for more details.                                                         *
 *                                                                           *
 ****************************************************************************/

#include <meshlab/glarea.h>
#include "edit_meshzoomtransform.h"
#include <wrap/qt/gl_label.h>
#include <wrap/gui/trackball.h>
#include "wrap/gl/space.h"
#include "common/GeoAndShow/TransformPack.h"
#include "common/GeoAndShow/CHLine3D.h"
#include "common/GeoAndShow/CHBaseAlg.h"
#include <minwindef.h>
#include "edit_meshtransform_factory.h"
#include "BoxBorder.h"

using namespace vcg;


EditMeshZoomTransformTool::EditMeshZoomTransformTool()
{
    m_stepFlag = 0;
    m_operateMoveZ = 0;

    originMove[0] = originMove[1] = originMove[2] = 0.0;
}

bool EditMeshZoomTransformTool::startEdit(MeshDocument& md, GLArea* gla, MLSceneGLSharedDataContext* scenedata)
{
    curScene = gla->m_scene;
    if (curScene->m_pickCommand->m_selectedObjs.size() == 0)
    {
        return false;
    }

    for (auto actionIt = transformActionsList.begin(); actionIt != transformActionsList.end(); actionIt++)
    {
        if ((*actionIt)->text() == QString("Zoom"))
        {
            (*actionIt)->setIcon(QIcon(":/images/fdm_scale_icon_s.png"));
            break;
        }
    }

    m_editMeshModels = curScene->m_pickCommand->m_selectedObjs;
    m_firstMesh = *m_editMeshModels.begin();

    m_stepFlag = 0;
    m_pickedObj = 0;
    m_operateMoveZ = 0;

    m_paramUI = new CHModelZoomTransformParamsSetUI();
    //if (m_editMeshModels.size() > 1)
    {
        m_lockScaleRatio = true;//多模型时强制锁定等比例缩放
        m_paramUI->m_lockCheckBox->setCheckState(false);
    }
    EditMeshTransformFactory::m_conInt->addWidgetToModelTransForm(m_paramUI, 3);
    connect(this, SIGNAL(sendParams(vector<float>)), m_paramUI, SLOT(receiveParams(vector<float>)));
    connect(m_paramUI, SIGNAL(sendParams(vector<float>)), this, SLOT(receiveParams(vector<float>)));
    connect(this, SIGNAL(sendBoxSizeParam(vector<float>)), m_paramUI, SLOT(receiveCurrentCenter(vector<float>)));
    connect(m_paramUI->m_scaleToFitButton, SIGNAL(clicked(bool)), this, SLOT(scaleToFitClicked(bool)));
    connect(m_paramUI->m_resetButton, SIGNAL(clicked()), this, SLOT(resetBtnClicked()));

    disconnect(getGlobalPick().get(), SIGNAL(resetSeletedObjsSig()), getGlobalPick().get(), SLOT(resetSelectedObjs()));
    connect(getGlobalPick().get(), SIGNAL(resetSeletedObjsSig()), this, SLOT(resetSelectedObjsClicked()));

    //初始化
    for (std::set<CHMeshShowObjPtr>::iterator it = m_editMeshModels.begin(); it != m_editMeshModels.end(); it++)
    {
        EditMeshTransformFactory::initMeshModelEulerParams(*it);
    }
    m_values.resize(m_editMeshModels.size());
    m_initValues.resize(m_editMeshModels.size());
    int p = 0;
    for (std::set<CHMeshShowObjPtr>::iterator it = m_editMeshModels.begin(); it != m_editMeshModels.end(); it++)
    {
        m_values[p].resize(6);
        m_initValues[p].resize(6);
        m_initValues[p][0] = (*it)->m_params[0];
        m_initValues[p][1] = (*it)->m_params[1];
        m_initValues[p][2] = (*it)->m_params[2];
        m_initValues[p][3] = (*it)->m_params[6];
        m_initValues[p][4] = (*it)->m_params[7];
        m_initValues[p][5] = (*it)->m_params[8];
        p++;
    }

    //多模型时计算操作中心
    CHAABB3D aabb;
    //if (m_editMeshModels.size() > 1)
    {
        for (std::set<CHMeshShowObjPtr>::iterator it = m_editMeshModels.begin(); it != m_editMeshModels.end(); it++)
        {
            aabb.add((*it)->calSimilarAABB());
        }
        m_operationCenter = aabb.getCenterPoint();
    }
    m_initBox.clear();
    m_initBox.push_back(aabb.getLenX());
    m_initBox.push_back(aabb.getLenY());
    m_initBox.push_back(aabb.getLenZ());
    /*else
    {
        aabb = m_firstMesh->getBaseAABB();//这里的逻辑与平移旋转不一样，对于缩放：单模型是本地坐标系，多模型是世界坐标系
        m_operationCenter = m_firstMesh->m_rotCenter;
    }*/
    emit sendBoxSizeParam(m_initBox);
    submitToUI();

    //创建缩放调节框架
    //QVector3D originCreateCenter(m_meshModel->m_rotCenter[0], m_meshModel->m_rotCenter[1], m_meshModel->m_rotCenter[2]);
    QVector3D originCreateCenter = m_operationCenter;
    QColor xcolor(125, 0, 0);
    QColor ycolor(0, 125, 0);
    QColor zcolor(0, 0, 125);
    double marksize = 4;
    double adjustsize = 8;
    m_adjustAxisX = CHLineSegment3DShowObjPtr(new CHLineSegment3DShowObj);
    m_adjustAxisX->create(originCreateCenter, originCreateCenter + QVector3D(aabb.getLenX() * 0.5, 0, 0));
    m_adjustAxisX->setColor(xcolor);
    m_adjustAxisY = CHLineSegment3DShowObjPtr(new CHLineSegment3DShowObj);
    m_adjustAxisY->create(originCreateCenter, originCreateCenter + QVector3D(0, aabb.getLenY() * 0.5, 0));
    m_adjustAxisY->setColor(ycolor);
    m_adjustAxisZ = CHLineSegment3DShowObjPtr(new CHLineSegment3DShowObj);
    m_adjustAxisZ->create(originCreateCenter, originCreateCenter + QVector3D(0, 0, aabb.getLenZ() * 0.5));
    m_adjustAxisZ->setColor(zcolor);

    m_markXPoint = CHPointShowObjPtr(new CHPointShowObj);
    m_markXPoint->create(m_adjustAxisX->m_et);
    m_markXPoint->setColor(QColor(0, 0, 0));
    m_markXPoint->setSize(marksize);
    m_markYPoint = CHPointShowObjPtr(new CHPointShowObj);
    m_markYPoint->create(m_adjustAxisY->m_et);
    m_markYPoint->setColor(QColor(0, 0, 0));
    m_markYPoint->setSize(marksize);
    m_markZPoint = CHPointShowObjPtr(new CHPointShowObj);
    m_markZPoint->create(m_adjustAxisZ->m_et);
    m_markZPoint->setColor(QColor(0, 0, 0));
    m_markZPoint->setSize(marksize);

    m_adjustXPoint = CHPointShowObjPtr(new CHPointShowObj);
    m_adjustXPoint->create(m_adjustAxisX->m_et);
    m_adjustXPoint->setColor(xcolor);
    m_adjustXPoint->setSize(adjustsize);
    m_adjustYPoint = CHPointShowObjPtr(new CHPointShowObj);
    m_adjustYPoint->create(m_adjustAxisY->m_et);
    m_adjustYPoint->setColor(ycolor);
    m_adjustYPoint->setSize(adjustsize);
    m_adjustZPoint = CHPointShowObjPtr(new CHPointShowObj);
    m_adjustZPoint->create(m_adjustAxisZ->m_et);
    m_adjustZPoint->setColor(zcolor);
    m_adjustZPoint->setSize(adjustsize);
    m_adjustXYZPoint = CHPointShowObjPtr(new CHPointShowObj);
    m_adjustXYZPoint->create(m_adjustAxisX->m_et + m_adjustAxisY->m_et - originCreateCenter);
    m_adjustXYZPoint->setColor(QColor(125, 0, 125));
    m_adjustXYZPoint->setSize(adjustsize);

    m_middleshowcurve1 = CHLineSegment3DShowObjPtr(new CHLineSegment3DShowObj);
    m_middleshowcurve1->create(m_adjustAxisY->m_et, m_adjustAxisX->m_et + m_adjustAxisY->m_et - originCreateCenter);
    m_middleshowcurve1->setColor(xcolor);
    m_middleshowcurve2 = CHLineSegment3DShowObjPtr(new CHLineSegment3DShowObj);
    m_middleshowcurve2->create(m_adjustAxisX->m_et, m_adjustAxisX->m_et + m_adjustAxisY->m_et - originCreateCenter);
    m_middleshowcurve2->setColor(ycolor);

    //刷新缩放调节框架
    refreshScaleFrame();

    m_allPickObjs.push_back(m_adjustXPoint);
    m_allPickObjs.push_back(m_adjustYPoint);
    m_allPickObjs.push_back(m_adjustZPoint);
    m_allPickObjs.push_back(m_adjustXYZPoint);

    m_allShowObjs.push_back(m_adjustAxisX);
    m_allShowObjs.push_back(m_adjustAxisY);
    m_allShowObjs.push_back(m_adjustAxisZ);
    m_allShowObjs.push_back(m_middleshowcurve1);
    m_allShowObjs.push_back(m_middleshowcurve2);
    m_allShowObjs.push_back(m_markXPoint);
    m_allShowObjs.push_back(m_markYPoint);
    m_allShowObjs.push_back(m_markZPoint);
    m_allShowObjs.push_back(m_adjustXPoint);
    m_allShowObjs.push_back(m_adjustYPoint);
    m_allShowObjs.push_back(m_adjustZPoint);
    m_allShowObjs.push_back(m_adjustXYZPoint);

    for (int i = 0; i < m_allShowObjs.size(); i++)
    {
        m_allShowObjs[i]->setLightTest(false);
        m_allShowObjs[i]->updateToScene();
    }

    return true;
}

void EditMeshZoomTransformTool::endEdit(MeshDocument& md, GLArea*, MLSceneGLSharedDataContext*)
{
    if (m_paramUI)
    {
        delete m_paramUI;
        m_paramUI = 0;
    }
    for (int i = 0; i < m_allShowObjs.size(); i++)
    {
        m_allShowObjs[i]->setDelete(true);
        m_allShowObjs[i]->updateToScene();
    }

    m_allPickObjs.clear();
    m_allShowObjs.clear();

    for (auto actionIt = transformActionsList.begin(); actionIt != transformActionsList.end(); actionIt++)
    {
        if ((*actionIt)->text() == QString("Zoom"))
        {
            (*actionIt)->setIcon(QIcon(":/images/fdm_scale_icon_e.png"));
            break;
        }
    }

    disconnect(getGlobalPick().get(), SIGNAL(resetSeletedObjsSig()), this, SLOT(resetSelectedObjsClicked()));
    connect(getGlobalPick().get(), SIGNAL(resetSeletedObjsSig()), getGlobalPick().get(), SLOT(resetSelectedObjs()));
}

void EditMeshZoomTransformTool::scaleToFitClicked(bool clicked)
{
    vector<float> params(3);
    if (clicked)
    {
        CHAABB3D aabb;//当前总的真实包围盒
        for (std::set<CHMeshShowObjPtr>::iterator it = m_editMeshModels.begin(); it != m_editMeshModels.end(); it++)
        {
            aabb.add((*it)->calRealAABB());
        }

        CHAABB3D platformAabb = getDoc()->m_machineBox->getBaseAABB();
        float ratio = getRadio(aabb, platformAabb);


        params[0] = ratio / m_initValues[0][0];
        params[1] = ratio / m_initValues[0][1];
        params[2] = ratio / m_initValues[0][2];
    }
    else
    {
        params[0] = m_initValues[0][0];
        params[1] = m_initValues[0][1];
        params[2] = m_initValues[0][2];
    }

    emit sendParams(params);
}

void EditMeshZoomTransformTool::resetSelectedObjsClicked()
{
    getGlobalPick()->resetSelectedObjs();
    submitToUI();
}

void EditMeshZoomTransformTool::resetBtnClicked()
{
    auto bIt = getGlobalPick()->m_selectedObjs.begin();
    auto eIt = getGlobalPick()->m_selectedObjs.end();
    for (bIt; bIt != eIt; bIt++)
    {
        std::dynamic_pointer_cast<CH3DPrintModel>(*bIt)->resetZoom();
    }
    submitToUI();
}

float EditMeshZoomTransformTool::getRadio(const CHAABB3D& aabb, const CHAABB3D& platformAabb)
{
    float radio = 0.0;
    float radioX = 0.0;
    float radioY = 0.0;
    float radioZ = 0.0;

    if (aabb.getLenX() < platformAabb.getLenX() &&
        aabb.getLenY() < platformAabb.getLenY() &&
        aabb.getLenZ() < platformAabb.getLenZ())
    {
        radioX = 2 * aabb.getCenterPoint().x() / aabb.getLenX();
        radioX = (radioX < (2 * (platformAabb.m_Xmax - aabb.getCenterPoint().x()) / aabb.getLenX()) ? radioX :
            (2 * (platformAabb.m_Xmax - aabb.getCenterPoint().x()) / aabb.getLenX()));

        radioY = 2 * aabb.getCenterPoint().y() / aabb.getLenY();
        radioY = (radioY < (2 * (platformAabb.m_Ymax - aabb.getCenterPoint().y()) / aabb.getLenY()) ? radioY :
            (2 * (platformAabb.m_Ymax - aabb.getCenterPoint().y()) / aabb.getLenY()));

        radioZ = 2 * (platformAabb.m_Zmax - aabb.getCenterPoint().z()) / aabb.getLenZ();

        radio = (radio = (radioX < radioY ? radioX : radioY)) < radioZ ? radio : radioZ; //取放大的最小因子
        radio -= 0.1;
    }
    else
    {
        radio = 1.0;
    }
    return radio;
}


void EditMeshZoomTransformTool::decorate(MeshModel& meshmodel, GLArea* gla, QPainter* mypainter)
{
    return;
    //GLdouble mm[16], pm[16]; GLint vp[4];
    glGetDoublev(GL_MODELVIEW_MATRIX, mm);
    glGetDoublev(GL_PROJECTION_MATRIX, pm);
    glGetIntegerv(GL_VIEWPORT, vp);

    glDisable(GL_DEPTH_TEST);
    for (int i = 0; i < m_allShowObjs.size(); i++)
    {
        if (m_allShowObjs[i] && m_allShowObjs[i]->getVisuable())
        {
            //m_allShowObjs[i]->draw();
        }
    }
    glEnable(GL_DEPTH_TEST);

}

void EditMeshZoomTransformTool::mousePressEvent(QMouseEvent* event, MeshModel&, GLArea* gla)
{
    //BoxBorder::getInstancePtr()->setParam(gla, *m_meshModel);
    if (event->button() == Qt::LeftButton && m_pickedObj)
    {
        m_stepFlag = 1;
        int i = 0;
        for (std::set<CHMeshShowObjPtr>::iterator it = m_editMeshModels.begin(); it != m_editMeshModels.end(); it++)
        {
            m_values[i][0] = (*it)->m_params[0];
            m_values[i][1] = (*it)->m_params[1];
            m_values[i][2] = (*it)->m_params[2];
            m_values[i][3] = (*it)->m_params[6];
            m_values[i][4] = (*it)->m_params[7];
            m_values[i][5] = (*it)->m_params[8];

            i++;
        }
    }
}

void EditMeshZoomTransformTool::mouseMoveEvent(QMouseEvent* event, MeshModel& meshmodel, GLArea* gla)
{
    if (m_stepFlag == 0)
    {
        //计算pick对象
        CHShowObjPtr curPickedObj = 0;
        double pickTol = 10;
        vector<PickResult> curPickerObjs;
        for (int i = 0; i < m_allPickObjs.size(); i++)
        {
            PickResult result;
            if (m_allPickObjs[i]->pick(event->pos().x(), event->pos().y(), result, pickTol))
            {
                curPickerObjs.push_back(result);
            }
        }
        int num = (int)curPickerObjs.size();
        if (num == 1)
        {
            curPickedObj = curPickerObjs[0].m_pickObj;

            m_pickCoord = curPickerObjs[0].m_ptOnObj;//免得鼠标按下的时候重新计算
        }
        else if (num > 1)
        {
            std::sort(curPickerObjs.begin(), curPickerObjs.end(), CHShowObj::pred1);//深度排序
            double ttol = 0.001;
            vector<PickResult> minDeepObjs;//深度一样的可能有好几个
            minDeepObjs.push_back(curPickerObjs[0]);
            for (int i = 1; i < num; i++)
            {
                if (fabs(curPickerObjs[i].m_deep - curPickerObjs[0].m_deep) < ttol)
                {
                    minDeepObjs.push_back(curPickerObjs[i]);
                }
            }

            std::sort(minDeepObjs.begin(), minDeepObjs.end(), CHShowObj::pred2);//pick优先级排序
            curPickedObj = minDeepObjs[0].m_pickObj;

            m_pickCoord = minDeepObjs[0].m_ptOnObj;//免得鼠标按下的时候重新计算
        }

        if (m_pickedObj != curPickedObj)//只有与上次的结果不一样才会去刷新界面
        {
            for (int i = 0; i < m_allPickObjs.size(); i++)
            {
                m_allPickObjs[i]->setStatus(general);
            }
            m_pickedObj = curPickedObj;
            if (m_pickedObj)
            {
                m_pickedObj->setStatus(canPicked);
            }
            curScene->refresh();
        }
    }
    else if (m_stepFlag == 1) //开始缩放操作
    {
        QVector3D np, fp;
        curScene->getCurNearFarPoint(event->pos().x(), event->pos().y(), np, fp);
        CHLine3DPtr ray(new CHLine3D);
        ray->create(np, fp);

        //通过坐标轴计算坐标原点（鼠标按下时的中心点）
        QVector3D origin = TransformPack::pRot(m_adjustAxisX->getTransform(), m_adjustAxisX->m_st);

        //可以近平面远平面建立世界坐标空间射线，与真实坐标轴求极值计算，也可以仿照pick映射到像素空间计算
        CHLine3DPtr line(new CHLine3D);
        int index = 0;
        if (m_pickedObj == m_adjustXPoint)
        {
            line->create(origin, TransformPack::pRot(m_markXPoint->getTransform(), m_markXPoint->m_coord));
            index = 0;
        }
        else if (m_pickedObj == m_adjustYPoint)
        {
            line->create(origin, TransformPack::pRot(m_markYPoint->getTransform(), m_markYPoint->m_coord));
            index = 1;
        }
        else if (m_pickedObj == m_adjustZPoint)
        {
            line->create(origin, TransformPack::pRot(m_markZPoint->getTransform(), m_markZPoint->m_coord));
            index = 2;
        }
        else//同比调节
        {
            line->create(origin, m_pickCoord);
            index = 3;
        }
        //line->create(origin, m_pickCoord);
        LineLineExtremeResult result;
        CHBaseAlg::instance()->extremeBetweenLineAndLine(line, ray, result);
        double minRatio = 0.05;
        if (result.m_u1 < minRatio)//不跑到反方向
        {
            result.m_u1 = minRatio;
        }
        else if (fabs(result.m_u1 - 1) < minRatio)
        {
            result.m_u1 = 1;
        }

        /*if (m_editMeshModels.size() == 1)
        {
            if (index == 3)//同比调节
            {
                m_firstMesh->m_params[0] = m_values[0][0] * result.m_u1;
                m_firstMesh->m_params[1] = m_values[0][1] * result.m_u1;
                m_firstMesh->m_params[2] = m_values[0][2] * result.m_u1;
            }
            else
            {
                if (m_firstMesh->m_params[index] > 0)//原来是什么正负号现在应该就是什么正负号
                {
                    m_firstMesh->m_params[index] = result.m_u1;
                }
                else
                {
                    m_firstMesh->m_params[index] = -result.m_u1;
                }

                if (m_lockScaleRatio)
                {
                    for (int p = 0; p < 3; p++)
                    {
                        if (p != index)
                        {
                            m_firstMesh->m_params[p] = m_values[0][p] / m_values[0][index] * m_firstMesh->m_params[index];
                        }
                    }
                }
            }
        }
        else  */
        {
            int i = 0;
            for (std::set<CHMeshShowObjPtr>::iterator it = m_editMeshModels.begin(); it != m_editMeshModels.end(); it++)
            {
                //之所以这里区分，是因为构造线段采用的不同策略（为了判断吸附的方便）
                if (index == 3)
                {
                    (*it)->m_params[0] = m_values[i][0] * result.m_u1;
                    (*it)->m_params[1] = m_values[i][1] * result.m_u1;
                    (*it)->m_params[2] = m_values[i][2] * result.m_u1;
                }
                else
                {
                    (*it)->m_params[0] = m_initValues[i][0] * result.m_u1;
                    (*it)->m_params[1] = m_initValues[i][1] * result.m_u1;
                    (*it)->m_params[2] = m_initValues[i][2] * result.m_u1;
                }

                //还要计算位移效果
                QVector3D vecDir = (*it)->m_rotCenter + QVector3D(m_initValues[i][3], m_initValues[i][4], m_initValues[i][5]) - m_operationCenter;
                QVector3D newCenter = vecDir * fabs((*it)->m_params[0] / m_initValues[i][0]) + m_operationCenter + QVector3D(0, 0, m_operateMoveZ);
                (*it)->m_params[6] = newCenter[0] - (*it)->m_rotCenter[0];
                (*it)->m_params[7] = newCenter[1] - (*it)->m_rotCenter[1];
                (*it)->m_params[8] = newCenter[2] - (*it)->m_rotCenter[2];



                //还要计算位移效果，以鼠标按下时刻起算
                /*QVector3D currentMeshCenter = QVector3D((*it)->m_rotCenter[0], (*it)->m_rotCenter[1],
                    (*it)->m_rotCenter[2]) + QVector3D(m_values[i][3], m_values[i][4], m_values[i][5]);
                QVector3D newCenter = TransformPack::pRot(TransformPack::scale(origin, fabs((*it)->m_params[0] / m_initValues[i][0]),
                    fabs((*it)->m_params[1] / m_initValues[i][1]), fabs((*it)->m_params[2] / m_initValues[i][2])), currentMeshCenter);
                QVector3D move = newCenter - QVector3D((*it)->m_rotCenter[0], (*it)->m_rotCenter[1], (*it)->m_rotCenter[2]);
                (*it)->m_params[6] = move[0];
                (*it)->m_params[7] = move[1];
                (*it)->m_params[8] = move[2];*/

                i++;
            }
        }

        submitToUI();

        for (std::set<CHMeshShowObjPtr>::iterator it = m_editMeshModels.begin(); it != m_editMeshModels.end(); it++)
        {
            //计算变换矩阵
            QMatrix4x4 sumtran1 = CHBaseAlg::instance()->calTransformFromParams(QVector3D((*it)->m_rotCenter[0],
                (*it)->m_rotCenter[1], (*it)->m_rotCenter[2]), (*it)->m_params);

            //刷新模型
            (*it)->setTransform(sumtran1);
        }

        //刷新平移调节框架
        refreshScaleFrame();

        curScene->refresh();
    }
}

void EditMeshZoomTransformTool::mouseReleaseEvent(QMouseEvent* event, MeshModel& meshmodel, GLArea* gla)
{
    if (event->button() == Qt::LeftButton)
    {
        //当前不管锁定打印平台否，都得计算真实包围盒，因为视图变换刷新会实时应用pick物体的包围盒
        CHAABB3D aabb;//当前总的真实包围盒
        for (std::set<CHMeshShowObjPtr>::iterator it = m_editMeshModels.begin(); it != m_editMeshModels.end(); it++)
        {
            aabb.add((*it)->calRealAABB());
        }

        //锁定z=0的打印平台
        if (m_lockToPrintPlatform)
        {
            //CHAABB3D aabb;//当前总的真实包围盒
            //for (std::set<CHMeshShowObjPtr>::iterator it = m_editMeshModels.begin(); it != m_editMeshModels.end(); it++)
            //{
            //	aabb.add((*it)->calRealAABB());
            //}
            float moveZ = -aabb.m_Zmin;
            m_operateMoveZ += moveZ;

            for (std::set<CHMeshShowObjPtr>::iterator it = m_editMeshModels.begin(); it != m_editMeshModels.end(); it++)
            {
                (*it)->m_params[8] += moveZ;

                //简单更新一下包围盒
                (*it)->m_realAABB.m_Zmin += moveZ;
                (*it)->m_realAABB.m_Zmax += moveZ;

                //计算变换矩阵
                QMatrix4x4 sumtran1 = CHBaseAlg::instance()->calTransformFromParams(QVector3D((*it)->m_rotCenter[0],
                    (*it)->m_rotCenter[1], (*it)->m_rotCenter[2]), (*it)->m_params);

                //刷新模型
                (*it)->setTransform(sumtran1);
            }

            refreshScaleFrame();
        }

        m_stepFlag = 0;
        m_pickedObj = 0;
        for (int i = 0; i < m_allPickObjs.size(); i++)
        {
            m_allPickObjs[i]->setStatus(general);
        }
        curScene->refresh();
    }
}

void EditMeshZoomTransformTool::receiveParams(vector<float> params)
{
    CHAABB3D aabb;//当前总的真实包围盒
    int i = 0;
    for (std::set<CHMeshShowObjPtr>::iterator it = m_editMeshModels.begin(); it != m_editMeshModels.end(); it++)
    {
        /*if (m_editMeshModels.size() == 1)//单模型不是重置为进入命令的状态，而是状态量直接设为0
        {
            //接收到的数据是大于0的缩放值，没有考虑镜像，而我m_params的存储是融合了镜像
            for (int p = 0; p < 3; p++)
            {
                if ((*it)->m_params[p] > 0)//原来是什么正负号现在应该就是什么正负号
                {
                    (*it)->m_params[p] = params[p];
                }
                else
                {
                    (*it)->m_params[p] = -params[p];
                }
            }
        }
        else  */
        {
            for (int p = 0; p < 3; p++)
            {
                (*it)->m_params[p] = m_initValues[i][p] * params[p];
            }

            //还要计算位移效果
            QVector3D vecDir = QVector3D((*it)->m_rotCenter[0], (*it)->m_rotCenter[1], (*it)->m_rotCenter[2]) +
                QVector3D(m_initValues[i][3], m_initValues[i][4], m_initValues[i][5]) - m_operationCenter;
            QVector3D newCenter = vecDir * params[0] + m_operationCenter + QVector3D(0, 0, m_operateMoveZ);//这里是否以当前点计算需要讨论
            (*it)->m_params[6] = newCenter[0] - (*it)->m_rotCenter[0];
            (*it)->m_params[7] = newCenter[1] - (*it)->m_rotCenter[1];
            (*it)->m_params[8] = newCenter[2] - (*it)->m_rotCenter[2];
        }

        //计算变换矩阵
        (*it)->setTransform(CHBaseAlg::instance()->calTransformFromParams((*it)->m_rotCenter, (*it)->m_params));

        if (true/*m_lockToPrintPlatform*/)//不管锁不锁定，为了视图变换的正确，这里都要计算包围盒
        {
            aabb.add((*it)->calRealAABB());
        }
        i++;
    }

    if (m_lockToPrintPlatform)
    {
        float moveZ = -aabb.m_Zmin;
        m_operateMoveZ += moveZ;
        for (std::set<CHMeshShowObjPtr>::iterator it = m_editMeshModels.begin(); it != m_editMeshModels.end(); it++)
        {
            (*it)->m_params[8] = (*it)->m_params[8] + moveZ;

            //简单更新一下包围盒
            (*it)->m_realAABB.m_Zmin += moveZ;
            (*it)->m_realAABB.m_Zmax += moveZ;

            //计算变换矩阵
            QMatrix4x4 sumtran1 = CHBaseAlg::instance()->calTransformFromParams((*it)->m_rotCenter, (*it)->m_params);

            //刷新模型
            (*it)->setTransform(sumtran1);
        }
    }

    for (std::set<CHMeshShowObjPtr>::iterator it = m_editMeshModels.begin(); it != m_editMeshModels.end(); it++)
    {
        CH3DPrintModelPtr meshPtr = dynamic_pointer_cast<CH3DPrintModel>(*it);
        if (meshPtr != NULL)
        {
            meshPtr->isSceneIn(meshPtr->calRealAABB(), getDoc()->m_machineBox->getBaseAABB());
        }
    }

    //刷新旋转调节框架
    refreshScaleFrame();
    refreshBoxSizeUI();
    curScene->refresh();
}

void EditMeshZoomTransformTool::refreshBoxSizeUI()
{
    submitToUI();
}

void EditMeshZoomTransformTool::refreshScaleFrame()
{
    if (m_adjustXPoint == nullptr || m_adjustYPoint == nullptr || m_adjustZPoint == nullptr)
        return;
    /*if (m_editMeshModels.size() == 1)
    {
        CHMeshShowObjPtr firstmesh = *m_editMeshModels.begin();

        //求调节点变换（与模型变换不一致，坐标轴变换不要融入镜像）
        vector<float> params1 = firstmesh->m_params;
        params1[0] = fabs(params1[0]);
        params1[1] = fabs(params1[1]);
        params1[2] = fabs(params1[2]);

        QMatrix4x4 tmpTranslate1, tmpTranslate2;
        //tmpTranslate2.translate(-QVector3D(params1[6], params1[7], 0));
        QMatrix4x4 sumtran1 = tmpTranslate2 * CHBaseAlg::instance()->calTransformFromParams(firstmesh->m_rotCenter, params1);
        m_adjustXPoint->setTransform(sumtran1);
        m_adjustYPoint->setTransform(sumtran1);
        m_adjustZPoint->setTransform(sumtran1);
        m_adjustXYZPoint->setTransform(sumtran1);
        m_middleshowcurve1->setTransform(sumtran1);
        m_middleshowcurve2->setTransform(sumtran1);

        params1[0] = max((double)params1[0], 1.0);
        params1[1] = max((double)params1[1], 1.0);
        params1[2] = max((double)params1[2], 1.0);
        QMatrix4x4 sumtran2 = tmpTranslate2 * CHBaseAlg::instance()->calTransformFromParams(firstmesh->m_rotCenter, params1);
        m_adjustAxisX->setTransform(sumtran2);
        m_adjustAxisY->setTransform(sumtran2);
        m_adjustAxisZ->setTransform(sumtran2);

        QMatrix4x4 tran1, tran2, tran3, tran4, tran5, tran6;
        tran1.translate(-firstmesh->m_rotCenter);
        tran2.rotate(firstmesh->m_params[3], QVector3D(1, 0, 0));
        tran3.rotate(firstmesh->m_params[4], QVector3D(0, 1, 0));
        tran4.rotate(firstmesh->m_params[5], QVector3D(0, 0, 1));
        tran5.translate(QVector3D(firstmesh->m_params[6], firstmesh->m_params[7], firstmesh->m_params[8]));//主要看这个位置是哪个点相对于世界坐标原点来说
        tran6.translate(firstmesh->m_rotCenter);
        QMatrix4x4 sumtran3 = tran6 * tran5 * tran4 * tran3 * tran2 * tran1;
        m_markXPoint->setTransform(sumtran3);
        m_markYPoint->setTransform(sumtran3);
        m_markZPoint->setTransform(sumtran3);
    }
    else */
    {
        float ratio = fabs(m_firstMesh->m_params[0] / m_initValues[0][0]);
        QMatrix4x4 tran1;
        tran1.translate(QVector3D(0, 0, m_operateMoveZ));
        QMatrix4x4 sumtran1 = tran1 * TransformPack::scale(m_operationCenter, ratio, ratio, ratio);
        m_adjustXPoint->setTransform(sumtran1);
        m_adjustYPoint->setTransform(sumtran1);
        m_adjustZPoint->setTransform(sumtran1);
        m_adjustXYZPoint->setTransform(sumtran1);
        m_middleshowcurve1->setTransform(sumtran1);
        m_middleshowcurve2->setTransform(sumtran1);

        ratio = max((double)ratio, 1.0);
        QMatrix4x4 sumtran2 = tran1 * TransformPack::scale(m_operationCenter, ratio, ratio, ratio);
        m_adjustAxisX->setTransform(sumtran2);
        m_adjustAxisY->setTransform(sumtran2);
        m_adjustAxisZ->setTransform(sumtran2);

        m_markXPoint->setTransform(tran1);
        m_markYPoint->setTransform(tran1);
        m_markZPoint->setTransform(tran1);
    }
}

void EditMeshZoomTransformTool::submitToUI()
{
    vector<float> params(3);
    CHMeshShowObjPtr mesh = *m_editMeshModels.begin();
    /*
    if (m_editMeshModels.size() == 1)//单选输出模型本身缩放状态量
    {
        //ui那边进行了正负号处理，这里就不用取fabs了
        params[0] = mesh->m_params[0];
        params[1] = mesh->m_params[1];
        params[2] = mesh->m_params[2];
    }
    else   */
    {
        params[0] = mesh->m_params[0] / m_initValues[0][0];
        params[1] = mesh->m_params[1] / m_initValues[0][1];
        params[2] = mesh->m_params[2] / m_initValues[0][2];
    }
    emit sendParams(params);

    vector<float > boxSize(3);
    boxSize[0] = m_initBox[0] * params[0];
    boxSize[1] = m_initBox[1] * params[1];
    boxSize[2] = m_initBox[2] * params[2];
    emit sendBoxSizeParam(boxSize);
}


