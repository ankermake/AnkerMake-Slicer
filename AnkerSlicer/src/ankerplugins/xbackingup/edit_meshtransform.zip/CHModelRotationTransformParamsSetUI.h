#ifndef CHModelRotationTransformParamsSetUI_H
#define CHModelRotationTransformParamsSetUI_H


#include <QDialog>
#include "QLabel"
#include <vector>
#include "CHCustomLineEdit.h"
#include "../../common/controlInterface/BubbleWidget.h"
#include "../../common/controlInterface/line.h"
#include "../../common/controlInterface/switchbutton.h"
#include <QDoubleSpinBox>
#include <QToolButton>

using namespace std;

class CHModelRotationTransformParamsSetUI : public control::BubbleWidget
{
    Q_OBJECT

public:
    CHModelRotationTransformParamsSetUI(QWidget* parent = Q_NULLPTR);
    ~CHModelRotationTransformParamsSetUI();


    public
Q_SLOTS:
    void receiveParams(vector<float> params);
    void submit();
    void submit(double);
    void reset();

Q_SIGNALS:
    void sendParams(vector<float> params);
    void valueChanged(double);
    void stateChanged(bool checked);

private:
    void adjustSingleAngle(float& angle);

public:
    QToolButton* m_resetButton;

private:

    QDoubleSpinBox* m_xRot;
    QDoubleSpinBox* m_yRot;
    QDoubleSpinBox* m_zRot;


    std::vector<QDoubleSpinBox*> m_allLineEdits;

};
#endif
