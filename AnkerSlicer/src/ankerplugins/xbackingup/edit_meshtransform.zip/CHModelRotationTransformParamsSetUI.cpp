#include "CHModelRotationTransformParamsSetUI.h"
#include "QPushButton"
#include "QBoxLayout"
#include "QValidator"
#include <QSignalMapper>

#define MAXNUM 360
#define MINNUM 0

CHModelRotationTransformParamsSetUI::CHModelRotationTransformParamsSetUI(QWidget* parent)
    : BubbleWidget(parent)
{
    move(97, 493);
    setFixedSize(172, 179);
    setAutoFillBackground(true);
    QPalette pal = palette();
    pal.setColor(QPalette::Background, QColor(255, 255, 255, 255));
    setPalette(pal);

    QVBoxLayout* mainblaout = new QVBoxLayout(this);
    QFont font1;
    font1.setPixelSize(14);
    QLabel* rotateLabel = new QLabel;
    rotateLabel->setFont(font1);
    rotateLabel->setText(tr("Rotate"));
    //rotateLabel->setStyleSheet("QLabel{ \n\tfont: roboto;\n\twidth: 42px; \n\theight: 16px; \n\ttop: 505px; \n\tleft: 109px; \n\tcolor: #333333; \n }");


    m_resetButton = new QToolButton;
    m_resetButton->setIcon(QIcon(":/images/fdm_remakes_small_icon_n.png"));
    m_resetButton->setStyleSheet(QString::fromUtf8("QToolButton{\n"
        "   border: none;\n"
        "   background: transparent;\n"
        "   width: 13.4px;\n"
        "   height: 13.4px;\n"
        "   left: 240.3px;\n"
        "   top: 507.04px;\n"
        "}\n"));
    //connect(m_resetButton, SIGNAL(clicked()), this, SLOT(reset()));
    QHBoxLayout* hblaout1 = new QHBoxLayout;
    hblaout1->addWidget(rotateLabel);
    hblaout1->addSpacing(90);
    hblaout1->addWidget(m_resetButton);
    hblaout1->setStretch(0, 42);
    hblaout1->setStretch(1, 90);
    hblaout1->setStretch(2, 13);
    mainblaout->addLayout(hblaout1);

    Line* line = new Line;
    line->setStyleSheet(QString::fromUtf8("QFrame{\n"
        "   width: 148px;\n"
        "   height: 1px;\n"
        "   top: 533px;\n"
        "   left: 109px;\n"
        "   color: #E7E7E9;\n"
        "}"));
    QHBoxLayout* hblaout2 = new QHBoxLayout;
    hblaout2->addWidget(line);
    mainblaout->addLayout(hblaout2);

    QLabel* xLogo = new QLabel;
    QPixmap xLogoPixmap(":/images/fdm_rotate_x_icon_u.png");
    xLogo->setPixmap(xLogoPixmap);
    xLogo->setScaledContents(true);
    xLogo->setStyleSheet(QString::fromUtf8("QLabel{\n"
        "   width: 14.49px;\n"
        "   height: 15.96px;\n"
        "   top: 553.09px;\n"
        "   left: 112.71px;\n"
        "}"));
    QLabel* xlabel = new QLabel(tr("X"));
    xlabel->setStyleSheet("QLabel{\n\twidth: 6px;\n\theight: 16px;\n\ttop: 553px;\n\tleft: 139px;\n\tcolor: #E32525;\n}");
    m_xRot = new QDoubleSpinBox;
    m_xRot->setButtonSymbols(QAbstractSpinBox::NoButtons);
    m_xRot->setAutoFillBackground(true);
    m_xRot->setSuffix("°");
    m_xRot->setStyleSheet(QString::fromUtf8("QDoubleSpinBox{\n"
        "width: 100px;\n"
        "height: 30px;\n"
        "top: 546px;\n"
        "left: 157px;\n"
        "border: 1px solid #E7E7E9;\n"
        "border-radius:4px;\n"
        "font-size: 12px;\n"
        "\n"
        "}"));
    QHBoxLayout* xhlayout = new QHBoxLayout;
    xhlayout->addWidget(xLogo);
    xhlayout->addWidget(xlabel);
    xhlayout->addWidget(m_xRot);
    xhlayout->setStretch(0, 15);
    xhlayout->setStretch(1, 6);
    xhlayout->setStretch(2, 100);
    mainblaout->addLayout(xhlayout);


    QLabel* yLogo = new QLabel;
    QPixmap yLogoPixmap(":/images/fdm_rotate_y_icon_u.png");
    yLogo->setPixmap(yLogoPixmap);
    yLogo->setScaledContents(true);
    yLogo->setStyleSheet(QString::fromUtf8("QLabel{\n"
        "   width: 14.49px;\n"
        "   height: 15.96px;\n"
        "   top: 595.09px;\n"
        "   left: 112.71px;\n"
        "}"));
    QLabel* ylabel = new QLabel(tr("Y"));
    ylabel->setStyleSheet("QLabel{\n\twidth: 6px;\n\theight: 16px;\n\ttop: 595px;\n\tleft: 139px;\n\tcolor: #62D361;\n}");
    m_yRot = new QDoubleSpinBox;
    m_yRot->setButtonSymbols(QAbstractSpinBox::NoButtons);
    m_yRot->setAutoFillBackground(true);
    m_yRot->setSuffix("°");
    m_yRot->setStyleSheet(QString::fromUtf8("QDoubleSpinBox{\n"
        "width: 100px;\n"
        "height: 30px;\n"
        "top: 588px;\n"
        "left: 157px;\n"
        "border: 1px solid #E7E7E9;\n"
        "border-radius:4px;\n"
        "font-size: 12px;\n"
        "\n"
        "}"));
    QHBoxLayout* yhlayout = new QHBoxLayout;
    yhlayout->addWidget(yLogo);
    yhlayout->addWidget(ylabel);
    yhlayout->addWidget(m_yRot);
    yhlayout->setStretch(0, 15);
    yhlayout->setStretch(1, 6);
    yhlayout->setStretch(2, 100);
    mainblaout->addLayout(yhlayout);


    QLabel* zLogo = new QLabel;
    QPixmap zLogoPixmap(":/images/fdm_rotate_z_icon_u.png");
    zLogo->setPixmap(zLogoPixmap);
    zLogo->setScaledContents(true);
    zLogo->setStyleSheet(QString::fromUtf8("QLabel{\n"
        "   width: 14.49px;\n"
        "   height: 15.96px;\n"
        "   top: 637.09px;\n"
        "   left: 112.71px;\n"
        "}"));
    QLabel* zlabel = new QLabel(tr("Z"));
    zlabel->setStyleSheet("QLabel{\n\twidth: 6px;\n\theight: 16px;\n\ttop: 637px;\n\tleft: 139px;\n\tcolor: #0167FF;\n}");
    m_zRot = new QDoubleSpinBox;
    m_zRot->setButtonSymbols(QAbstractSpinBox::NoButtons);
    m_zRot->setAutoFillBackground(true);
    m_zRot->setSuffix("°");
    m_zRot->setStyleSheet(QString::fromUtf8("QDoubleSpinBox{\n"
        "width: 100px;\n"
        "height: 30px;\n"
        "top: 630px;\n"
        "left: 157px;\n"
        "border: 1px solid #E7E7E9;\n"
        "border-radius:4px;\n"
        "font-size: 12px;\n"
        "\n"
        "}"));
    QHBoxLayout* zhlayout = new QHBoxLayout;
    zhlayout->addWidget(zLogo);
    zhlayout->addWidget(zlabel);
    zhlayout->addWidget(m_zRot);
    zhlayout->setStretch(0, 15);
    zhlayout->setStretch(1, 6);
    zhlayout->setStretch(2, 100);
    mainblaout->addLayout(zhlayout);


    m_allLineEdits.push_back(m_xRot);
    m_allLineEdits.push_back(m_yRot);
    m_allLineEdits.push_back(m_zRot);

    for (int i = 0; i < m_allLineEdits.size(); i++)
    {
        m_allLineEdits[i]->setDecimals(2);
        m_allLineEdits[i]->setMaximum(MAXNUM);
        m_allLineEdits[i]->setMinimum(MINNUM);
        m_allLineEdits[i]->setWrapping(true);
        m_allLineEdits[i]->setSingleStep(1.0);
        connect(m_allLineEdits[i], SIGNAL(valueChanged(double)), this, SLOT(submit(double)));
    }
    connect(m_resetButton, SIGNAL(clicked()), this, SLOT(reset()));
}

CHModelRotationTransformParamsSetUI::~CHModelRotationTransformParamsSetUI()
{

}

void CHModelRotationTransformParamsSetUI::receiveParams(vector<float> params)
{
    for (int i = 0; i < m_allLineEdits.size(); i++)
    {
        m_allLineEdits[i]->setValue(params[i]);
    }
}

void CHModelRotationTransformParamsSetUI::submit()
{
    vector<float> params(3);
    for (int i = 0; i < m_allLineEdits.size(); i++)
    {
        params[i] = m_allLineEdits[i]->text().toFloat();
    }

    adjustSingleAngle(params[0]);
    adjustSingleAngle(params[1]);
    adjustSingleAngle(params[2]);
    receiveParams(params);

    emit sendParams(params);
}

void CHModelRotationTransformParamsSetUI::submit(double)
{
    vector<float> params(3);
    for (int i = 0; i < m_allLineEdits.size(); i++)
    {
        params[i] = m_allLineEdits[i]->value();
    }

    adjustSingleAngle(params[0]);
    adjustSingleAngle(params[1]);
    adjustSingleAngle(params[2]);
    receiveParams(params);

    emit sendParams(params);
}

void CHModelRotationTransformParamsSetUI::reset()
{
    for (int i = 0; i < m_allLineEdits.size(); i++)
    {
        m_allLineEdits[i]->setValue(0);
    }
    vector<float> params(3);
    params[0] = 0;
    params[1] = 0;
    params[2] = 0;
    emit sendParams(params);
}


void CHModelRotationTransformParamsSetUI::adjustSingleAngle(float& angle)
{
    int n = (int)(angle / 360.0);
    if (angle < 0)
    {
        n--;
    }
    angle = angle - 360.0 * n;
}






