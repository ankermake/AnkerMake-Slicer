/****************************************************************************
 * MeshLab                                                           o o     *
 * A versatile mesh processing toolbox                             o     o   *
 *                                                                _   O  _   *
 * Copyright(C) 2008                                                \/)\/    *
 * Visual Computing Lab                                            /\/|      *
 * ISTI - Italian National Research Council                           |      *
 *                                                                    \      *
 * All rights reserved.                                                      *
 *                                                                           *
 * This program is free software; you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation; either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)          *
 * for more details.                                                         *
 *                                                                           *
 ****************************************************************************/
#ifndef ManualSupportTool_H
#define ManualSupportTool_H

#include <QObject>
#include <QStringList>
#include <QList>

#include <common/plugins/interfaces/edit_plugin.h>
#include "common/GeoAndShow/CHLineSegment3DShowObj.h"
#include "common/GeoAndShow/CHPointShowObj.h"
#include "common/GeoAndShow/CHAssembly.h"
#include "common/GeoAndShow/CHCuboid.h"
#include "common/GeoAndShow/CH3DPrintModel.h"
#include "CHModelManualSupportParamsSetUI.h"
#include "common/support/supportline.h"

class ManualSupportTool : public QObject, public EditTool
{
    Q_OBJECT

public:

    ManualSupportTool();
    virtual ~ManualSupportTool() {}
    virtual bool startEdit(MeshDocument& md, GLArea* /*parent*/, MLSceneGLSharedDataContext* /*cont*/);
    virtual void endEdit(MeshDocument& md, GLArea* /*parent*/, MLSceneGLSharedDataContext* /*cont*/);
    virtual void decorate(MeshModel&, GLArea*, QPainter*);
    virtual void mousePressEvent(QMouseEvent*, MeshModel&, GLArea*);
    virtual void mouseMoveEvent(QMouseEvent*, MeshModel&, GLArea*);
    virtual void mouseReleaseEvent(QMouseEvent* event, MeshModel&, GLArea*);


    public
Q_SLOTS:
    void receiveCuboidSize(float lenth, float wide);



private:
    //  0: 都不是, 1:是 CH3DPrintModel, 2: 是 CHCuboidPtr,
    int superShowObj(CHShowObjPtr obj);
    bool checkSupportAngle(const PickResult& pickPrintResult, float angle = 89.99);

private:
    CHModelManualSupportParamsSetUI* m_paramUI;
    std::set<CHMeshShowObjPtr> m_editMeshModels;

    CHMeshShowObjPtr m_pickedModel;
    CHMeshShowObjPtr m_pickedModelLock;

    QColor colorPrintModel;
    QColor colorSupportModel;
    float angleSupport;

    CHCuboidPtr m_cuboidShow;
    //CHSupportCuboidPtr m_cuboidShow;

    PickResult m_result;

    SupportPoint getSupportPoint();
};

#endif
