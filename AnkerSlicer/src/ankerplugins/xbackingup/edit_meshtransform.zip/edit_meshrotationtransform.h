/****************************************************************************
 * MeshLab                                                           o o     *
 * A versatile mesh processing toolbox                             o     o   *
 *                                                                _   O  _   *
 * Copyright(C) 2008                                                \/)\/    *
 * Visual Computing Lab                                            /\/|      *
 * ISTI - Italian National Research Council                           |      *
 *                                                                    \      *
 * All rights reserved.                                                      *
 *                                                                           *
 * This program is free software; you can redistribute it and/or modify      *
 * it under the terms of the GNU General Public License as published by      *
 * the Free Software Foundation; either version 2 of the License, or         *
 * (at your option) any later version.                                       *
 *                                                                           *
 * This program is distributed in the hope that it will be useful,           *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)          *
 * for more details.                                                         *
 *                                                                           *
 ****************************************************************************/
#ifndef EditMeshRotationTransformTool_H
#define EditMeshRotationTransformTool_H

#include <QObject>
#include <QStringList>
#include <QList>

#include <common/plugins/interfaces/edit_plugin.h>
#include "common/GeoAndShow/CHLineSegment3DShowObj.h"
#include "common/GeoAndShow/CHCircleShowObj.h"
#include "common/GeoAndShow/CHPointShowObj.h"
#include "CHModelRotationTransformParamsSetUI.h"
#include "common/GeoAndShow/CHAssembly.h"


DEF_PTR(CHLocalCoordinateAxis)
class CHLocalCoordinateAxis :public CHAssembly
{
public:
    CHLocalCoordinateAxis();
    virtual ~CHLocalCoordinateAxis();

public:
    void create(QVector3D center, double lenth);

private:
    CHLineSegment3DShowObjPtr m_axisX;
    CHLineSegment3DShowObjPtr m_axisY;
    CHLineSegment3DShowObjPtr m_axisZ;
};


DEF_PTR(CHAdjustCircle)
//旋转调节框架
class CHAdjustCircle :public CHAssembly
{
public:
    CHAdjustCircle();
    virtual ~CHAdjustCircle();

public:
    void create(QVector3D center, double rad, QVector3D nor, QVector3D refVec);


public:
    //这几个必须是单位阵，因为渲染现在没做这种反复嵌套的数据结构
    CHCircleShowObjPtr m_circleBody;
    CHLineSegment3DShowObjPtr m_lineBody;
    CHPointShowObjPtr m_adjustPointBody;
};


class EditMeshRotationTransformTool : public QObject, public EditTool
{
    Q_OBJECT

public:

    EditMeshRotationTransformTool();
    virtual ~EditMeshRotationTransformTool() {}
    virtual bool startEdit(MeshDocument& md, GLArea* /*parent*/, MLSceneGLSharedDataContext* /*cont*/);
    virtual void endEdit(MeshDocument& md, GLArea* /*parent*/, MLSceneGLSharedDataContext* /*cont*/);
    virtual void decorate(MeshModel&, GLArea*, QPainter*);
    virtual void mousePressEvent(QMouseEvent*, MeshModel&, GLArea*);
    virtual void mouseMoveEvent(QMouseEvent*, MeshModel&, GLArea*);
    virtual void mouseReleaseEvent(QMouseEvent* event, MeshModel&, GLArea*);

    public
Q_SLOTS:
    void showAxis(bool showed);
    void receiveParams(vector<float> params);
    void resetBtnClicked();
    void resetSelectedObjsClicked();

Q_SIGNALS:
    void sendParams(vector<float> params);

private:
    void adjustSingleAngle(float& angle);

    //刷新旋转调节框架
    void refreshRotationFrame();

    void submitToUI();


private:
    CHModelRotationTransformParamsSetUI* m_paramUI;
    std::set<CHMeshShowObjPtr> m_editMeshModels;
    CHMeshShowObjPtr m_firstMesh;//???????????????
    QVector3D m_operationCenter;

    //本地坐标系
    CHLocalCoordinateAxisPtr m_CoordAxis1;
    CHLocalCoordinateAxisPtr m_CoordAxis2;

    //旋转调节框架
    CHAdjustCirclePtr m_adjustCircleX;
    CHAdjustCirclePtr m_adjustCircleY;
    CHAdjustCirclePtr m_adjustCircleZ;
    std::vector<CHShowObjPtr> m_allPickObjs;

    std::vector<CHShowObjPtr> m_allShowObjs;

    CHShowObjPtr m_pickedObj;
    int m_stepFlag;//同cmd的m_step，为了移植的方便，这里自己定义
    std::vector<std::vector<float>> m_values;//鼠标按下一刻保存的量
    std::vector<std::vector<float>> m_initValues;//初始量状态保存，用来做重置

    float m_operateMoveZ;//???????????z????

    CHLineSegment3DShowObjPtr m_adjustShowCurve;//鼠标交互旋转的中间显示线

    //为了解决在mouse事件中获取的模型视图矩阵是单位阵（glarea渲染框架调了glLoadIdentity）而设置
    GLdouble mm[16];
    GLdouble pm[16];
    GLint vp[4];
};

#endif
