#include "CHModelRotationTransformParamsSetUI.h"
#include "QPushButton"
#include "QBoxLayout"
#include "QValidator"
#include <QSignalMapper>



CHModelRotationTransformParamsSetUI::CHModelRotationTransformParamsSetUI(QWidget *parent)
	: QWidget(parent)
{
	move(120, 100);
	setFixedSize(300, 400);

	QGroupBox* groupbox = createParamsSetUI();

	m_resetButton = new QPushButton(QString::fromLocal8Bit("??"), this);


	QVBoxLayout* vlayout = new QVBoxLayout(this);
	vlayout->setSpacing(10);
	vlayout->addWidget(groupbox);
	vlayout->addWidget(m_resetButton);
	vlayout->addStretch(1);

}

CHModelRotationTransformParamsSetUI::~CHModelRotationTransformParamsSetUI()
{
	
}

void CHModelRotationTransformParamsSetUI::receiveParams(vector<float> params)
{	
	for (int i = 0; i < m_allLineEdits.size(); i++)
	{
		m_allLineEdits[i]->setText(QString::number(params[i], 'f', 2));
	}	
}

void CHModelRotationTransformParamsSetUI::submit()
{
	vector<float> params(3);
	for (int i = 0; i < m_allLineEdits.size(); i++)
	{
		params[i] = m_allLineEdits[i]->text().toFloat();
	}
	
	//????
	adjustSingleAngle(params[0]);
	adjustSingleAngle(params[1]);
	adjustSingleAngle(params[2]);
	receiveParams(params);

	emit sendParams(params);
}

void CHModelRotationTransformParamsSetUI::reset()
{
	for (int i = 0; i < m_allLineEdits.size(); i++)
	{
		m_allLineEdits[i]->setText(QString::number(0, 'f', 2));
	}
	vector<float> params(3);
	params[0] = 0;
	params[1] = 0;
	params[2] = 0;
	emit sendParams(params);
}

QGroupBox * CHModelRotationTransformParamsSetUI::createParamsSetUI()
{
	QGroupBox* groupbox = new QGroupBox(this);
	groupbox->setTitle(QString::fromLocal8Bit("??"));
	groupbox->setAlignment(Qt::AlignHCenter);

	QGridLayout* layout = new QGridLayout(groupbox);
	//layout->setSpacing(20);//????

	QLabel* xlabel = new QLabel(QString::fromLocal8Bit("X?"));
	QLabel* ylabel = new QLabel(QString::fromLocal8Bit("Y?"));
	QLabel* zlabel = new QLabel(QString::fromLocal8Bit("Z?"));
	m_xRot= new QLineEdit(this);
	m_yRot = new QLineEdit(this);
	m_zRot = new QLineEdit(this);
	QLabel* rotUnit1 = new QLabel(QString::fromLocal8Bit("?"));
	QLabel* rotUnit2 = new QLabel(QString::fromLocal8Bit("?"));
	QLabel* rotUnit3 = new QLabel(QString::fromLocal8Bit("?"));
	
	m_allLineEdits.push_back(m_xRot);
	m_allLineEdits.push_back(m_yRot);
	m_allLineEdits.push_back(m_zRot);

	QDoubleValidator* dv = new QDoubleValidator();
	dv->setDecimals(2);
	for (int i = 0; i < m_allLineEdits.size(); i++)
	{
		m_allLineEdits[i]->setValidator(dv);
	}

	layout->addWidget(xlabel, 0, 0);
	layout->addWidget(m_xRot, 0, 1);
	layout->addWidget(rotUnit1, 0, 2);
	layout->addWidget(ylabel, 1, 0);
	layout->addWidget(m_yRot, 1, 1);
	layout->addWidget(rotUnit1, 1, 2);
	layout->addWidget(zlabel, 2, 0);
	layout->addWidget(m_zRot, 2, 1);
	layout->addWidget(rotUnit1, 2, 2);

	//??
	for (int i = 0; i < m_allLineEdits.size(); i++)
	{
		connect(m_allLineEdits[i], SIGNAL(editingFinished()), this, SLOT(submit()));
	}

	return groupbox;
}

void CHModelRotationTransformParamsSetUI::adjustSingleAngle(float & angle)
{
	int n = (int)(angle / 360.0);
	if (angle < 0)
	{
		n--;
	}
	angle = angle - 360.0*n;
}






