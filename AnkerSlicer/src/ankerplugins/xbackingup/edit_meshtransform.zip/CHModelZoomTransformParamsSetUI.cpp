#include "CHModelZoomTransformParamsSetUI.h"
#include "QPushButton"
#include "QBoxLayout"
#include "QValidator"
#include <QSignalMapper>
#include "edit_meshtransform_factory.h"

#define MAXNUM 1000
#define MINNUM 0

CHModelZoomTransformParamsSetUI::CHModelZoomTransformParamsSetUI(QWidget* parent)
    : BubbleWidget(parent)
{
    move(97, 422);
    setFixedSize(248, 262);

    setAutoFillBackground(true);
    QPalette pal = palette();
    pal.setColor(QPalette::Background, QColor(255, 255, 255, 255));
    setPalette(pal);

    m_ratios.resize(3);

    QVBoxLayout* mainblaout = new QVBoxLayout(this);
    QFont font1;
    font1.setPixelSize(14);
    font1.setFamily(QString("Arial"));
    QLabel* scaleLabel = new QLabel;
    scaleLabel->setFont(font1);
    scaleLabel->setText(tr("Scale"));
    //scaleLabel->setStyleSheet("QLabel{ \n\tfont: Arial;\n\twidth: 35px; \n\theight: 16px; \n\ttop: 434px; \n\tleft: 109px; \n\tcolor: #333333; \n }");

    m_resetButton = new QToolButton;
    m_resetButton->setIcon(QIcon(":/images/fdm_remakes_small_icon_n.png"));
    m_resetButton->setStyleSheet(QString::fromUtf8("QToolButton{\n"
        "   border: none;\n"
        "   background: transparent;\n"
        "   width: 13.4px;\n"
        "   height: 13.4px;\n"
        "   left: 316.3px;\n"
        "   top: 436.04px;\n"
        "}\n"));
    //connect(m_resetButton, SIGNAL(clicked()), this, SLOT(reset()));
    QHBoxLayout* hblaout1 = new QHBoxLayout;
    hblaout1->addWidget(scaleLabel);
    hblaout1->addSpacing(172);
    hblaout1->addWidget(m_resetButton);
    hblaout1->setStretch(0, 35);
    hblaout1->setStretch(1, 172);
    hblaout1->setStretch(2, 13);
    mainblaout->addLayout(hblaout1);


    Line* line = new Line;
    line->setStyleSheet(QString::fromUtf8("QFrame{\n"
        "   width: 224px;\n"
        "   height: 1px;\n"
        "   top: 462px;\n"
        "   left: 109px;\n"
        "   color: #E7E7E9;\n"
        "}"));
    QHBoxLayout* hblayout2 = new QHBoxLayout;
    hblayout2->addWidget(line);
    mainblaout->addLayout(hblayout2);

    QFont font2;
    font2.setPixelSize(12);
    QLabel* u_scaleLabel = new QLabel;
    u_scaleLabel->setText(tr("Uniform Scaling"));
    u_scaleLabel->setFont(font2);
    u_scaleLabel->setStyleSheet("QLabel{ \n\tfont: Arial;\n\twidth: 86px; \n\theight: 14px; \n\ttop: 475px; \n\tleft: 109px; \n\tcolor: #000000; \n }");

    m_lockCheckBox = new SwitchButton;
    m_lockCheckBox->setFixedWidth(26);
    m_lockCheckBox->setFixedHeight(14);
    m_lockCheckBox->setCheckState(m_lockScaleRatio);
    connect(m_lockCheckBox, SIGNAL(stateChanged(bool)), this, SLOT(setLock(bool)));
    QHBoxLayout* hblayout3 = new QHBoxLayout;
    hblayout3->addWidget(u_scaleLabel);
    hblayout3->addWidget(m_lockCheckBox, Qt::AlignRight);
    hblayout3->setStretch(0, 86);
    hblayout3->setStretch(1, 26);
    mainblaout->addLayout(hblayout3);


    QLabel* xLogo = new QLabel;
    QPixmap xLogoPixmap(":/images/fdm_scale_x_icon_u.png");
    xLogo->setPixmap(xLogoPixmap);
    xLogo->setScaledContents(true);
    xLogo->setStyleSheet(QString::fromUtf8("QLabel{\n"
        "   width: 14.9px;\n"
        "   height: 15.96px;\n"
        "   top: 508.09px;\n"
        "   left: 112.71px;\n"
        "}"));
    QLabel* xlabel = new QLabel(tr("X"));
    xlabel->setStyleSheet("QLabel{\n\twidth: 6px;\n\theight: 16px;\n\ttop: 508px;\n\tleft: 139px;\n\tcolor: #E32525;\n}");
    m_xBox = new QDoubleSpinBox;
    m_xBox->setButtonSymbols(QAbstractSpinBox::NoButtons);
    m_xBox->setAutoFillBackground(true);
    m_xBox->setSuffix("mm");
    m_xBox->setDecimals(2);
    m_xBox->setMinimum(-99999);
    m_xBox->setMaximum(99999);
    m_xBox->setReadOnly(true);
    m_xBox->setStyleSheet(QString::fromUtf8("QDoubleSpinBox{\n"
        "width: 88px;\n"
        "height: 30px;\n"
        "top: 501px;\n"
        "left: 157px;\n"
        "border: 1px solid #E7E7E9;\n"
        "border-radius:4px;\n"
        "font-size: 12px;\n"
        "\n"
        "}"));

    QLabel* xLogo2 = new QLabel;
    QPixmap xLogo2Pixmap(":/images/fm_scale_round_icon_u.png");
    xLogo2->setPixmap(xLogo2Pixmap);
    xLogo2->setScaledContents(true);
    xLogo2->setStyleSheet(QString::fromUtf8("QLabel{\n"
        "   width: 16px;\n"
        "   height: 16px;\n"
        "   top: 508px;\n"
        "   left: 247px;\n"
        "}"));
    m_xScale = new QDoubleSpinBox;
    m_xScale->setButtonSymbols(QAbstractSpinBox::NoButtons);
    m_xScale->setAutoFillBackground(true);
    m_xScale->setValue(100.0);
    m_xScale->setSuffix("%");
    m_xScale->setStyleSheet(QString::fromUtf8("QDoubleSpinBox{\n"
        "width: 68px;\n"
        "height: 30px;\n"
        "top: 501px;\n"
        "left: 265px;\n"
        "border: 1px solid #E7E7E9;\n"
        "border-radius:4px;\n"
        "font-size: 12px;\n"
        "\n"
        "}"));
    QHBoxLayout* hblayout4 = new QHBoxLayout;
    hblayout4->addWidget(xLogo);
    hblayout4->addWidget(xlabel);
    hblayout4->addWidget(m_xBox);
    hblayout4->addWidget(xLogo2);
    hblayout4->addWidget(m_xScale);
    hblayout4->setStretch(0, 14);
    hblayout4->setStretch(1, 6);
    hblayout4->setStretch(2, 88);
    hblayout4->setStretch(3, 16);
    hblayout4->setStretch(4, 68);
    mainblaout->addLayout(hblayout4);



    QLabel* yLogo = new QLabel;
    QPixmap yLogoPixmap(":/images/fdm_scale_y_icon_u.png");
    yLogo->setPixmap(yLogoPixmap);
    yLogo->setScaledContents(true);
    yLogo->setStyleSheet(QString::fromUtf8("QLabel{\n"
        "   width: 14.9px;\n"
        "   height: 15.96px;\n"
        "   top: 550.09px;\n"
        "   left: 112.71px;\n"
        "}"));
    QLabel* ylabel = new QLabel(tr("Y"));
    ylabel->setStyleSheet("QLabel{\n\twidth: 6px;\n\theight: 16px;\n\ttop: 550px;\n\tleft: 139px;\n\tcolor: #62D361;\n}");
    m_yBox = new QDoubleSpinBox;
    m_yBox->setButtonSymbols(QAbstractSpinBox::NoButtons);
    m_yBox->setAutoFillBackground(true);
    m_yBox->setSuffix("mm");
    m_yBox->setDecimals(2);
    m_yBox->setMinimum(-99999);
    m_yBox->setMaximum(99999);
    m_yBox->setReadOnly(true);
    m_yBox->setStyleSheet(QString::fromUtf8("QDoubleSpinBox{\n"
        "width: 88px;\n"
        "height: 30px;\n"
        "top: 543px;\n"
        "left: 157px;\n"
        "border: 1px solid #E7E7E9;\n"
        "border-radius:4px;\n"
        "font-size: 12px;\n"
        "\n"
        "}"));

    QLabel* yLogo2 = new QLabel;
    QPixmap yLogo2Pixmap(":/images/fm_scale_round_icon_u.png");
    yLogo2->setPixmap(yLogo2Pixmap);
    yLogo2->setScaledContents(true);
    yLogo2->setStyleSheet(QString::fromUtf8("QLabel{\n"
        "   width: 16px;\n"
        "   height: 16px;\n"
        "   top: 550px;\n"
        "   left: 247px;\n"
        "}"));
    m_yScale = new QDoubleSpinBox;
    m_yScale->setButtonSymbols(QAbstractSpinBox::NoButtons);
    m_yScale->setAutoFillBackground(true);
    m_yScale->setValue(100.0);
    m_yScale->setSuffix("%");
    m_yScale->setStyleSheet(QString::fromUtf8("QDoubleSpinBox{\n"
        "width: 68px;\n"
        "height: 30px;\n"
        "top: 543px;\n"
        "left: 265px;\n"
        "border: 1px solid #E7E7E9;\n"
        "border-radius:4px;\n"
        "font-size: 12px;\n"
        "\n"
        "}"));
    QHBoxLayout* hblayout5 = new QHBoxLayout;
    hblayout5->addWidget(yLogo);
    hblayout5->addWidget(ylabel);
    hblayout5->addWidget(m_yBox);
    hblayout5->addWidget(yLogo2);
    hblayout5->addWidget(m_yScale);
    hblayout5->setStretch(0, 14);
    hblayout5->setStretch(1, 6);
    hblayout5->setStretch(2, 88);
    hblayout5->setStretch(3, 16);
    hblayout5->setStretch(4, 68);
    mainblaout->addLayout(hblayout5);


    QLabel* zLogo = new QLabel;
    QPixmap zLogoPixmap(":/images/fdm_scale_z_icon_u.png");
    zLogo->setPixmap(zLogoPixmap);
    zLogo->setScaledContents(true);
    zLogo->setStyleSheet(QString::fromUtf8("QLabel{\n"
        "   width: 14.9px;\n"
        "   height: 15.96px;\n"
        "   top: 592.09px;\n"
        "   left: 112.71px;\n"
        "}"));
    QLabel* zlabel = new QLabel(tr("Z"));
    zlabel->setStyleSheet("QLabel{\n\twidth: 6px;\n\theight: 16px;\n\ttop: 592px;\n\tleft: 139px;\n\tcolor: #0167FF;\n}");
    m_zBox = new QDoubleSpinBox;
    m_zBox->setButtonSymbols(QAbstractSpinBox::NoButtons);
    m_zBox->setAutoFillBackground(true);
    m_zBox->setDecimals(2);
    m_zBox->setMinimum(-99999);
    m_zBox->setMaximum(99999);
    m_zBox->setSuffix("mm");
    m_zBox->setReadOnly(true);
    m_zBox->setStyleSheet(QString::fromUtf8("QDoubleSpinBox{\n"
        "width: 88px;\n"
        "height: 30px;\n"
        "top: 585px;\n"
        "left: 157px;\n"
        "border: 1px solid #E7E7E9;\n"
        "border-radius:4px;\n"
        "font-size: 12px;\n"
        "\n"
        "}"));

    QLabel* zLogo2 = new QLabel;
    QPixmap zLogo2Pixmap(":/images/fm_scale_round_icon_u.png");
    zLogo2->setPixmap(zLogo2Pixmap);
    zLogo2->setScaledContents(true);
    zLogo2->setStyleSheet(QString::fromUtf8("QLabel{\n"
        "   width: 16px;\n"
        "   height: 16px;\n"
        "   top: 592px;\n"
        "   left: 247px;\n"
        "}"));
    m_zScale = new QDoubleSpinBox;
    m_zScale->setButtonSymbols(QAbstractSpinBox::NoButtons);
    m_zScale->setAutoFillBackground(true);
    m_zScale->setValue(100.0);
    m_zScale->setSuffix("%");
    m_zScale->setStyleSheet(QString::fromUtf8("QDoubleSpinBox{\n"
        "width: 68px;\n"
        "height: 30px;\n"
        "top: 585px;\n"
        "left: 265px;\n"
        "border: 1px solid #E7E7E9;\n"
        "border-radius:4px;\n"
        "font-size: 12px;\n"
        "\n"
        "}"));
    QHBoxLayout* hblayout6 = new QHBoxLayout;
    hblayout6->addWidget(zLogo);
    hblayout6->addWidget(zlabel);
    hblayout6->addWidget(m_zBox);
    hblayout6->addWidget(zLogo2);
    hblayout6->addWidget(m_zScale);
    hblayout6->setStretch(0, 14);
    hblayout6->setStretch(1, 6);
    hblayout6->setStretch(2, 88);
    hblayout6->setStretch(3, 16);
    hblayout6->setStretch(4, 68);
    mainblaout->addLayout(hblayout6);

    m_scaleToFitButton = new QToolButton;
    m_scaleToFitButton->setText(tr("Scale To Fit"));
    m_scaleToFitButton->setStyleSheet(QString::fromUtf8("QToolButton{\n"
        "   width: 120px;"
        "   height: 32px;"
        "   top: 640px;"
        "   left: 213px;"
        "   border: 1px solid #EDEDED;\n"
        "   border-radius:4px;\n"
        "   background: #EDEDED;\n"
        "   font-size: 12px;\n"
        "}"));
    QHBoxLayout* hblayout7 = new QHBoxLayout;
    hblayout7->addSpacing(116);
    hblayout7->addWidget(m_scaleToFitButton, Qt::AlignRight);
    mainblaout->addLayout(hblayout7);

    m_allScaleEdits.push_back(m_xScale);
    m_allScaleEdits.push_back(m_yScale);
    m_allScaleEdits.push_back(m_zScale);

    m_scaleToFitButton->setCheckable(true);
    //QSignalMapper* mapper = new QSignalMapper(this);
    for (int i = 0; i < m_allScaleEdits.size(); i++)
    {
        m_allScaleEdits[i]->setDecimals(2);
        m_allScaleEdits[i]->setMaximum(MAXNUM);
        m_allScaleEdits[i]->setMinimum(MINNUM);
        connect(m_allScaleEdits[i], SIGNAL(valueChanged(double)), this, SLOT(submit(double)));
    }
    //reset();
}

CHModelZoomTransformParamsSetUI::~CHModelZoomTransformParamsSetUI()
{

}

void CHModelZoomTransformParamsSetUI::receiveParams(vector<float> params)
{
    if (m_lockScaleRatio)
    {
        m_ratios = params;
    }
    for (int i = 0; i < m_allScaleEdits.size(); i++)
    {
        m_allScaleEdits[i]->setValue(fabs(params[i]) * 100.0);
    }
}

void CHModelZoomTransformParamsSetUI::receiveCurrentCenter(vector<float> params)
{
    m_xBox->setValue(params[0]);
    m_yBox->setValue(params[1]);
    m_zBox->setValue(params[2]);
}

void CHModelZoomTransformParamsSetUI::submit()
{
    vector<float> params(3);
    for (int i = 0; i < m_allScaleEdits.size(); i++)
    {
        params[i] = fabs(m_allScaleEdits[i]->value()) / 100.0;//严格的说这里要控制缩放值只能输入正值
    }

    //控制格式
    receiveParams(params);

    emit sendParams(params);
}

void CHModelZoomTransformParamsSetUI::submit(double)
{
    vector<float> params(3);
    for (int i = 0; i < m_allScaleEdits.size(); i++)
    {
        params[i] = fabs(m_allScaleEdits[i]->value()) / 100.0;//严格的说这里要控制缩放值只能输入正值
    }

    //控制格式
    receiveParams(params);

    emit sendParams(params);
}

void CHModelZoomTransformParamsSetUI::reset()
{
    for (int i = 0; i < m_allScaleEdits.size(); i++)
    {
        m_allScaleEdits[i]->setValue(100.0);
    }
    vector<float> params(3);
    params[0] = 1;
    params[1] = 1;
    params[2] = 1;
    emit sendParams(params);
}

void CHModelZoomTransformParamsSetUI::sameScale(int index)
{
    if (m_lockScaleRatio)
    {
        for (int i = 0; i < m_allScaleEdits.size(); i++)
        {
            if (i != index)
            {
                //m_allScaleEdits[i]->setText(QString::number(m_allScaleEdits[index]->text().toFloat() / m_ratios[index] * m_ratios[i]));
            }
        }
    }

    submit();
}

void CHModelZoomTransformParamsSetUI::setLock()
{
    if (m_lockCheckBox->checkState() == Qt::Checked)
    {
        m_lockScaleRatio = true;
        for (int i = 0; i < m_allScaleEdits.size(); i++)
        {
            m_ratios[i] = fabs(m_allScaleEdits[i]->text().toFloat());
        }
    }
    else
    {
        m_lockScaleRatio = false;
    }
}
void CHModelZoomTransformParamsSetUI::setLock(bool checked)
{
    m_lockToPrintPlatform = checked;
    submit(0.0);
}



