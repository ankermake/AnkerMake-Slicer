#include "edit_meshtransform_factory.h"
#include "edit_meshrotationtransform.h"
#include "common/plugins/interfaces/meshlab_plugin.h"
#include "edit_meshmovetransform.h"
#include "edit_meshzoomtransform.h"
#include "edit_meshmirrortransform.h"
#include "edit_meshAnyFaceToPlatformTransform.h"
#include "vcg/space/box3.h"
#include "edit_manualsupport.h"


bool m_lockToPrintPlatform = true;
bool m_lockScaleRatio = true;
bool m_clearSupport = false;
std::list<QAction*> transformActionsList;
ControlInterface* EditMeshTransformFactory::m_conInt = nullptr;

EditMeshTransformFactory::EditMeshTransformFactory() {
    initActionEditTools();
}

QString EditMeshTransformFactory::pluginName() const
{
    return "EditMeshTransform";
}

//get the edit tool for the given action
EditTool* EditMeshTransformFactory::getEditTool(const QAction* action)
{
    const ActionEditTool* actionEditTool = qobject_cast<const ActionEditTool*>(action);
    if (actionEditTool) {
        return actionEditTool->ankerEditTool;
    }
    Q_ASSERT(actionEditTool);
    return nullptr;
}

QString EditMeshTransformFactory::getEditToolDescription(const QAction* action)
{
    const ActionEditTool* actionEditTool = qobject_cast<const ActionEditTool*>(action);
    if (actionEditTool) {
        return actionEditTool->getDescription();
    }
    return tr("transform mesh model");
}



void EditMeshTransformFactory::initialize(ControlInterface* controlmanager, RichParameterList* globalParameterList)
{
    m_conInt = controlmanager;
    for (auto* action : actionList) {
        action->setCheckable(false);
        m_conInt->addActionToModelTranform(action);
    }
}

void EditMeshTransformFactory::initActionEditTools()
{
    {
        moveMeshTransform = new ActionEditTool(QIcon(":/images/fdm_move_icon_e.png"), tr("Move"), this);
        auto ankerEditTool = new EditMeshMoveTransformTool();
        ankerEditTool->setParent(moveMeshTransform);
        moveMeshTransform->setDescription(tr("move mesh model"));
        moveMeshTransform->ankerEditTool = ankerEditTool;
        actionList.push_back(moveMeshTransform);
    }

    {
        scaleMeshTransform = new ActionEditTool(QIcon(":/images/fdm_scale_icon_e.png"), tr("Zoom"), this);
        auto ankerEditTool = new EditMeshZoomTransformTool();
        ankerEditTool->setParent(scaleMeshTransform);
        scaleMeshTransform->setDescription(tr("zoom mesh model"));
        scaleMeshTransform->ankerEditTool = ankerEditTool;
        actionList.push_back(scaleMeshTransform);
    }

    {
        rotateMeshTransform = new ActionEditTool(QIcon(":/images/fdm_rotate_icon_e.png"), tr("Rotate"), this);
        auto ankerEditTool = new EditMeshRotationTransformTool();
        ankerEditTool->setParent(rotateMeshTransform);
        rotateMeshTransform->setDescription(tr("rotate mesh model"));
        rotateMeshTransform->ankerEditTool = ankerEditTool;
        actionList.push_back(rotateMeshTransform);
    }

    {
        mirrorMeshTransform = new ActionEditTool(QIcon(":/images/fdm_mirror_icon_e.png"), tr("Mirror"), this);
        auto ankerEditTool = new EditMeshMirrorTransformTool();
        ankerEditTool->setParent(mirrorMeshTransform);
        mirrorMeshTransform->setDescription(tr("mirror mesh model"));
        mirrorMeshTransform->ankerEditTool = ankerEditTool;
        actionList.push_back(mirrorMeshTransform);
    }

    if (0) {
        anyFaceTransform = new ActionEditTool(QIcon(":/images/icon_manipulators.png"), tr("AnyFace"), this);
        auto ankerEditTool = new EditMeshAnyFaceTransformTool();
        ankerEditTool->setParent(anyFaceTransform);
        anyFaceTransform->setDescription(tr("AnyFaceToPlatform"));
        anyFaceTransform->ankerEditTool = ankerEditTool;
        actionList.push_back(anyFaceTransform);
    }

    {
        manualSupport = new ActionEditTool(QIcon(":/images/fdm_manual_icon_e.png"), tr("Support"), this);
        auto ankerEditTool = new ManualSupportTool();
        ankerEditTool->setParent(manualSupport);
        manualSupport->setDescription(tr("Manual Support"));
        manualSupport->ankerEditTool = ankerEditTool;
        actionList.push_back(manualSupport);
    }
    transformActionsList = actionList;
}

void EditMeshTransformFactory::initMeshModelEulerParams(CHMeshShowObjPtr tmm)
{
    //vcg::Box3f aabb = tmm->bbox;
    CHAABB3D aabb = tmm->getBaseAABB();
    if ((int)tmm->m_params.size() == 0)//??????
    {
        //vcg::Point3f pt = aabb.Center();
        QVector3D pt = aabb.getCenterPoint();

        tmm->m_rotCenter[0] = pt[0];
        tmm->m_rotCenter[1] = pt[1];
        tmm->m_rotCenter[2] = pt[2];
        tmm->m_params.resize(9);
        for (int i = 0; i < 3; i++)
        {
            tmm->m_params[i] = 1;
        }
        for (int i = 3; i < 9; i++)
        {
            tmm->m_params[i] = 0;
        }
    }
}

void EditMeshTransformFactory::recMsgfromManager(PluginMessageData)
{
}

void EditMeshTransformFactory::sendMsg2Manager(PluginMessageData)
{
}


MESHLAB_PLUGIN_NAME_EXPORTER(EditMeshTransformFactory)

