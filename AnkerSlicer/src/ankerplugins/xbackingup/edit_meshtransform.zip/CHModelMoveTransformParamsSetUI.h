/*
*?????????????
*?????
*???2021?12?5?
*/


#ifndef CHModelMoveTransformParamsSetUI_H
#define CHModelMoveTransformParamsSetUI_H


#include <QDialog>
#include "QLabel"
#include <vector>
#include "../../common/controlInterface/BubbleWidget.h"
#include "../../common/controlInterface/line.h"
#include "../../common/controlInterface/switchbutton.h"
#include <QDoubleSpinBox>
#include <QToolButton>


using namespace std;

class CHModelMoveTransformParamsSetUI : public control::BubbleWidget
{
    Q_OBJECT

public:
    CHModelMoveTransformParamsSetUI(QWidget* parent = Q_NULLPTR);
    ~CHModelMoveTransformParamsSetUI();


    void disableLineEdit();

    public
Q_SLOTS:
    void receiveParams(vector<float> params);
    void submit();
    void submit(double);
    void reset();
    void setLock();
    void setLock(bool);

Q_SIGNALS:
    void sendParams(vector<float> params);
    void valueChanged(double);
    void stateChanged(bool checked);
public:
    QToolButton* m_resetButton;
private:

    QDoubleSpinBox* m_yMove;
    QDoubleSpinBox* m_xMove;
    QDoubleSpinBox* m_zMove;

    SwitchButton* m_lockCheck;
    std::vector<QDoubleSpinBox*> m_allLineEdits;

};


#endif
