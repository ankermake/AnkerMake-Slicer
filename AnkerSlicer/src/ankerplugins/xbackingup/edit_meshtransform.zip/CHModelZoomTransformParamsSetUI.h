/*
*摘要：模型变换缩放参数设置窗口
*作者：邹刚
*日期：2021年12月5日
*/


#ifndef CHModelZoomTransformParamsSetUI_H
#define CHModelZoomTransformParamsSetUI_H


#include <QDialog>
#include <QGroupBox>
#include <QScrollArea>
#include "QLabel"
#include "QLineEdit"
#include <vector>
#include "QPushButton"
#include "QCheckBox"
#include "CHCustomLineEdit.h"
#include "../../common/controlInterface/BubbleWidget.h"
#include "../../common/controlInterface/line.h"
#include "../../common/controlInterface/switchbutton.h"
#include <QDoubleSpinBox>
#include <QToolButton>

using namespace std;

class CHModelZoomTransformParamsSetUI : public control::BubbleWidget
{
    Q_OBJECT

public:
    CHModelZoomTransformParamsSetUI(QWidget* parent = Q_NULLPTR);
    ~CHModelZoomTransformParamsSetUI();


public Q_SLOTS:
    void receiveParams(vector<float> params);
    void receiveCurrentCenter(vector<float> params);


    void submit();
    void submit(double);
    void reset();
    void sameScale(int index);
    void setLock();
    void setLock(bool);

Q_SIGNALS:
    void sendParams(vector<float> params);
    void valueChanged(double);
    void stateChanged(bool checked);

private:

public:
    SwitchButton* m_lockCheckBox;
    QToolButton* m_scaleToFitButton;
    QToolButton* m_resetButton;
private:

    QDoubleSpinBox* m_xBox;
    QDoubleSpinBox* m_yBox;
    QDoubleSpinBox* m_zBox;

    QDoubleSpinBox* m_xScale;
    QDoubleSpinBox* m_yScale;
    QDoubleSpinBox* m_zScale;
    std::vector<QDoubleSpinBox*> m_allScaleEdits;
    vector<float> m_ratios;

};
#endif
